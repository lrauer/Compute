﻿using Compute;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testinterface
{
    class Levels
    {
        public static string getDescription(string name)
        {
            switch (name)
            {
                case "1Straight":
                    return "Input: Left, Output: Right";
                case "2TurnRight":
                    return "Input: Left, Output: Down";
                case "3Straight2D":
                    return "Input: Left or Right, Output: Opposite direction (Right or Left)";
                case "4TurnLeftAllSides":
                    return "Input: Any, Output: Next direction clockwise";
                case "5StraightTurn":
                    return "Input: Left or Right, Output: Right if Left, Up if Right";
                case "6Straight4D":
                    return "Input: Any, Output: Opposite direction";
                case "7Computer":
                    return "Input: Left, Output: value + 1, Right if value = 2 else down";
                case "8+Add5Big":
                    return "Input: Left, Output: value + 5, Right";
                case "8Add5Small":
                    return "Input: Left, Output: value + 5, Right, Boundaries are limited";
                case "9Alternate":
                    return "Input: Left, Output: Right (first) and Down alternating";
                case "10Swap":
                    return "Input: 2xLeft, Output: 2xRight in Reverse order";
                case "11ReadDirection":
                    return "Input: Left (value 1-4), Output: direction depending on Value (1=L,2=U,3=R,4=D)";
                case "12+RRRL":
                    return "Input: Any, Output: Right, except from Right then Left";
                case "12ReadDirectionAll":
                    return "Input: Any (value 1-4), Output: direction depending on Value (1=L,2=U,3=R,4=D)";
                case "13NOT":
                    return "Input: Left (Value 0 or 1), Output: Right (inverted Value 1 or 0)";
                case "14NOTNoIncrementer":
                    return "Input: Left (Value 0 or 1), Output: Right (inverted Value 1 or 0), can't use Incrementer/Decrementer";
                case "15OR":
                    return "Input: 2xLeft (Value 0 or 1), Output: Right (value 1 if either is 1 else 0)";
                case "16AND":
                    return "Input: 2xLeft (Value 0 or 1), Output: Right (value 1 if both are 1 else 0)";
                case "17XOR":
                    return "Input: 2xLeft (Value 0 or 1), Output: Right (value 0 inputs are the same else 1) ";
                case "18+Split":
                    return "Input: 2xLeft, Output: Up (first), Down";
                case "18ADD":
                    return "Input: 2xLeft (positive values), Output: Right (summed up)";
                case "19SUB":
                    return "Input: 2xLeft (positive values), Output: Right (subtracted)";
                case "20+PositiveCopy":
                    return "Input: Left (Value >= 0), Output: 2xRight";
                case "20PositiveCopyUpDown":
                    return "Input: Left (Value >= 0), Output: Up, Down";
                case "21Identical":
                    return "Input: 2xLeft, Output: Right (Value 1 if identical else 0)";
                case "22+DoubleInOut":
                    return "Input: 2xAny, Output: 2xRight (order does not matter)";
                case "22IdenticalOut":
                    return "Input: 2xLeft, Output: Up, Down, Right (Value 1 if identical else 0)";
                case "23Alternate3Way":
                    return "Input: Left, Output: Up (first), Right (second) and Down alternating";
                case "24+AlternateAll":
                    return "Input: Any, Output: Up (first), Right";
                case "24Alternate4Way":
                    return "Input: Left, Output: Up (first), Right (second) and Down (third), Left alternating";
                case "25+Straight2I":
                    return "Input: 2xAny (one value is -1), Right (other value)";
                case "25Sync":
                    return "Input 2xLeft, Output: 2xRight, outputs at the exact same time by waiting for the other input";
                case "26Greater5":
                    return "Input: Left, Output: Up if value greater 5 else Down";
                case "27PositiveGreaterThan":
                    return "Input: 2xLeft (positive values), Output: Right (1 if first value greater, 0 if identical, else -1)";
                case "28GreaterUp":
                    return "Input: 2xLeft, Output: Up (greater Number), Down (Lower Number)";
                case "29PositiveNegative":
                    return "Input: Left, Output: Right (1 if positive number, 0 if 0, else -1)";
                case "30Multiply3":
                    return "Input: Left, Output: Right (Value * 3)";
                case "31ChangeSign":
                    return "Input: Left, Output: Right (Value * -1)";
                case "32Divide2":
                    return "Input: Left (even Value), Output: Right (Value / 2)";
                case "33Multiply":
                    return "Input: 2xLeft, Output: Right (multiplied)";
                case "34RaisePower":
                    return "Input: 2xLeft, Output: Right (first value raised to the power of second)";
                case "35Divide":
                    return "Input: 2xLeft, Output: Right (first value divided by second), Down (Remainder)";
                case "36Combine":
                    return "Input: 2xLeft, Output: Right (combined Digits)";
                case "37TakeApart":
                    return "Input: Left (value 3 digits), Output: 3xRight (single Digits)";
                case "38Lowest":
                    return "Input: 4xLeft, Output: Right (lowest value)";
                case "39Average":
                    return "Input: 6xLeft, Output: Right (average no rounding needed)";
                case "40Sort":
                    return "Input: 4xLeft, Output: 4xRight (sorted lowest to highest)";
                case "41+Split4":
                    return "Input: 4xLeft, Output: 2xUp, 2xDown (first up then down)";
                case "41Sort5":
                    return "Input: 5xLeft, Output: 5xRight (sorted lowest to highest)";
                case "42Memory":
                    return "Input: Left or Up (Value 0 or 1), Output: Right (if input up save the value and output, if left read the previously saved value or 0)";
                case "43Memory2Bit":
                    return "Input: 2xLeft or 2xUp (Value 0 or 1), Output: 2xRight (saved value)";
                case "44+Combine4":
                    return "Input: 4xLeft, Output: Right (combined digits)";
                case "44+Divide10":
                    return "Input: Left, Output: Right (value / 10), Down (Remainder)";
                case "44+SplitAngle":
                    return "Input: 2xLeft, Output: Right (first value), Up";
                case "44Memory4Bit":
                    return "Input: Left or Up (4 digit value of 1 and 0), Output: Right (saved value)";
                case "45+Memory8Bit":
                    return "Input: Left or Up (8 digit value of 1 and 0), Output: Right (saved value)";
                case "45+ToBase2":
                    return "Input: Left (number <= 255), Output: Right (8 bit binary value)";
                case "45+ToBase10":
                    return "Input: Left (8 bit (digits) binary value), Output: Right (base 10 number)";
                case "45MemoryBase10":
                    return "Input: Left or Up (number <= 255), Output: Right (saved value)";
                case "46+Invert1Bit":
                    return "Input: Left (value 0 or 1), Output: Right (inverted value 1 or 0)";
                case "46+Reverse":
                    return "Input: Left (8 digits) , Output: Right (all 8 digits in reversed order including leading 0)";
                case "46Invert8Bit":
                    return "Input: Left (8 bit (digits) binary value), Output: Right (inverted 8 bit binary value including leading 0)";
                case "47Add3Circles":
                    return "Input: Left, Output: Right (0 for first and second time, sum of last 3 values the third time)";
                case "48+CurrentCircle":
                    return "Input: Left, Output: Right (number of total inputs - 1)";
                case "48Fibonacci":
                    return "Input: Left, Output: Right (fibonacci sequence (sum of last 2 outputs) repeated after 13 outputs)";
                case "49+AlternateSwitched":
                    return "Input: Left, Output: Down (first), Right alternating";
                case "49+DDRRR":
                    return "Input: Left, Output: Down (first and second time), Right (third to fifth time) alternating";
                case "49+Multiply-1":
                    return "Input: Left, Output: Right (Value * -1) faster Version of 31ChangeSign";
                case "49+Savebank":
                    return "Input: Left (value 1 to 3 for saveslot) then Left or Up, Output: Right (saved value in the selected saveslot)";
                case "49Movement3D":
                    return "Input: 2xLeft (1 to 6 for order, then value amount), Output: 3xRight (value of each axis starts at 0,0,0), Orders: 1 = X forward, 2 = Y forward, 3 = Z forward, 4-6 same Axis but backwards";
                case "50+Check3":
                    return "Input: 3xLeft (values 0 or 1 or 2), Output: Right (value if all identical, 0 if atleast one is 0 else 3";
                case "50+CheckForDiagonals":
                    return "Input: 9xLeft (values 0 or 1 or 2), Output: 2xRight (outputs of 50+Check3 for diagonal lines, first top left to bottom right)";
                case "50+CheckForEnd":
                    return "Input: 6xLeft, 2xUp (values 0 or 1 or 2 or 3), Output: Right (priority 2>1>0>3 to find the endresult of the Checks)";
                case "50+CheckForLines":
                    return "Input: 9xLeft (values 0 or 1 or 2), Output: 6xRight (outputs of 50+Check3 first for vertical then for horizontal lines)";
                case "50+GetPlayer":
                    return "Input: Left, Output: Right (1 and 2 alternating, starts with 1, resets and outs 0 if input > 0)";
                case "50+PriorityUp":
                    return "Input: 2xLeft, Output: Up (more important value with priority 2>1>0>3), Down";
                case "50+ResetIfEnd":
                    return "Input: Left ( 1 to 9 for chosen field), Output: Right (like 50+WriteRead9 but Player 1 begins automatically and players take turns, if -1 same player goes again next, if > 0 game resets)";
                case "50+Savebank9":
                    return "Input: Left (value 1 to 9 for saveslot) then Left or Up, Output: Right (saved value in the selected saveslot)";
                case "50+SaveWithError":
                    return "Input: Left (value 1 to 9 for saveslot) then Left or Up, Output: Right (-1 if value already > 0 and new value > 0 else saved value in the selected saveslot)";
                case "50+SaveWithReset":
                    return "Input: Left (value 1 to 9 for saveslot) then Left or Up, Output: Right (like 50+SaveWithError, but resets all values to 0 if first input = 0 and outs -1)";
                case "50+WriteRead9":
                    return "Input: 2xLeft ( 1 to 9 for chosen field, then 1 or 2 for active player), Output: Right (0 if input ok, -1 if field already claimed, 1 if player 1 wins, 2 if player 2 wins, 3 if draw)";
                case "50TicTacToe":
                    return "Input: 2xLeft ( 1 to 3 for row and column), Output: Right(like 50+ResetIfEnd), Rules: player 1 always Begins, alternating inputs tile (1-3 for row then 1-3 for column), outs -1 if already mark at tile, 0 if ok, 1 if player 1 win, 2 if player 2 win, 3 if full = draw, after -1 player goes again, after 1/2/3 system will reset for next game";
                case "99test":
                    return "Input: Left, Output: Right, Just for testing";
                default:
                    return "Custom";
            }
        }

        public static void FillInputs(ComputeController c, string name, int amount)
        {
            switch (name)
            {
                case "1Straight":
                    Straight(c, amount);
                    break;
                case "2TurnRight":
                    TurnRight(c, amount);
                    break;
                case "3Straight2D":
                    Straight2D(c, amount);
                    break;
                case "4TurnLeftAllSides":
                    TurnLeftAllSides(c, amount);
                    break;
                case "5StraightTurn":
                    StraightTurn(c, amount);
                    break;
                case "6Straight4D":
                    Straight4D(c, amount);
                    break;
                case "7Computer":
                    Computer(c, amount);
                    break;
                case "8+Add5Big":
                    Add5(c, amount);
                    break;
                case "8Add5Small":
                    Add5(c, amount);
                    break;
                case "9Alternate":
                    Alternate(c, amount);
                    break;
                case "10Swap":
                    Swap(c, amount);
                    break;
                case "11ReadDirection":
                    ReadDirection(c, amount);
                    break;
                case "12+RRRL":
                    RRRL(c, amount);
                    break;
                case "12ReadDirectionAll":
                    ReadDirectionAll(c, amount);
                    break;
                case "13NOT":
                    NOT(c, amount);
                    break;
                case "14NOTNoIncrementer":
                    NOT(c, amount);
                    break;
                case "15OR":
                    OR(c, amount);
                    break;
                case "16AND":
                    AND(c, amount);
                    break;
                case "17XOR":
                    XOR(c, amount);
                    break;
                case "18+Split":
                    Split(c, amount);
                    break;
                case "18ADD":
                    ADD(c, amount);
                    break;
                case "19SUB":
                    SUB(c, amount);
                    break;
                case "20+PositiveCopy":
                    PositiveCopy(c, amount);
                    break;
                case "20PositiveCopyUpDown":
                    CopyUpDown(c, amount);
                    break;
                case "21Identical":
                    Identical(c, amount);
                    break;
                case "22+DoubleInOut":
                    DoubleInOut(c, amount);
                    break;
                case "22IdenticalOut":
                    IdenticalOut(c, amount);
                    break;
                case "23Alternate3Way":
                    Alternate3Way(c, amount);
                    break;
                case "24+AlternateAll":
                    AlternateAll(c, amount);
                    break;
                case "24Alternate4Way":
                    Alternate4Way(c, amount);
                    break;
                case "25+Straight2I":
                    Straight2I(c, amount);
                    break;
                case "25Sync":
                    Sync(c, amount);
                    break;
                case "26Greater5":
                    Greater5(c, amount);
                    break;
                case "27PositiveGreaterThan":
                    PositiveGreaterThan(c, amount);
                    break;
                case "28GreaterUp":
                    GreaterUp(c, amount);
                    break;
                case "29PositiveNegative":
                    PositiveNegative(c, amount);
                    break;
                case "30Multiply3":
                    Multiply3(c, amount);
                    break;
                case "31ChangeSign":
                    ChangeSign(c, amount);
                    break;
                case "32Divide2":
                    Divide2(c, amount);
                    break;
                case "33Multiply":
                    Multiply(c, amount);
                    break;
                case "34RaisePower":
                    RaisePower(c, amount);
                    break;
                case "35Divide":
                    Divide(c, amount);
                    break;
                case "36Combine":
                    Combine(c, amount);
                    break;
                case "37TakeApart":
                    TakeApart(c, amount);
                    break;
                case "38Lowest":
                    Lowest(c, amount);
                    break;
                case "39Average":
                    Average(c, amount);
                    break;
                case "40Sort":
                    Sort(c, amount);
                    break;
                case "41+Split4":
                    Split4(c, amount);
                    break;
                case "41Sort5":
                    Sort5(c, amount);
                    break;
                case "42Memory":
                    Memory1Bit(c, amount);
                    break;
                case "43Memory2Bit":
                    Memory2Bit(c, amount);
                    break;
                case "44+Combine4":
                    Combine4(c, amount);
                    break;
                case "44+Divide10":
                    Divide10(c, amount);
                    break;
                case "44+SplitAngle":
                    SplitAngle(c, amount);
                    break;
                case "44Memory4Bit":
                    Memory4Bit(c, amount);
                    break;
                case "45+Memory8Bit":
                    Memory8Bit(c, amount);
                    break;
                case "45+ToBase2":
                    ToBase2(c, amount);
                    break;
                case "45+ToBase10":
                    ToBase10(c, amount);
                    break;
                case "45MemoryBase10":
                    MemoryBase10(c, amount);
                    break;
                case "46+Invert1Bit":
                    Invert1Bit(c, amount);
                    break;
                case "46+Reverse":
                    Reverse(c, amount);
                    break;
                case "46Invert8Bit":
                    Invert8Bit(c, amount);
                    break;
                case "47Add3Circles":
                    Add3Circles(c, amount);
                    break;
                case "48+CurrentCircle":
                    CurrentCircle(c, amount);
                    break;
                case "48Fibonacci":
                    Fibonacci(c, amount);
                    break;
                case "49+AlternateSwitched":
                    AlternateSwitched(c, amount);
                    break;
                case "49+DDRRR":
                    DDRRR(c, amount);
                    break;
                case "49+Multiply-1":
                    MultiplyNEG1(c, amount);
                    break;
                case "49+Savebank":
                    Savebank(c, amount);
                    break;
                case "49Movement3D":
                    Movement3D(c, amount);
                    break;
                case "50+Check3":
                    Check3(c, amount);
                    break;
                case "50+CheckForDiagonals":
                    CheckForDiagonals(c, amount);
                    break;
                case "50+CheckForEnd":
                    CheckForEnd(c, amount);
                    break;
                case "50+CheckForLines":
                    CheckForLines(c, amount);
                    break;
                case "50+GetPlayer":
                    GetPlayer(c, amount);
                    break;
                case "50+PriorityUp":
                    PriorityUp(c, amount);
                    break;
                case "50+ResetIfEnd":
                    ResetIfEnd(c, amount);
                    break;
                case "50+Savebank9":
                    Savebank9(c, amount);
                    break;
                case "50+SaveWithError":
                    SaveWithError(c, amount);
                    break;
                case "50+SaveWithReset":
                    SaveWithReset(c, amount);
                    break;
                case "50+WriteRead9":
                    WriteRead9(c, amount);
                    break;
                case "50TicTacToe":
                    TicTacToe(c, amount);
                    break;
                case "99test":
                    Custom(c, amount);
                    break;
                default:
                    Custom(c, amount);
                    break;
            }
        }

        public static void Straight(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);

                c.AddNextInput(Direction.Left, r);

                c.AddNextExpectedOutput(Direction.Right, r);

            }
        }

        public static void TurnRight(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);

                c.AddNextInput(Direction.Left, r);

                c.AddNextExpectedOutput(Direction.Down, r);

            }
        }

        public static void Straight2D(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);
                int r2 = random.Next(0, 2);

                if (r2 == 0)
                {
                    c.AddNextInput(Direction.Left, r);
                    c.AddNextExpectedOutput(Direction.Right, r);
                }
                else
                {
                    c.AddNextInput(Direction.Right, r);
                    c.AddNextExpectedOutput(Direction.Left, r);
                }

            }
        }

        public static void TurnLeftAllSides(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);
                int r2 = random.Next(0, 4);

                if (r2 == 0)
                {
                    c.AddNextInput(Direction.Left, r);
                    c.AddNextExpectedOutput(Direction.Up, r);
                }
                if (r2 == 1)
                {
                    c.AddNextInput(Direction.Up, r);
                    c.AddNextExpectedOutput(Direction.Right, r);
                }
                if (r2 == 2)
                {
                    c.AddNextInput(Direction.Right, r);
                    c.AddNextExpectedOutput(Direction.Down, r);
                }
                if (r2 == 3)
                {
                    c.AddNextInput(Direction.Down, r);
                    c.AddNextExpectedOutput(Direction.Left, r);
                }

            }
        }

        public static void StraightTurn(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);
                int r2 = random.Next(0, 2);

                if (r2 == 0)
                {
                    c.AddNextInput(Direction.Left, r);
                    c.AddNextExpectedOutput(Direction.Right, r);
                }
                else
                {
                    c.AddNextInput(Direction.Right, r);
                    c.AddNextExpectedOutput(Direction.Up, r);
                }

            }
        }

        public static void Straight4D(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);
                int r2 = random.Next(0, 4);

                if (r2 == 0)
                {
                    c.AddNextInput(Direction.Left, r);
                    c.AddNextExpectedOutput(Direction.Right, r);
                }
                if (r2 == 1)
                {
                    c.AddNextInput(Direction.Up, r);
                    c.AddNextExpectedOutput(Direction.Down, r);
                }
                if (r2 == 2)
                {
                    c.AddNextInput(Direction.Right, r);
                    c.AddNextExpectedOutput(Direction.Left, r);
                }
                if (r2 == 3)
                {
                    c.AddNextInput(Direction.Down, r);
                    c.AddNextExpectedOutput(Direction.Up, r);
                }

            }
        }

        public static void Computer(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 10);
                c.AddNextInput(Direction.Left, r);
                r++;
                if(r == 2)
                {
                    c.AddNextExpectedOutput(Direction.Right, r);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Down, r);
                }

            }
        }

        public static void Add5(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 10);
                c.AddNextInput(Direction.Left, r);
                c.AddNextExpectedOutput(Direction.Right, r+5);

            }
        }

        public static void Alternate(ComputeController c, int amount)
        {
            Random random = new Random();

            bool down = false;
            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);
                c.AddNextInput(Direction.Left, r);
                if (down)
                {
                    c.AddNextExpectedOutput(Direction.Down, r);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, r);
                }
                down = !down;
            }
        }

        public static void Swap(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);
                int r2 = random.Next(0, 100);

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);

                c.AddNextExpectedOutput(Direction.Right, r2);
                c.AddNextExpectedOutput(Direction.Right, r);
            }
        }

        public static void ReadDirection(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(1, 5);

                c.AddNextInput(Direction.Left, r);

                if (r == 1)
                {
                    c.AddNextExpectedOutput(Direction.Left, r);
                }
                if (r == 2)
                {
                    c.AddNextExpectedOutput(Direction.Up, r);
                }
                if (r == 3)
                {
                    c.AddNextExpectedOutput(Direction.Right, r);
                }
                if (r == 4)
                {
                    c.AddNextExpectedOutput(Direction.Down, r);
                }
            }
        }

        public static void RRRL(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);
                int r2 = random.Next(0, 4);

                if (r2 == 0)
                {
                    c.AddNextInput(Direction.Left, r);
                    c.AddNextExpectedOutput(Direction.Right, r);
                }
                if (r2 == 1)
                {
                    c.AddNextInput(Direction.Up, r);
                    c.AddNextExpectedOutput(Direction.Right, r);
                }
                if (r2 == 2)
                {
                    c.AddNextInput(Direction.Down, r);
                    c.AddNextExpectedOutput(Direction.Right, r);
                }
                if (r2 == 3)
                {
                    c.AddNextInput(Direction.Right, r);
                    c.AddNextExpectedOutput(Direction.Left, r);
                }
            }
        }

        public static void ReadDirectionAll(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(1, 5);
                int r2 = random.Next(0, 4);

                if (r2 == 0)
                {
                    c.AddNextInput(Direction.Left, r);
                }
                if (r2 == 1)
                {
                    c.AddNextInput(Direction.Up, r);
                }
                if (r2 == 2)
                {
                    c.AddNextInput(Direction.Right, r);
                }
                if (r2 == 3)
                {
                    c.AddNextInput(Direction.Down, r);
                }

                if (r == 1)
                {
                    c.AddNextExpectedOutput(Direction.Left, r);
                }
                if (r == 2)
                {
                    c.AddNextExpectedOutput(Direction.Up, r);
                }
                if (r == 3)
                {
                    c.AddNextExpectedOutput(Direction.Right, r);
                }
                if (r == 4)
                {
                    c.AddNextExpectedOutput(Direction.Down, r);
                }
            }
        }

        public static void NOT(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 2);

                c.AddNextInput(Direction.Left, r);

                if (r == 0)
                {
                    c.AddNextExpectedOutput(Direction.Right, 1);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, 0);
                }
            }
        }

        public static void OR(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 2);
                int r2 = random.Next(0, 2);

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);

                if (r == 1 || r2 == 1)
                {
                    c.AddNextExpectedOutput(Direction.Right, 1);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, 0);
                }
            }
        }

        public static void AND(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 2);
                int r2 = random.Next(0, 2);

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);

                if (r == 1 && r2 == 1)
                {
                    c.AddNextExpectedOutput(Direction.Right, 1);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, 0);
                }
            }
        }

        public static void XOR(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 2);
                int r2 = random.Next(0, 2);

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);

                if ((r == 1 && r2 == 0) || (r == 0 && r2 == 1))
                {
                    c.AddNextExpectedOutput(Direction.Right, 1);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, 0);
                }
            }
        }

        public static void Split(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);
                int r2 = random.Next(0, 100);

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);

                c.AddNextExpectedOutput(Direction.Up, r);
                c.AddNextExpectedOutput(Direction.Down, r2);

            }
        }

        public static void ADD(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 10);
                int r2 = random.Next(0, 10);

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);

                c.AddNextExpectedOutput(Direction.Right, r+r2);

            }
        }

        public static void SUB(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 10);
                int r2 = random.Next(0, 10);

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);

                c.AddNextExpectedOutput(Direction.Right, r - r2);

            }
        }

        public static void PositiveCopy(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 10);

                c.AddNextInput(Direction.Left, r);

                c.AddNextExpectedOutput(Direction.Right, r);
                c.AddNextExpectedOutput(Direction.Right, r);

            }
        }

        public static void CopyUpDown(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 10);

                c.AddNextInput(Direction.Left, r);

                c.AddNextExpectedOutput(Direction.Up, r);
                c.AddNextExpectedOutput(Direction.Down, r);

            }
        }

        public static void Identical(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 10);
                int r2 = random.Next(0, 10);

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);

                if (r == r2)
                {
                    c.AddNextExpectedOutput(Direction.Right, 1);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, 0);
                }
                

            }
        }

        public static void DoubleInOut(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);
                int r2 = r;
                int r3 = random.Next(0, 4);
                int r4 = random.Next(0, 4);

                if (r3 == 0)
                {
                    c.AddNextInput(Direction.Left, r);
                }
                if (r3 == 1)
                {
                    c.AddNextInput(Direction.Up, r);
                }
                if (r3 == 2)
                {
                    c.AddNextInput(Direction.Right, r);
                }
                if (r3 == 3)
                {
                    c.AddNextInput(Direction.Down, r);
                }

                if (r4 == 0)
                {
                    c.AddNextInput(Direction.Left, r2);
                }
                if (r4 == 1)
                {
                    c.AddNextInput(Direction.Up, r2);
                }
                if (r4 == 2)
                {
                    c.AddNextInput(Direction.Right, r2);
                }
                if (r4 == 3)
                {
                    c.AddNextInput(Direction.Down, r2);
                }

                c.AddNextExpectedOutput(Direction.Right, r);
                c.AddNextExpectedOutput(Direction.Right, r2);


            }
        }

        public static void IdenticalOut(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 10);
                int r2 = random.Next(0, 10);

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);

                c.AddNextExpectedOutput(Direction.Up, r);
                c.AddNextExpectedOutput(Direction.Down, r2);

                if (r == r2)
                {
                    c.AddNextExpectedOutput(Direction.Right, 1);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, 0);
                }


            }
        }

        public static void Alternate3Way(ComputeController c, int amount)
        {
            Random random = new Random();

            int d = 0;
            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);
                d++;

                c.AddNextInput(Direction.Left, r);


                if (d == 1)
                {
                    c.AddNextExpectedOutput(Direction.Up, r);
                }
                else if(d == 2)
                {
                    c.AddNextExpectedOutput(Direction.Right, r);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Down, r);
                    d = 0;
                }


            }
        }

        public static void AlternateAll(ComputeController c, int amount)
        {
            Random random = new Random();

            bool down = false;
            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);
                int r2 = random.Next(0, 4);

                if(r2 == 0)
                {
                    c.AddNextInput(Direction.Left, r);
                }
                if (r2 == 1)
                {
                    c.AddNextInput(Direction.Up, r);
                }
                if (r2 == 2)
                {
                    c.AddNextInput(Direction.Right, r);
                }
                if (r2 == 3)
                {
                    c.AddNextInput(Direction.Down, r);
                }

                if (!down)
                {
                    c.AddNextExpectedOutput(Direction.Up, r);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, r);
                }
                down = !down;
            }
        }

        public static void Alternate4Way(ComputeController c, int amount)
        {
            Random random = new Random();

            int d = 0;
            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);
                d++;

                c.AddNextInput(Direction.Left, r);


                if (d == 1)
                {
                    c.AddNextExpectedOutput(Direction.Up, r);
                }
                else if (d == 2)
                {
                    c.AddNextExpectedOutput(Direction.Right, r);
                }
                else if (d == 3)
                {
                    c.AddNextExpectedOutput(Direction.Down, r);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Left, r);
                    d = 0;
                }


            }
        }

        public static void Straight2I(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);
                int r2 = -1;
                int r3 = random.Next(0, 2);

                if (r3 == 0)
                {
                    c.AddNextInput(Direction.Left, r);
                    c.AddNextInput(Direction.Left, r2);
                }
                else
                {
                    c.AddNextInput(Direction.Left, r2);
                    c.AddNextInput(Direction.Left, r);
                }

                c.AddNextExpectedOutput(Direction.Right, r);

            }
        }

        public static void Sync(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);
                int r2 = random.Next(0, 100);

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);

                c.AddNextExpectedOutput(Direction.Right, r);
                c.AddNextExpectedOutput(Direction.Right, r2);

            }
        }

        public static void Greater5(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 10);
                c.AddNextInput(Direction.Left, r);

                if (r > 5)
                {
                    c.AddNextExpectedOutput(Direction.Up, r);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Down, r);
                }

            }
        }

        public static void PositiveGreaterThan(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 10);
                int r2 = random.Next(0, 10);

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);

                if (r > r2)
                {
                    c.AddNextExpectedOutput(Direction.Right, 1);
                }
                else if (r == r2)
                {
                    c.AddNextExpectedOutput(Direction.Right, 0);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, -1);
                }

            }
        }

        public static void GreaterUp(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);
                int r2 = random.Next(0, 100);

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);

                if (r > r2)
                {
                    c.AddNextExpectedOutput(Direction.Up, r);
                    c.AddNextExpectedOutput(Direction.Down, r2);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Up, r2);
                    c.AddNextExpectedOutput(Direction.Down, r);
                }

            }
        }

        public static void PositiveNegative(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(-9, 10);

                c.AddNextInput(Direction.Left, r);

                if (r > 0)
                {
                    c.AddNextExpectedOutput(Direction.Right, 1);
                }
                else if (r == 0)
                {
                    c.AddNextExpectedOutput(Direction.Right, 0);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, -1);
                }

            }
        }

        public static void Multiply3(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);

                c.AddNextInput(Direction.Left, r);

                c.AddNextExpectedOutput(Direction.Right, r*3);

            }
        }

        public static void ChangeSign(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(-9, 10);

                c.AddNextInput(Direction.Left, r);

                c.AddNextExpectedOutput(Direction.Right, r * -1);

            }
        }

        public static void Divide2(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 11);

                c.AddNextInput(Direction.Left, r*2);

                c.AddNextExpectedOutput(Direction.Right, r);

            }
        }

        public static void Multiply(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 10);
                int r2 = random.Next(1, 5);
                int r3 = random.Next(0, 2);

                if (r3 == 1)
                {
                    c.AddNextInput(Direction.Left, r);
                    c.AddNextInput(Direction.Left, r2);
                }
                else
                {
                    c.AddNextInput(Direction.Left, r);
                    c.AddNextInput(Direction.Left, r2);
                }

                c.AddNextExpectedOutput(Direction.Right, r * r2);

            }
        }

        public static void RaisePower(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 20);
                int r2 = random.Next(0, 4);

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);

                c.AddNextExpectedOutput(Direction.Right, int.Parse(Math.Round(Math.Pow(r, r2)).ToString()));

            }
        }

        public static void Divide(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 21);
                int r2 = random.Next(1, 10);

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);

                c.AddNextExpectedOutput(Direction.Right, r / r2);
                c.AddNextExpectedOutput(Direction.Down, r % r2);

            }
        }

        public static void Combine(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 10);
                int r2 = random.Next(0, 10);

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);

                c.AddNextExpectedOutput(Direction.Right, r * 10 + r2);

            }
        }

        public static void TakeApart(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 10);
                int r2 = random.Next(0, 10);
                int r3 = random.Next(0, 10);

                c.AddNextInput(Direction.Left, r * 100 + r2 * 10 + r3);

                c.AddNextExpectedOutput(Direction.Right, r);
                c.AddNextExpectedOutput(Direction.Right, r2);
                c.AddNextExpectedOutput(Direction.Right, r3);

            }
        }

        public static void Lowest(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);
                int r2 = random.Next(0, 100);
                int r3 = random.Next(0, 100);
                int r4 = random.Next(0, 100);

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);
                c.AddNextInput(Direction.Left, r3);
                c.AddNextInput(Direction.Left, r4);

                if (r > r2)
                {
                    r = r2;
                }
                if (r3 > r4)
                {
                    r3 = r4;
                }
                if (r > r3)
                {
                    r = r3;
                }
                c.AddNextExpectedOutput(Direction.Right, r);

            }
        }

        public static void Average(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);
                int r2 = random.Next(0, 100);
                int r3 = random.Next(0, 100);
                int r4 = random.Next(0, 100);
                int r5 = random.Next(0, 100);
                int r6 = 6 * random.Next(1, 16) - (r + r2 + r3 + r4 + r5) % 6;

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);
                c.AddNextInput(Direction.Left, r3);
                c.AddNextInput(Direction.Left, r4);
                c.AddNextInput(Direction.Left, r5);
                c.AddNextInput(Direction.Left, r6);


                c.AddNextExpectedOutput(Direction.Right, (r+r2+r3+r4+r5+r6)/6);

            }
        }

        public static void Sort(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                List<int> list = new List<int>();
                int r = 0;
                for (int j = 0; j < 4; j++)
                {
                    r = random.Next(0, 100);
                    list.Add(r);
                    c.AddNextInput(Direction.Left, r);
                }

                list.Sort();

                for (int j = 0; j < 4; j++)
                {
                    c.AddNextExpectedOutput(Direction.Right, list[j]);
                }

            }
        }

        public static void Split4(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {

                int r = random.Next(0, 100);
                int r2 = random.Next(0, 100);
                int r3 = random.Next(0, 100);
                int r4 = random.Next(0, 100);
                
                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);
                c.AddNextInput(Direction.Left, r3);
                c.AddNextInput(Direction.Left, r4);

                c.AddNextExpectedOutput(Direction.Up, r);
                c.AddNextExpectedOutput(Direction.Up, r2);
                c.AddNextExpectedOutput(Direction.Down, r3);
                c.AddNextExpectedOutput(Direction.Down, r4);

            }
        }

        public static void Sort5(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                List<int> list = new List<int>();
                int r;
                for (int j = 0; j < 5; j++)
                {
                    r = random.Next(0, 100);
                    list.Add(r);
                    c.AddNextInput(Direction.Left, r);
                }

                list.Sort();

                for (int j = 0; j < 5; j++)
                {
                    c.AddNextExpectedOutput(Direction.Right, list[j]);
                }

            }
        }

        public static void Memory1Bit(ComputeController c, int amount)
        {
            Random random = new Random();

            int memory = 0;
            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 2);
                int r2 = random.Next(0, 2);

                if (r2 == 0)
                {
                    c.AddNextInput(Direction.Left, r);
                }
                else
                {
                    c.AddNextInput(Direction.Up, r);
                    memory = r;
                }

                c.AddNextExpectedOutput(Direction.Right, memory);

            }
        }

        public static void Memory2Bit(ComputeController c, int amount)
        {
            Random random = new Random();

            int memory = 0;
            int memory2 = 0;
            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 2);
                int r2 = random.Next(0, 2);
                int r3 = random.Next(0, 2);

                if (r3 == 0)
                {
                    c.AddNextInput(Direction.Left, r);
                    c.AddNextInput(Direction.Left, r2);
                }
                else
                {
                    c.AddNextInput(Direction.Up, r);
                    c.AddNextInput(Direction.Up, r2);
                    memory = r;
                    memory2 = r2;
                }

                c.AddNextExpectedOutput(Direction.Right, memory);
                c.AddNextExpectedOutput(Direction.Right, memory2);

            }
        }

        public static void Combine4(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 10);
                int r2 = random.Next(0, 10);
                int r3 = random.Next(0, 10);
                int r4 = random.Next(0, 10);

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);
                c.AddNextInput(Direction.Left, r3);
                c.AddNextInput(Direction.Left, r4);

                c.AddNextExpectedOutput(Direction.Right, r * 1000 + r2 * 100 + r3 * 10 + r4);

            }
        }

        public static void Divide10(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);

                c.AddNextInput(Direction.Left, r);

                c.AddNextExpectedOutput(Direction.Right, r / 10);
                c.AddNextExpectedOutput(Direction.Down, r % 10);

            }
        }

        public static void SplitAngle(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);
                int r2 = random.Next(0, 100);

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);

                c.AddNextExpectedOutput(Direction.Right, r);
                c.AddNextExpectedOutput(Direction.Up, r2);

            }
        }

        public static void Memory4Bit(ComputeController c, int amount)
        {
            Random random = new Random();

            int memory = 0;
            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 2);
                int r2 = random.Next(0, 2);
                int r3 = random.Next(0, 2);
                int r4 = random.Next(0, 2);
                int r5 = random.Next(0, 2);
                int erg = r * 1000 + r2 * 100 + r3 * 10 + r4;

                if (r5 == 0)
                {
                    c.AddNextInput(Direction.Left, erg);
                }
                else
                {
                    c.AddNextInput(Direction.Up, erg);
                    memory = erg;
                }

                c.AddNextExpectedOutput(Direction.Right, memory);

            }
        }

        public static void Memory8Bit(ComputeController c, int amount)
        {
            Random random = new Random();

            int memory = 0;
            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 2);
                int r2 = random.Next(0, 2);
                int r3 = random.Next(0, 2);
                int r4 = random.Next(0, 2);
                int r5 = random.Next(0, 2);
                int r6 = random.Next(0, 2);
                int r7 = random.Next(0, 2);
                int r8 = random.Next(0, 2);
                int r9 = random.Next(0, 2);
                int erg = r * 10000000 + r2 * 1000000 + r3 * 100000 + r4 * 10000 + r5 * 1000 + r6 * 100 + r7 * 10 + r8;

                if (r9 == 0)
                {
                    c.AddNextInput(Direction.Left, erg);
                }
                else
                {
                    c.AddNextInput(Direction.Up, erg);
                    memory = erg;
                }

                c.AddNextExpectedOutput(Direction.Right, memory);

            }
        }

        public static void ToBase2(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 255);
                int erg = 0;
                int tmp = r;
                int multiplier = 1;

                for(int j = 0; j < 8; j++)
                {
                    erg += tmp % 2 * multiplier;
                    multiplier *= 10;
                    tmp /= 2;
                }

                c.AddNextInput(Direction.Left, r);
                c.AddNextExpectedOutput(Direction.Right, erg);

            }
        }

        public static void ToBase10(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 255);
                int erg = 0;
                int tmp = r;
                int multiplier = 1;

                for (int j = 0; j < 8; j++)
                {
                    erg += tmp % 2 * multiplier;
                    multiplier *= 10;
                    tmp /= 2;
                }

                c.AddNextInput(Direction.Left, erg);
                c.AddNextExpectedOutput(Direction.Right, r);

            }
        }

        public static void MemoryBase10(ComputeController c, int amount)
        {
            Random random = new Random();

            int memory = 0;
            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 255);
                int r2 = random.Next(0, 2);

                if (r2 == 0)
                {
                    c.AddNextInput(Direction.Left, r);
                }
                else
                {
                    c.AddNextInput(Direction.Up, r);
                    memory = r;
                }

                c.AddNextExpectedOutput(Direction.Right, memory);

            }
        }

        public static void Invert1Bit(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 2);

                c.AddNextInput(Direction.Left, r);

                if (r == 0)
                {
                    c.AddNextExpectedOutput(Direction.Right, 1);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, 0);
                }

            }
        }

        public static void Reverse(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int[] r = new int[8];
                int input = 0;
                int output = 0;

                for (int j = 0; j < r.Length; j++)
                {
                    r[j] = random.Next(0, 10);
                    input *= 10;
                    input += r[j];
                }

                for (int j = r.Length-1; j >= 0; j--)
                {
                    output *= 10;
                    output += r[j];
                }

                c.AddNextInput(Direction.Left, input);

                c.AddNextExpectedOutput(Direction.Right, output);

            }
        }

        public static void Invert8Bit(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int[] r = new int[8];
                int input = 0;
                int output = 0;

                for (int j = 0; j < r.Length; j++)
                {
                    r[j] = random.Next(0, 2);
                    input *= 10;
                    input += r[j];
                    output *= 10;
                    if (r[j] == 0)
                    {
                        output += 1;
                    }
                    else
                    {
                        output += 0;
                    }
                }

                c.AddNextInput(Direction.Left, input);

                c.AddNextExpectedOutput(Direction.Right, output);

            }
        }

        public static void Add3Circles(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);
                int r2 = random.Next(0, 100);
                int r3 = random.Next(0, 100);

                c.AddNextInput(Direction.Left, r);
                c.AddNextExpectedOutput(Direction.Right, 0);
                i++;
                if (i < amount)
                {
                    c.AddNextInput(Direction.Left, r2);
                    c.AddNextExpectedOutput(Direction.Right, 0);
                }
                i++;
                if (i < amount)
                {
                    c.AddNextInput(Direction.Left, r3);
                    c.AddNextExpectedOutput(Direction.Right, r + r2 + r3);
                }

            }
        }

        public static void CurrentCircle(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);

                c.AddNextInput(Direction.Left, r);
                c.AddNextExpectedOutput(Direction.Right, i);

            }
        }

        public static void Fibonacci(ComputeController c, int amount)
        {
            Random random = new Random();

            int last = 0;
            int last2 = 0;
            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);

                if (i % 13 == 0)
                {
                    last = 0;
                    last2 = 0;
                }

                c.AddNextInput(Direction.Left, r);

                int erg = last + last2;
                if (erg == 0)
                {
                    erg = 1;
                }
                c.AddNextExpectedOutput(Direction.Right, erg);

                last2 = last;
                last = erg;

            }
        }

        public static void AlternateSwitched(ComputeController c, int amount)
        {
            Random random = new Random();

            bool down = true;
            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);

                c.AddNextInput(Direction.Left, r);

                if (down)
                {
                    c.AddNextExpectedOutput(Direction.Down, r);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, r);
                }

                down = !down;

            }
        }

        public static void DDRRR(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);

                c.AddNextInput(Direction.Left, r);

                if (i % 5 == 0 || i % 5 == 1)
                {
                    c.AddNextExpectedOutput(Direction.Down, r);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, r);
                }

            }
        }

        public static void MultiplyNEG1(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(-99, 100);

                c.AddNextInput(Direction.Left, r);

                c.AddNextExpectedOutput(Direction.Right, r * -1);

            }
        }

        public static void Savebank(ComputeController c, int amount)
        {
            Random random = new Random();

            int save = 0;
            int save2 = 0;
            int save3 = 0;
            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 100);
                int r2 = random.Next(1, 4);
                int r3 = random.Next(0, 2);

                c.AddNextInput(Direction.Left, r2);

                if (r3 == 0)
                {
                    c.AddNextInput(Direction.Left, r);
                }
                else
                {
                    c.AddNextInput(Direction.Up, r);
                    if (r2 == 1)
                    {
                        save = r;
                    }
                    else if (r2 == 2)
                    {
                        save2 = r;
                    }
                    else
                    {
                        save3 = r;
                    }
                }

                if (r2 == 1)
                {
                    c.AddNextExpectedOutput(Direction.Right, save);
                }
                else if (r2 == 2)
                {
                    c.AddNextExpectedOutput(Direction.Right, save2);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, save3);
                }

            }
        }

        public static void Movement3D(ComputeController c, int amount)
        {
            Random random = new Random();

            int save = 0;
            int save2 = 0;
            int save3 = 0;
            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(1, 7);
                int r2 = random.Next(0, 10);

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);

                switch (r)
                {
                    case 1:
                        save += r2;
                        break;
                    case 2:
                        save2 += r2;
                        break;
                    case 3:
                        save3 += r2;
                        break;
                    case 4:
                        save -= r2;
                        break;
                    case 5:
                        save2 -= r2;
                        break;
                    case 6:
                        save3 -= r2;
                        break;
                }

                c.AddNextExpectedOutput(Direction.Right, save);
                c.AddNextExpectedOutput(Direction.Right, save2);
                c.AddNextExpectedOutput(Direction.Right, save3);

            }
        }

        public static void Check3(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 3);
                int r2 = random.Next(0, 3);
                int r3 = random.Next(0, 3);

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);
                c.AddNextInput(Direction.Left, r3);

                if (r == r2 && r == r3)
                {
                    c.AddNextExpectedOutput(Direction.Right, r);
                }
                else if (r != 0 && r2 != 0 && r3 != 0)
                {
                    c.AddNextExpectedOutput(Direction.Right, 3);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, 0);
                }
                

            }
        }

        public static void CheckForDiagonals(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 3);
                int r2 = random.Next(0, 3);
                int r3 = random.Next(0, 3);
                int r4 = random.Next(0, 3);
                int r5 = random.Next(0, 3);
                int r6 = random.Next(0, 3);
                int r7 = random.Next(0, 3);
                int r8 = random.Next(0, 3);
                int r9 = random.Next(0, 3);

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);
                c.AddNextInput(Direction.Left, r3);
                c.AddNextInput(Direction.Left, r4);
                c.AddNextInput(Direction.Left, r5);
                c.AddNextInput(Direction.Left, r6);
                c.AddNextInput(Direction.Left, r7);
                c.AddNextInput(Direction.Left, r8);
                c.AddNextInput(Direction.Left, r9);

                if (r3 == r5 && r3 == r7)
                {
                    c.AddNextExpectedOutput(Direction.Right, r3);
                }
                else if (r3 != 0 && r5 != 0 && r7 != 0)
                {
                    c.AddNextExpectedOutput(Direction.Right, 3);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, 0);
                }

                if (r == r5 && r == r9)
                {
                    c.AddNextExpectedOutput(Direction.Right, r);
                }
                else if (r != 0 && r5 != 0 && r9 != 0)
                {
                    c.AddNextExpectedOutput(Direction.Right, 3);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, 0);
                }

            }
        }

        public static void CheckForEnd(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                List<int> list = new List<int>();

                int[] r = new int[8];

                for (int j = 0; j < r.Length; j++ )
                {
                    r[j] = random.Next(-10, 14);
                    if (r[j] < 0)
                    {
                        r[j] = 0;
                    }
                    if (r[j] > 3)
                    {
                        r[j] = 3;
                    }
                    list.Add(r[j]);
                    if (j < 6)
                    {
                        c.AddNextInput(Direction.Left, r[j]);
                    }
                    else
                    {
                        c.AddNextInput(Direction.Up, r[j]);
                    }
                }
                


                if (list.Contains(2))
                {
                    c.AddNextExpectedOutput(Direction.Right, 2);
                }
                else if (list.Contains(1))
                {
                    c.AddNextExpectedOutput(Direction.Right, 1);
                }
                else if (list.Contains(0))
                {
                    c.AddNextExpectedOutput(Direction.Right, 0);
                }
                else if (list.Contains(3))
                {
                    c.AddNextExpectedOutput(Direction.Right, 3);
                }

            }
        }

        public static void CheckForLines(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(0, 3);
                int r2 = random.Next(0, 3);
                int r3 = random.Next(0, 3);
                int r4 = random.Next(0, 3);
                int r5 = random.Next(0, 3);
                int r6 = random.Next(0, 3);
                int r7 = random.Next(0, 3);
                int r8 = random.Next(0, 3);
                int r9 = random.Next(0, 3);

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);
                c.AddNextInput(Direction.Left, r3);
                c.AddNextInput(Direction.Left, r4);
                c.AddNextInput(Direction.Left, r5);
                c.AddNextInput(Direction.Left, r6);
                c.AddNextInput(Direction.Left, r7);
                c.AddNextInput(Direction.Left, r8);
                c.AddNextInput(Direction.Left, r9);

                if (r == r4 && r == r7)
                {
                    c.AddNextExpectedOutput(Direction.Right, r);
                }
                else if (r != 0 && r4 != 0 && r7 != 0)
                {
                    c.AddNextExpectedOutput(Direction.Right, 3);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, 0);
                }

                if (r2 == r5 && r2 == r8)
                {
                    c.AddNextExpectedOutput(Direction.Right, r2);
                }
                else if (r2 != 0 && r5 != 0 && r8 != 0)
                {
                    c.AddNextExpectedOutput(Direction.Right, 3);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, 0);
                }

                if (r3 == r6 && r3 == r9)
                {
                    c.AddNextExpectedOutput(Direction.Right, r3);
                }
                else if (r3 != 0 && r6 != 0 && r9 != 0)
                {
                    c.AddNextExpectedOutput(Direction.Right, 3);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, 0);
                }

                if (r == r2 && r == r3)
                {
                    c.AddNextExpectedOutput(Direction.Right, r);
                }
                else if (r != 0 && r2 != 0 && r3 != 0)
                {
                    c.AddNextExpectedOutput(Direction.Right, 3);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, 0);
                }

                if (r4 == r5 && r4 == r6)
                {
                    c.AddNextExpectedOutput(Direction.Right, r4);
                }
                else if (r4 != 0 && r5 != 0 && r6 != 0)
                {
                    c.AddNextExpectedOutput(Direction.Right, 3);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, 0);
                }

                if (r7 == r8 && r7 == r9)
                {
                    c.AddNextExpectedOutput(Direction.Right, r7);
                }
                else if (r7 != 0 && r8 != 0 && r9 != 0)
                {
                    c.AddNextExpectedOutput(Direction.Right, 3);
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, 0);
                }

            }
        }

        public static void GetPlayer(ComputeController c, int amount)
        {
            Random random = new Random();

            int player = 0;
            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(-5, 2);
                if (r < 0)
                {
                    r = 0;
                }

                if (r > 0)
                {
                    player = 0;
                }
                else
                {
                    player++;
                    if (player == 3)
                    {
                        player = 1;
                    }
                }

                c.AddNextInput(Direction.Left, r);

                c.AddNextExpectedOutput(Direction.Right, player);


            }
        }

        public static void PriorityUp(ComputeController c, int amount)
        {
            Random random = new Random();

            for (int i = 0; i < amount; i++)
            {

                int r = random.Next(0, 4);
                int r2 = random.Next(0, 4);

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);



                if (r == 2 || (r == 1 && r2 != 2) || (r == 0 && r2 == 3))
                {
                    c.AddNextExpectedOutput(Direction.Up, r);
                    c.AddNextExpectedOutput(Direction.Down, r2);
                }
                else 
                {
                    c.AddNextExpectedOutput(Direction.Up, r2);
                    c.AddNextExpectedOutput(Direction.Down, r);
                }
               

            }
        }

        public static void ResetIfEnd(ComputeController c, int amount)
        {
            Random random = new Random();

            int[] lastsave = new int[9];
            int player = 0;
            for (int i = 0; i < amount; i++)
            {
                player++;
                if (player == 3)
                {
                    player = 1;
                }
                int r = random.Next(1, 10);

                c.AddNextInput(Direction.Left, r);

                if (lastsave[r-1] == 0)
                {
                    bool win = false;
                    lastsave[r-1] = player;
                    if (lastsave[0] != 0 && lastsave[0] == lastsave[1] && lastsave[0] == lastsave[2])
                    {
                        c.AddNextExpectedOutput(Direction.Right, lastsave[0]);
                        win = true;
                    }
                    else if (lastsave[3] != 0 && lastsave[3] == lastsave[4] && lastsave[3] == lastsave[5])
                    {
                        c.AddNextExpectedOutput(Direction.Right, lastsave[3]);
                        win = true;
                    }
                    else if (lastsave[6] != 0 && lastsave[6] == lastsave[7] && lastsave[6] == lastsave[8])
                    {
                        c.AddNextExpectedOutput(Direction.Right, lastsave[6]);
                        win = true;
                    }
                    else if (lastsave[0] != 0 && lastsave[0] == lastsave[3] && lastsave[0] == lastsave[6])
                    {
                        c.AddNextExpectedOutput(Direction.Right, lastsave[0]);
                        win = true;
                    }
                    else if (lastsave[1] != 0 && lastsave[1] == lastsave[4] && lastsave[1] == lastsave[7])
                    {
                        c.AddNextExpectedOutput(Direction.Right, lastsave[1]);
                        win = true;
                    }
                    else if (lastsave[2] != 0 && lastsave[2] == lastsave[5] && lastsave[2] == lastsave[8])
                    {
                        c.AddNextExpectedOutput(Direction.Right, lastsave[2]);
                        win = true;
                    }
                    else if (lastsave[0] != 0 && lastsave[0] == lastsave[4] && lastsave[0] == lastsave[8])
                    {
                        c.AddNextExpectedOutput(Direction.Right, lastsave[0]);
                        win = true;
                    }
                    else if (lastsave[2] != 0 && lastsave[2] == lastsave[4] && lastsave[2] == lastsave[6])
                    {
                        c.AddNextExpectedOutput(Direction.Right, lastsave[2]);
                        win = true;
                    }
                    else if (lastsave[0] != 0 && lastsave[1] != 0 && lastsave[2] != 0 && lastsave[3] != 0 && lastsave[4] != 0 && lastsave[5] != 0 && lastsave[6] != 0 && lastsave[7] != 0 && lastsave[8] != 0)
                    {
                        c.AddNextExpectedOutput(Direction.Right, 3);
                        win = true;
                    }
                    else
                    {
                        c.AddNextExpectedOutput(Direction.Right, 0);
                    }
                    if (win)
                    {
                        player = 0;
                        lastsave = new int[9];
                    }
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, -1);
                    player--;
                }

            }
        }

        public static void Savebank9(ComputeController c, int amount)
        {
            Random random = new Random();

            int[] lastsave = new int[9];
            for (int i = 0; i < amount; i++)
            {

                int r = random.Next(1, 10);
                int r2 = random.Next(0, 100);
                int r3 = random.Next(0, 2);

                c.AddNextInput(Direction.Left, r);



                if (r3 == 0)
                {
                    c.AddNextInput(Direction.Left, r2);
                }
                else
                {
                    c.AddNextInput(Direction.Up, r2);
                    lastsave[r - 1] = r2;
                }

                c.AddNextExpectedOutput(Direction.Right, lastsave[r - 1]);

            }
        }

        public static void SaveWithError(ComputeController c, int amount)
        {
            Random random = new Random();

            int[] lastsave = new int[9];
            for (int i = 0; i < amount; i++)
            {

                int r = random.Next(1, 10);
                int r2 = random.Next(0, 3);
                int r3 = random.Next(0, 2);
                int erg = 0;

                c.AddNextInput(Direction.Left, r);



                if (r3 == 0)
                {
                    c.AddNextInput(Direction.Left, r2);
                    erg = lastsave[r - 1];
                }
                else
                {
                    c.AddNextInput(Direction.Up, r2);
                    if (lastsave[r - 1] > 0 && r2 != 0)
                    {
                        erg = -1;
                    }
                    else
                    {
                        lastsave[r - 1] = r2;
                        erg = lastsave[r - 1];
                    }
                }

                c.AddNextExpectedOutput(Direction.Right, erg);

            }
        }

        public static void SaveWithReset(ComputeController c, int amount)
        {
            Random random = new Random();

            int[] lastsave = new int[9];
            for (int i = 0; i < amount; i++)
            {

                int r = random.Next(1, 10);
                int r2 = random.Next(0, 3);
                int r3 = random.Next(0, 2);
                //reset about every 30 circles
                if (random.Next(0, 30) == 0)
                {
                    r = 0;
                }
                int erg = 0;

                c.AddNextInput(Direction.Left, r);

                if (r == 0)
                {
                    c.AddNextInput(Direction.Left, 0);
                    erg = -1;
                    lastsave = new int[9];
                }
                else
                {
                    if (r3 == 0)
                    {
                        c.AddNextInput(Direction.Left, r2);
                        erg = lastsave[r - 1];
                    }
                    else
                    {
                        c.AddNextInput(Direction.Up, r2);
                        if (lastsave[r - 1] > 0 && r2 != 0)
                        {
                            erg = -1;
                        }
                        else
                        {
                            lastsave[r - 1] = r2;
                            erg = lastsave[r - 1];
                        }
                    }
                }

                c.AddNextExpectedOutput(Direction.Right, erg);

            }
        }

        public static void WriteRead9(ComputeController c, int amount)
        {
            Random random = new Random();

            int[] lastsave = new int[9];
            bool end = false;
            for (int i = 0; i < amount; i++)
            {
                int r = random.Next(1, 10);
                int r2 = random.Next(1, 3);

                //reset about every 30 circles
                if (random.Next(0, 30) == 0 || end)
                {
                    r = 0;
                    end = false;
                }

                c.AddNextInput(Direction.Left, r);
                c.AddNextInput(Direction.Left, r2);

                if (r == 0)
                {
                    lastsave = new int[9];
                    c.AddNextExpectedOutput(Direction.Right, -1);
                }
                else if (lastsave[r-1] == 0)
                {
                    end = true;
                    lastsave[r-1] = r2;
                    if (lastsave[0] != 0 && lastsave[0] == lastsave[1] && lastsave[0] == lastsave[2])
                    {
                        c.AddNextExpectedOutput(Direction.Right, lastsave[0]);
                    }
                    else if (lastsave[3] != 0 && lastsave[3] == lastsave[4] && lastsave[3] == lastsave[5])
                    {
                        c.AddNextExpectedOutput(Direction.Right, lastsave[3]);
                    }
                    else if (lastsave[6] != 0 && lastsave[6] == lastsave[7] && lastsave[6] == lastsave[8])
                    {
                        c.AddNextExpectedOutput(Direction.Right, lastsave[6]);
                    }
                    else if (lastsave[0] != 0 && lastsave[0] == lastsave[3] && lastsave[0] == lastsave[6])
                    {
                        c.AddNextExpectedOutput(Direction.Right, lastsave[0]);
                    }
                    else if (lastsave[1] != 0 && lastsave[1] == lastsave[4] && lastsave[1] == lastsave[7])
                    {
                        c.AddNextExpectedOutput(Direction.Right, lastsave[1]);
                    }
                    else if (lastsave[2] != 0 && lastsave[2] == lastsave[5] && lastsave[2] == lastsave[8])
                    {
                        c.AddNextExpectedOutput(Direction.Right, lastsave[2]);
                    }
                    else if (lastsave[0] != 0 && lastsave[0] == lastsave[4] && lastsave[0] == lastsave[8])
                    {
                        c.AddNextExpectedOutput(Direction.Right, lastsave[0]);
                    }
                    else if (lastsave[2] != 0 && lastsave[2] == lastsave[4] && lastsave[2] == lastsave[6])
                    {
                        c.AddNextExpectedOutput(Direction.Right, lastsave[2]);
                    }
                    else if (lastsave[0] != 0 && lastsave[1] != 0 && lastsave[2] != 0 && lastsave[3] != 0 && lastsave[4] != 0 && lastsave[5] != 0 && lastsave[6] != 0 && lastsave[7] != 0 && lastsave[8] != 0)
                    {
                        c.AddNextExpectedOutput(Direction.Right, 3);
                    }
                    else
                    {
                        c.AddNextExpectedOutput(Direction.Right, 0);
                        end = false;
                    }
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, -1);
                }

            }
        }

        public static void TicTacToe(ComputeController c, int amount)
        {
            Random random = new Random();

            int[] lastsave = new int[9];
            int player = 0;
            for (int i = 0; i < amount; i++)
            {
                player++;
                if (player == 3)
                {
                    player = 1;
                }
                int r2 = random.Next(1, 4);
                int r3 = random.Next(1, 4);
                int r = (r2 - 1) * 3 + r3 - 1;

                c.AddNextInput(Direction.Left, r2);
                c.AddNextInput(Direction.Left, r3);

                if (lastsave[r] == 0)
                {
                    bool win = false;
                    lastsave[r] = player;
                    if (lastsave[0] != 0 && lastsave[0] == lastsave[1] && lastsave[0] == lastsave[2])
                    {
                        c.AddNextExpectedOutput(Direction.Right, lastsave[0]);
                        win = true;
                    }
                    else if (lastsave[3] != 0 && lastsave[3] == lastsave[4] && lastsave[3] == lastsave[5])
                    {
                        c.AddNextExpectedOutput(Direction.Right, lastsave[3]);
                        win = true;
                    }
                    else if (lastsave[6] != 0 && lastsave[6] == lastsave[7] && lastsave[6] == lastsave[8])
                    {
                        c.AddNextExpectedOutput(Direction.Right, lastsave[6]);
                        win = true;
                    }
                    else if (lastsave[0] != 0 && lastsave[0] == lastsave[3] && lastsave[0] == lastsave[6])
                    {
                        c.AddNextExpectedOutput(Direction.Right, lastsave[0]);
                        win = true;
                    }
                    else if (lastsave[1] != 0 && lastsave[1] == lastsave[4] && lastsave[1] == lastsave[7])
                    {
                        c.AddNextExpectedOutput(Direction.Right, lastsave[1]);
                        win = true;
                    }
                    else if (lastsave[2] != 0 && lastsave[2] == lastsave[5] && lastsave[2] == lastsave[8])
                    {
                        c.AddNextExpectedOutput(Direction.Right, lastsave[2]);
                        win = true;
                    }
                    else if (lastsave[0] != 0 && lastsave[0] == lastsave[4] && lastsave[0] == lastsave[8])
                    {
                        c.AddNextExpectedOutput(Direction.Right, lastsave[0]);
                        win = true;
                    }
                    else if (lastsave[2] != 0 && lastsave[2] == lastsave[4] && lastsave[2] == lastsave[6])
                    {
                        c.AddNextExpectedOutput(Direction.Right, lastsave[2]);
                        win = true;
                    }
                    else if (lastsave[0] != 0 && lastsave[1] != 0 && lastsave[2] != 0 && lastsave[3] != 0 && lastsave[4] != 0 && lastsave[5] != 0 && lastsave[6] != 0 && lastsave[7] != 0 && lastsave[8] != 0)
                    {
                        c.AddNextExpectedOutput(Direction.Right, 3);
                        win = true;
                    }
                    else
                    {
                        c.AddNextExpectedOutput(Direction.Right, 0);
                    }
                    if (win)
                    {
                        player = 0;
                        lastsave = new int[9];
                    }
                }
                else
                {
                    c.AddNextExpectedOutput(Direction.Right, -1);
                    player--;
                }

            }
        }

        public static void Custom(ComputeController c, int amount)
        {
            Random random = new Random();
            for (int i = 0; i < amount; i++)
            {
                for (int j = 0; j < c.Events.Owner.Rootplace.InputCount; j++)
                {
                    int r = random.Next(0, 100);

                    c.AddNextInput(c.Events.Owner.Rootplace.InputDirections[j], r);
                }

                for (int j = 0; j < c.Events.Owner.Rootplace.OutputCount; j++)
                {
                    int r = random.Next(0, 100);

                    c.AddNextExpectedOutput(c.Events.Owner.Rootplace.OutputDirections[j], r);
                }

            }
        }


    }
}
