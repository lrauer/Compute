﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Testinterface
{
    public partial class LevelSelectForm : Form
    {
        public ComputeUIForm CurrentLevel;

        public LevelSelectForm()
        {
            InitializeComponent();
            listBox1.SelectedIndex = 0;
            listBox2.SelectedIndex = 0;

        }

        public void loadLevel(string level)
        {
            if (CurrentLevel != null)
            {
                CurrentLevel.Close();
            }
            CurrentLevel = new ComputeUIForm(level, true, label1.Text, null, 0, 0);
            CurrentLevel.Show();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            label1.Text = listBox1.Text;
            label2.Text = Levels.getDescription(listBox1.Text);
            label2.Text += Environment.NewLine + Environment.NewLine;

            StreamReader sr = new StreamReader(System.Environment.CurrentDirectory + @"\saves\" + listBox1.Text + ".xml");
            string s;
            List<string> erg = new List<string>();

            while(!sr.EndOfStream)
            {
                s = sr.ReadLine();
                if(s.Contains("<Name>"))
                {
                    erg.Add(s.Substring(s.IndexOf("<Name>") + 6, s.IndexOf("</Name>") - s.IndexOf("<Name>") - 6));
                }
            }
            erg.RemoveAt(0);
            
            if(erg.Count > 0)
            {
                label2.Text += "Examplesolution uses:";
                foreach (string s2 in erg.Distinct())
                {
                    label2.Text += " " + s2;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox2.SelectedIndex == 0)
            {
                loadLevel(label1.Text);
            }
            else
            {
                loadLevel(label1.Text + listBox2.SelectedIndex);
            }
        }
    }
}
