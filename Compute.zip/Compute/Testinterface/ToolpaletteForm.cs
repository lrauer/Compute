﻿using Compute;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Testinterface
{
    public partial class ToolpaletteForm : Form
    {

        ComputeUIForm parent;

        public ToolpaletteForm(ComputeUIForm parent)
        {
            InitializeComponent();
            this.parent = parent;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            parent.action = listBox1.SelectedIndex;
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (listBox2.SelectedIndex)
            {
                case 0:
                    parent.direction = Direction.Right;
                    break;
                case 1:
                    parent.direction = Direction.Left;
                    break;
                case 2:
                    parent.direction = Direction.Up;
                    break;
                case 3:
                    parent.direction = Direction.Down;
                    break;
            }
        }

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (listBox3.SelectedIndex)
            {
                case 0:
                    parent.altdirection = Direction.Right;
                    break;
                case 1:
                    parent.altdirection = Direction.Left;
                    break;
                case 2:
                    parent.altdirection = Direction.Up;
                    break;
                case 3:
                    parent.altdirection = Direction.Down;
                    break;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            parent.loadname = textBox1.Text;
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            parent.value = (int)numericUpDown1.Value;
        }
    }
}
