﻿namespace Testinterface
{
    partial class LevelSelectForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Items.AddRange(new object[] {
            "1Straight",
            "2TurnRight",
            "3Straight2D",
            "4TurnLeftAllSides",
            "5StraightTurn",
            "6Straight4D",
            "7Computer",
            "8+Add5Big",
            "8Add5Small",
            "9Alternate",
            "10Swap",
            "11ReadDirection",
            "12+RRRL",
            "12ReadDirectionAll",
            "13NOT",
            "14NOTNoIncrementer",
            "15OR",
            "16AND",
            "17XOR",
            "18+Split",
            "18ADD",
            "19SUB",
            "20+PositiveCopy",
            "20PositiveCopyUpDown",
            "21Identical",
            "22+DoubleInOut",
            "22IdenticalOut",
            "23Alternate3Way",
            "24+AlternateAll",
            "24Alternate4Way",
            "25+Straight2I",
            "25Sync",
            "26Greater5",
            "27PositiveGreaterThan",
            "28GreaterUp",
            "29PositiveNegative",
            "30Multiply3",
            "31ChangeSign",
            "32Divide2",
            "33Multiply",
            "34RaisePower",
            "35Divide",
            "36Combine",
            "37TakeApart",
            "38Lowest",
            "39Average",
            "40Sort",
            "41+Split4",
            "41Sort5",
            "42Memory",
            "43Memory2Bit",
            "44+Combine4",
            "44+Divide10",
            "44+SplitAngle",
            "44Memory4Bit",
            "45+Memory8Bit",
            "45+ToBase2",
            "45+ToBase10",
            "45MemoryBase10",
            "46+Invert1Bit",
            "46+Reverse",
            "46Invert8Bit",
            "47Add3Circles",
            "48+CurrentCircle",
            "48Fibonacci",
            "49+AlternateSwitched",
            "49+DDRRR",
            "49+Multiply-1",
            "49+Savebank",
            "49Movement3D",
            "50+Check3",
            "50+CheckForDiagonals",
            "50+CheckForEnd",
            "50+CheckForLines",
            "50+GetPlayer",
            "50+PriorityUp",
            "50+ResetIfEnd",
            "50+Savebank9",
            "50+SaveWithError",
            "50+SaveWithReset",
            "50+WriteRead9",
            "50TicTacToe",
            "99test"});
            this.listBox1.Location = new System.Drawing.Point(12, 12);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(173, 324);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(360, 295);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(160, 41);
            this.button1.TabIndex = 1;
            this.button1.Text = "Load Level";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(360, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 62);
            this.label1.TabIndex = 2;
            this.label1.Text = "label1";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 16;
            this.listBox2.Items.AddRange(new object[] {
            "ExampleSolution",
            "Slot1",
            "Slot2",
            "Slot3"});
            this.listBox2.Location = new System.Drawing.Point(191, 12);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(109, 84);
            this.listBox2.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(191, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(485, 169);
            this.label2.TabIndex = 4;
            this.label2.Text = "label2";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(688, 366);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.listBox1);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Label label2;
    }
}