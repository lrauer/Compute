﻿using Compute;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Testinterface
{
    public partial class ComputeUIForm : Form
    {

        ComputeController c;
        Label[,] grid;
        List<String> inputs;
        List<String> outputs;

        bool updating = true;

        ComputeUIForm parent;
        int posX;
        int posY;

        string ValidationName;

        public ComputeUIForm(string name, bool load, string validationname, ComputeUIForm parent, int posX, int posY)
        {
            InitializeComponent();

            grid = new Label[11, 33];

            // label1
            System.Windows.Forms.Label label1;
            for (int i = 0; i < 11; i++)
            {
                for (int j = 0; j < 33; j++)
                {
                    label1 = new System.Windows.Forms.Label();
                    grid[i, j] = label1;
                    label1.Dock = System.Windows.Forms.DockStyle.None;
                    label1.AutoSize = false;
                    label1.Click += LabelClick;
                    //create 3 objekts for the lines to avoid large line spacing
                    int k = j / 3;
                    label1.Font = new System.Drawing.Font("Courier New", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    label1.Location = new System.Drawing.Point(37 * i, 14 * j + k*3);
                    label1.Name = "label1";
                    label1.Size = new System.Drawing.Size(37, 14);
                    label1.TabIndex = 2;
                    label1.Text = "   ";
                    panel1.Controls.Add(label1);
                }
            }

            this.parent = parent;
            this.posX = posX;
            this.posY = posY;

            c = new ComputeController(name, true, false,false);

            //create a new system with the name or a copy if name is in use
            if (!load)
            {
                c.Events.Owner.Rootplace.Name = SaveLoadManager.GetAvailableName(name, c.Events.Owner.savepath, false);
            }

            //SaveLoadManager.saveRootplace(c.Events.Owner.Rootplace.Name, c.Events.Owner, false);

            //set the metadata for the rootplace
            //c.SetRootplaceBoundaries(2, 2, new Direction[] { Direction.Left, Direction.Left }, new Direction[] { Direction.Right }, 2, 1);

            //add initial objects for testing (if not loaded)
            //c.AddSwitch(-2, 0, Direction.Down, Direction.Right);
            //c.AddConveyorBelt(-1, -1, Direction.Down);
            //c.AddConveyorBelt(-1, -2, Direction.Right);

            //react to updates
            c.Events.SystemLayoutChanged += HandlePosition;
            c.Events.SystemStateChanged += HandlePosition;
            c.Events.SystemMemoryChanged += HandlePosition;
            c.Events.SystemLayoutChanged += HandleLayout;
            c.Events.MoveablePositionChanged += HandlePosition;
            c.Events.MoveableBeginMove += HandleMoveBegin;
            //c.Events.MoveableEndMove += HandleMoveEnd;
            //c.Events.MoveableValueChanged += HandleValue;
            c.Events.SystemOutput += HandleOutput;
            c.Events.SystemInput += HandleInput;
            c.Events.InputReceived += HandleInputAdd;
            c.Events.OutputReceived += HandleOutputAdd;
            c.Events.RunBegin += HandleRunBegin;
            c.Events.ExecuteFailed += HandleError;
            c.Events.ExecuteFinished += HandleFinished;
            c.Events.ExecuteCompleted += HandleCompleted;
            c.Events.ExecuteCircleFinished += HandleCircleFinished;
            c.Events.SystemResetted += HandleResetted;

            ValidationName = validationname;

            //add in/outputs
            AddInputs();

            //draw initial objects and inputs
            Initialize();

            this.Text = name;
        }

        public void AddInputs()
        {
            //amount of circles to test the system
            int circleamount = 5000;

            progressBar1.Value = 0;
            progressBar1.Maximum = circleamount;
            label4.Text = progressBar1.Value + "/" + circleamount;

            //create inputs & outputs
            inputs = new List<string>();
            outputs = new List<string>();
            Levels.FillInputs(c, ValidationName, circleamount);
        }

        public int action = 0;
        public Direction direction = Direction.Right;
        public Direction altdirection = Direction.Right;
        public int value = 0;
        public string loadname = "";

        int connectX = -100;
        int connectY = -100;

        private void LabelClick(object sender, EventArgs e)
        {
            if (c.Events.Owner.IsReady())
            {
                int x = 0;
                int y = 0;
                for (int i = 0; i < 11; i++)
                {
                    for (int j = 0; j < 33; j++)
                    {
                        if (grid[i, j] == sender)
                        {
                            x = i - 5;
                            y = -1 * (j / 3 - 5);
                            break;
                        }
                    }
                }
                switch (action)
                {
                    case 0:
                        c.AddConveyorBelt(x, y, direction);
                        break;
                    case 1:
                        c.DeleteAtPosition(x, y);
                        break;
                    case 2:
                        c.AddIncrementer(x, y, direction);
                        break;
                    case 3:
                        c.AddDecrementer(x, y, direction);
                        break;
                    case 4:
                        c.AddDestructor(x, y);
                        break;
                    case 5:
                        c.AddHolder(x, y, direction);
                        break;
                    case 6:
                        c.AddLever(x, y, direction);
                        break;
                    case 7:
                        c.AddSwitch(x, y, direction, altdirection);
                        break;
                    case 8:
                        c.AddMover(x, y);
                        break;
                    case 9:
                        //c.AddJumper(x, y, x, y);
                        break;
                    case 10:
                        c.AddComparer(x, y, direction, altdirection, value);
                        break;
                    case 11:
                        c.AddCreator(x, y, direction, value);
                        break;
                    case 12:
                        if(connectX == -100)
                        {
                            connectX = x;
                            connectY = y;
                        }
                        else
                        {
                            c.Connect(connectX, connectY, x, y);
                            connectX = -100;
                            connectY = -100;
                        }
                        break;
                    case 13:
                        c.TurnAround(x, y, 1);
                        break;
                    case 14:
                        c.LoadComputerByName(x, y, loadname);
                        break;
                    case 15:
                        if (connectX == -100)
                        {
                            connectX = x;
                            connectY = y;
                        }
                        else
                        {
                            c.CopyPasteObjekt(connectX, connectY, x, y, false);
                            connectX = -100;
                            connectY = -100;
                        }
                        break;
                    case 16:
                        if (connectX == -100)
                        {
                            connectX = x;
                            connectY = y;
                        }
                        else
                        {
                            c.ChangePosition(connectX, connectY, x, y, false);
                            connectX = -100;
                            connectY = -100;
                        }
                        break;
                    case 17:
                        Place p = c.GetObjectAt(x, y) as Place;
                        if (p != null)
                        {
                            ComputeUIForm child = new ComputeUIForm(p.Name, false, p.Name, this, x, y);
                            child.Show();
                        }
                        break;
                    case 18:
                        c.AddComputer(x, y, SaveLoadManager.GetAvailableName("NewSystem", c.Events.Owner.savepath, false), new Direction[] { Direction.Left }, new Direction[] { Direction.Right }, 1, 1);
                        break;
                    case 19:
                        c.AddCopier(x, y, direction, altdirection);
                        break;
                    case 20:
                        c.AddMelter(x, y, direction);
                        break;
                    case 21:
                        c.AddAdder(x, y, direction);
                        break;
                    case 22:
                        c.AddSubber(x, y, direction);
                        break;
                    case 23:
                        c.AddMultiplier(x, y, direction);
                        break;
                    case 24:
                        c.AddDivider(x, y, direction, altdirection);
                        break;
                    case 25:
                        c.AddMemory(x, y, direction);
                        break;
                    case 26:
                        c.AddIdenticalTester(x, y, direction);
                        break;
                    case 27:
                        c.AddGreaterThanTester(x, y, direction);
                        break;
                    case 28:
                        c.AddSplitter(x, y, direction, altdirection);
                        break;
                    case 29:
                        c.AddAlternator(x, y, direction, altdirection);
                        break;
                    case 30:
                        if (connectX == -100)
                        {
                            connectX = x;
                            connectY = y;
                        }
                        else
                        {
                            c.SwapPosition(connectX, connectY, x, y);
                            connectX = -100;
                            connectY = -100;
                        }
                        break;
                    case 31:
                        if (connectX == -100)
                        {
                            connectX = x;
                            connectY = y;
                        }
                        else
                        {
                            c.CopyPasteObjekt(connectX, connectY, x, y, true);
                            connectX = -100;
                            connectY = -100;
                        }
                        break;
                }
                
            }
        }

        DateTime starttime;

        public void HandleRunBegin(object sender, SystemStateEventArgs eventArg)
        {
            progressBar1.Visible = true;
            label4.Visible = true;
            starttime = DateTime.Now;
        }

        public void HandleError(object sender, SystemStateFailedEventArgs eventArgs)
        {
            string s;
            if (eventArgs.ErrorPosition() == null)
            {
               s = "global";
            }
            else
            {
              s =  eventArgs.ErrorPosition().ToString();
            }
            label1.Text = "Systemstate: " + eventArgs.State + "\r\n(" + eventArgs.Errormessage() + " " + s + ")";
            label1.ForeColor = Color.Red;
            autorun = 0;
        }

        public void HandleFinished(object sender, SystemStateEventArgs eventArgs)
        {
            label1.Text = "Systemstate: " + eventArgs.State;
            label1.ForeColor = Color.Blue;
        }

        public void HandleCompleted(object sender, SystemCompletionEventArgs eventArgs)
        {
            progressBar1.PerformStep();
            autorun = 0;
            label1.Text = "Systemstate: " + eventArgs.State;
            if (eventArgs.RunStatistics.AllCorrect())
            {
                label1.ForeColor = Color.Green;
            }
            else
            {
                label1.ForeColor = Color.Red;
            }
            MessageBox.Show("Turns taken: " + eventArgs.RunStatistics.Steps + " (" + eventArgs.RunStatistics.StepsPerCircle() + " per circle , min/max: "+eventArgs.RunStatistics.MinSteps+"/"+ eventArgs.RunStatistics.MaxSteps + ")\r\nElements used: " + eventArgs.RunStatistics.Objects + "\r\nSpace Taken: " + eventArgs.RunStatistics.Space + "\r\nDistance Traveled: " + eventArgs.RunStatistics.DistanceTraveled + " (" + eventArgs.RunStatistics.DistancePerCircle() + " per circle , min/max: " + eventArgs.RunStatistics.MinDistanceTraveled + "/" + eventArgs.RunStatistics.MaxDistanceTraveled + ")\r\nRealtime since Run started: " + DateTime.Now.Subtract(starttime));
            progressBar1.Visible = false;
            label4.Visible = false;
        }

        public void HandleCircleFinished(object sender, SystemStateEventArgs eventArgs)
        {
            progressBar1.PerformStep();
            label4.Text = progressBar1.Value + "/" + progressBar1.Maximum;

            waittimer *= 9;
            waittimer /= 10;
        }

        public void HandleResetted(object sender, SystemStateEventArgs eventArgs)
        {
            label1.Text = "Systemstate: " + eventArgs.State;
            label1.ForeColor = Color.Black;
        }

        public void HandleOutputAdd(object sender, QueueEventArgs eventArgs)
        {
            outputs.Add(" " + eventArgs.EventOrder.Objekt.Value + " " +eventArgs.EventOrder.Order);
        }

        public void HandleInputAdd(object sender, QueueEventArgs eventArgs)
        {
            inputs.Add(" " + eventArgs.EventOrder.Objekt.Value + " " + eventArgs.EventOrder.Order);
        }

        public void HandleOutput(object sender, QueueValidationEventArgs eventArgs)
        {
            if (eventArgs.Correct())
            {
                outputs[eventArgs.CurrentPosition()] = "G" + outputs[eventArgs.CurrentPosition()].Substring(1);
            }
            else
            {
                outputs[eventArgs.CurrentPosition()] = "R" + outputs[eventArgs.CurrentPosition()].Substring(1);
            }
            UpdateOutputs();
            //mark all current inputs as completed
            for (int i = 0; i < inputs.Count; i++)
            {
                if (inputs[i][0] == 'B')
                {
                    inputs[i] = 'G' + inputs[i].Substring(1);
                }
            }
            UpdateInputs();
        }

        public void UpdateOutputs()
        {
            if (updating)
            {
                richTextBox1.Text = "";
                for (int i = 0; i < outputs.Count; i++)
                {
                    richTextBox1.Select(richTextBox1.TextLength, 0);
                    if (outputs[i][0] == 'R')
                    {
                        richTextBox1.SelectionColor = Color.Red;
                    }
                    else if (outputs[i][0] == 'G')
                    {
                        richTextBox1.SelectionColor = Color.Green;
                    }
                    else
                    {
                        richTextBox1.SelectionColor = Color.Black;
                    }
                    richTextBox1.AppendText(outputs[i].Substring(1));
                    //dont redraw all outputs cause it takes too long
                    if (i > 100)
                    {
                        break;
                    }
                    richTextBox1.AppendText("\r\n");
                }
            }
        }

        public void HandleInput(object sender, QueueEventArgs eventArgs)
        {
            inputs[eventArgs.CurrentPosition()] = "B" + inputs[eventArgs.CurrentPosition()].Substring(1);
            UpdateInputs();
        }

        public void UpdateInputs()
        {
            if (updating)
            {
                richTextBox2.Text = "";
                for (int i = 0; i < inputs.Count; i++)
                {
                    richTextBox2.Select(richTextBox2.TextLength, 0);
                    if (inputs[i][0] == 'B')
                    {
                        richTextBox2.SelectionColor = Color.Blue;
                    }
                    else if (inputs[i][0] == 'G')
                    {
                        richTextBox2.SelectionColor = Color.Gray;
                    }
                    else
                    {
                        richTextBox2.SelectionColor = Color.Black;
                    }
                    //dont redraw all inputs cause it takes too long
                    if (i > 100)
                    {
                        break;
                    }
                    richTextBox2.AppendText(inputs[i].Substring(1) + "\r\n");
                }
            }
        }

        public void HandlePosition(object sender, PositionEventArgs eventArgs)
        {
            //update old and new location of the object

            //if no position specified the whole system changed
            if (eventArgs.OwnerType == Objektname.Root)
            {
                Initialize();
            }
            //if new position is in rootplace update the new location
            if (eventArgs.InRootPlace(false))
            {
                //new position gets passed the object (moveable/placeableobject)
                if (eventArgs.OwnerType == Objektname.Moveable)
                {
                    UpdateText(eventArgs.NewPositionX, eventArgs.NewPositionY, c.GetInputAt(eventArgs.NewPositionX, eventArgs.NewPositionY));
                }
                else
                {
                    UpdateText(eventArgs.NewPositionX, eventArgs.NewPositionY, c.GetObjectAt(eventArgs.NewPositionX, eventArgs.NewPositionY));
                }
            }
            //if old position is in rootplace update the old location except if old and new position are identical
            if (eventArgs.InRootPlace(true) && (eventArgs.OldPositionX != eventArgs.NewPositionX || eventArgs.OldPositionY != eventArgs.NewPositionY || eventArgs.OldPositionParent != eventArgs.NewPositionParent))
            {
                //old position gets passed the placeableobject
                UpdateText(eventArgs.OldPositionX, eventArgs.OldPositionY, c.GetObjectAt(eventArgs.OldPositionX, eventArgs.OldPositionY));
            } 
        }

        public void HandleMoveBegin(object sender, MoveOrderEventArgs eventArgs)
        {
            if (autorun > 0 && waittimer > 20 && !completeRun)
            {
                //create moving object (animation)
                System.Windows.Forms.Label label1;
                label1 = new System.Windows.Forms.Label
                {
                    Dock = System.Windows.Forms.DockStyle.None,
                    AutoSize = false,
                    Font = new System.Drawing.Font("Courier New", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0))),
                    Location = grid[eventArgs.getOriginPosition().PosX + 5, grid.GetLength(1) - (eventArgs.getOriginPosition().PosY + 6) * 3 + 1].Location,
                    Text = "" + eventArgs.Order.Objekt.Value,
                    Name = "label1",
                    Size = new System.Drawing.Size(37, 14),
                    BackColor = Color.Transparent,
                    TabIndex = 2
                };
                panel1.Controls.Add(label1);
                label1.BringToFront();
                //redraw originposition to remove object
                UpdateText(eventArgs.getOriginPosition().PosX,eventArgs.getOriginPosition().PosY,c.GetObjectAt(eventArgs.getOriginPosition().PosX,eventArgs.getOriginPosition().PosY));
                MoveLabel(label1, label1.Location, grid[eventArgs.getNewPosition().PosX + 5, grid.GetLength(1) - (eventArgs.getNewPosition().PosY + 6) * 3 + 1].Location, eventArgs.getNewPosition(), eventArgs.Order.Objekt);
            }
        }

        public async void MoveLabel(Label l, Point origin, Point target, Position newPosition, Moveable objekt)
        {
            int waittime = waittimer/3;
            int  waited = 0;
            while (waited < waittime)
            {
                int roundedX = (int)Math.Round(10.0 / waittime * (target.X - origin.X), 0);
                int roundedY = (int)Math.Round(10.0 / waittime * (target.Y - origin.Y), 0);
                l.Location = new Point(l.Location.X + roundedX, l.Location.Y + roundedY);
                await Task.Delay(10);
                waited += 10;
            }
            panel1.Controls.Remove(l);
            l.Dispose();
            //update targetposition to already show the moveable there (even though its logically still at originposition
            UpdateText(newPosition.PosX, newPosition.PosY, objekt);
        }

        public void HandleMoveEnd(object sender, MoveOrderEventArgs eventArgs)
        {
            //destroy moving object (animation)
            //we dont have to do anything here, because it autodestroys after reaching target
        }

        public void HandleLayout(object sender, PositionEventArgs eventArgs)
        {
            UpdateConnections();
            //if this is a childobject, update the reference in the parentsystem
            if (parent != null)
            {
                PlaceMemento p = c.Events.Owner.Rootplace.CreateMemento() as PlaceMemento;
                Place pl = parent.c.GetObjectAt(posX, posY) as Place;
                p.positionX = pl.Position.PosX;
                p.positionY = pl.Position.PosY;
                p.relativeRotation = pl.RelativeRotation;
                p.destructable = pl.Destructable;
                pl.SetToMemento(p);
                SaveLoadManager.SaveRootplace(parent.c.Events.Owner.Rootplace.Name, parent.c.Events.Owner, false);
                parent.UpdateText(posX, posY, pl);
                this.Text = c.Events.Owner.Rootplace.Name;
            }
        }

        List<IFlickable> flickables;

        public void UpdateConnections()
        {
            flickables = new List<IFlickable>();
            foreach (Label l in grid)
            {
                l.ForeColor = Color.Black;
            }

            foreach (PlaceableObjekt o in c.GetInitialObjects())
            {
                IFlickable f = o as IFlickable;
                if (f != null)
                {
                    flickables.Add(f);
                }
            }

            Color[] color;
            PlaceableObjekt p;
            color = new Color[7] { Color.Blue, Color.Red, Color.Goldenrod, Color.Green, Color.Orange, Color.Magenta, Color.Teal };

            for (int i = 0; i < flickables.Count; i++)
            {
                p = flickables[i] as PlaceableObjekt;
                grid[p.Position.PosX + 5, grid.GetLength(1) - (p.Position.PosY + 6) * 3].ForeColor = color[i % 7];
                grid[p.Position.PosX + 5, grid.GetLength(1) - (p.Position.PosY + 6) * 3 + 1].ForeColor = color[i % 7];
                grid[p.Position.PosX + 5, grid.GetLength(1) - (p.Position.PosY + 6) * 3 + 2].ForeColor = color[i % 7];
            }

            foreach (PlaceableObjekt o in c.GetInitialObjects())
            {
                Lever l = o as Lever;
                if (l != null && l.Connection != null && flickables.Contains(l.Connection))
                {
                    grid[l.Position.PosX + 5, grid.GetLength(1) - (l.Position.PosY + 6) * 3].ForeColor = color[flickables.FindIndex(x => x == l.Connection) % 7];
                    grid[l.Position.PosX + 5, grid.GetLength(1) - (l.Position.PosY + 6) * 3 + 1].ForeColor = color[flickables.FindIndex(x => x == l.Connection) % 7];
                    grid[l.Position.PosX + 5, grid.GetLength(1) - (l.Position.PosY + 6) * 3 + 2].ForeColor = color[flickables.FindIndex(x => x == l.Connection) % 7];
                }
            }
        }

        public void HandleValue(object sender, ValueEventArgs eventArgs)
        {
            //the value is never updated in the rootplace so we dont need to update the text
            //we get the moveable with updated value in the HandlePosition event once its passed back to the rootplace
        }

        public void UpdateText(int x, int y, Worldobjekt w)
        {
            if (updating)
            {
                char upB = ' ';
                char up = ' ';
                char rightB = ' ';
                char left = ' ';
                char s = ' ';
                char right = ' ';
                char leftB = ' ';
                char down = ' ';
                char downB = ' ';
                if (w == null)
                {
                    grid[x + 5, grid.GetLength(1) - (y + 6) * 3].Text = "   ";
                    grid[x + 5, grid.GetLength(1) - (y + 6) * 3 + 1].Text = "   ";
                    grid[x + 5, grid.GetLength(1) - (y + 6) * 3 + 2].Text = "   ";
                }
                else
                {
                    switch (w.ObjectType)
                    {
                        case Objektname.Place:
                            s = 'X';
                            break;
                        case Objektname.Moveable:
                            Moveable m = w as Moveable;
                            s = m.Value.ToString().ToCharArray()[0];
                            upB = grid[x + 5, grid.GetLength(1) - (y + 6) * 3].Text[0];
                            up = grid[x + 5, grid.GetLength(1) - (y + 6) * 3].Text[1];
                            rightB = grid[x + 5, grid.GetLength(1) - (y + 6) * 3].Text[2];
                            left = grid[x + 5, grid.GetLength(1) - (y + 6) * 3 + 1].Text[0];
                            right = grid[x + 5, grid.GetLength(1) - (y + 6) * 3 + 1].Text[2];
                            leftB = grid[x + 5, grid.GetLength(1) - (y + 6) * 3 + 2].Text[0];
                            down = grid[x + 5, grid.GetLength(1) - (y + 6) * 3 + 2].Text[1];
                            downB = grid[x + 5, grid.GetLength(1) - (y + 6) * 3 + 2].Text[2];
                            break;
                        case Objektname.ConveyorBelt:
                            s = '-';
                            break;
                        case Objektname.Comparer:
                            s = 'C';
                            break;
                        case Objektname.Incrementer:
                            s = '+';
                            break;
                        case Objektname.Decrementer:
                            s = 'D';
                            break;
                        case Objektname.Destructor:
                            s = '†';
                            break;
                        case Objektname.Holder:
                            s = 'H';
                            break;
                        case Objektname.Returner:
                            s = '#';
                            break;
                        case Objektname.Mover:
                            s = '╬';
                            break;
                        case Objektname.Jumper:
                            s = 'J';
                            break;
                        case Objektname.Switch:
                            s = '∟';
                            break;
                        case Objektname.Lever:
                            s = 'L';
                            break;
                        case Objektname.Creator:
                            s = '~';
                            break;
                        case Objektname.Copier:
                            s = '°';
                            break;
                        case Objektname.Melter:
                            s = 'M';
                            break;
                        case Objektname.Adder:
                            s = 'A';
                            break;
                        case Objektname.Subber:
                            s = 'S';
                            break;
                        case Objektname.Multiplier:
                            s = '*';
                            break;
                        case Objektname.Divider:
                            s = '/';
                            break;
                        case Objektname.IdenticalTester:
                            s = '=';
                            break;
                        case Objektname.GreaterThanTester:
                            s = '>';
                            break;
                        case Objektname.Splitter:
                            s = '$';
                            break;
                        case Objektname.Alternator:
                            s = '%';
                            break;
                        case Objektname.Memory:
                            Memory me = w as Memory;
                            rightB = me.SavedValue.ToString().ToCharArray()[0];
                            if (me.InputDirections[0] == Direction.Left)
                            {
                                leftB = '⇒';
                            }
                            if (me.InputDirections[0] == Direction.Right)
                            {
                                rightB = '⇐';
                                leftB = me.SavedValue.ToString().ToCharArray()[0];
                            }
                            if (me.InputDirections[0] == Direction.Up)
                            {
                                upB = '⇓';
                            }
                            if (me.InputDirections[0] == Direction.Down)
                            {
                                downB = '⇑';
                            }
                            s = '§';
                            break;
                    }
                    //place has a relative rotation you need to calculate to real rotation
                    if (w.ObjectType == Objektname.Place)
                    {
                        Place p = w as Place;
                        if (p.OutputDirections.Contains(DirectionHelper.Rotate(Direction.Left, 4 -DirectionHelper.GetRotation(p.RelativeRotation))))
                        {
                            left = '←';
                        }
                        if (p.OutputDirections.Contains(DirectionHelper.Rotate(Direction.Right, 4 - DirectionHelper.GetRotation(p.RelativeRotation))))
                        {
                            right = '→';
                        }
                        if (p.OutputDirections.Contains(DirectionHelper.Rotate(Direction.Up, 4 - DirectionHelper.GetRotation(p.RelativeRotation))))
                        {
                            up = '↑';
                        }
                        if (p.OutputDirections.Contains(DirectionHelper.Rotate(Direction.Down, 4 - DirectionHelper.GetRotation(p.RelativeRotation))))
                        {
                            down = '↓';
                        }
                        grid[x + 5, grid.GetLength(1) - (y + 6) * 3].Text = "" + upB + up + rightB;
                        grid[x + 5, grid.GetLength(1) - (y + 6) * 3 + 1].Text = "" + left + s + right;
                        grid[x + 5, grid.GetLength(1) - (y + 6) * 3 + 2].Text = "" + leftB + down + downB;
                    }
                    else if (w.ObjectType != Objektname.Moveable)
                    {
                        PlaceableObjekt p = w as PlaceableObjekt;
                        if (p.OutputDirections.Contains(Direction.Left))
                        {
                            left = '←';
                            if (w.ObjectType == Objektname.Switch)
                            {
                                Switch sw = p as Switch;
                                if((sw.Activated && sw.OutputDirections[1] == Direction.Left) || (!sw.Activated && sw.OutputDirections[0] == Direction.Left))
                                {
                                    left = '-';
                                }
                            }
                            if (w.ObjectType == Objektname.Alternator)
                            {
                                Alternator sw = p as Alternator;
                                if ((sw.Activated && sw.OutputDirections[0] == Direction.Left) || (!sw.Activated && sw.OutputDirections[1] == Direction.Left))
                                {
                                    left = '-';
                                }
                            }
                            if (w.ObjectType == Objektname.Returner && p.OutputDirections.Contains(Direction.Parent))
                            {
                                right = '→';
                                rightB = '→';
                                downB = '→';
                                if (!p.InputDirections.Contains(Direction.Parent))
                                {
                                    left = ' ';
                                }
                            }
                            if ((w.ObjectType == Objektname.Comparer || w.ObjectType == Objektname.Creator) && p.OutputDirections[0] == Direction.Left)
                            {
                                Comparer c = p as Comparer;
                                leftB = c.TargetValue.ToString().ToCharArray()[0];
                                left = '⇐';
                            }
                        }
                        if (p.OutputDirections.Contains(Direction.Right))
                        {
                            right = '→';
                            if (w.ObjectType == Objektname.Switch)
                            {
                                Switch sw = p as Switch;
                                if((sw.Activated && sw.OutputDirections[1] == Direction.Right) || (!sw.Activated && sw.OutputDirections[0] == Direction.Right))
                                {
                                    right = '-';
                                }
                            }
                            if (w.ObjectType == Objektname.Alternator)
                            {
                                Alternator sw = p as Alternator;
                                if ((sw.Activated && sw.OutputDirections[0] == Direction.Right) || (!sw.Activated && sw.OutputDirections[1] == Direction.Right))
                                {
                                    right = '-';
                                }
                            }
                            if (w.ObjectType == Objektname.Returner && p.OutputDirections.Contains(Direction.Parent))
                            {
                                left = '←';
                                leftB = '←';
                                upB = '←';
                                if (!p.InputDirections.Contains(Direction.Parent))
                                {
                                    right = ' ';
                                }
                            }
                            if ((w.ObjectType == Objektname.Comparer || w.ObjectType == Objektname.Creator) && p.OutputDirections[0] == Direction.Right)
                            {
                                Comparer c = p as Comparer;
                                rightB = c.TargetValue.ToString().ToCharArray()[0];
                                right = '⇒';
                            }
                        }
                        if (p.OutputDirections.Contains(Direction.Up))
                        {
                            up = '↑';
                            if (w.ObjectType == Objektname.Switch)
                            {
                                Switch sw = p as Switch;
                                if((sw.Activated && sw.OutputDirections[1] == Direction.Up) || (!sw.Activated && sw.OutputDirections[0] == Direction.Up))
                                {
                                    up = '｜';
                                }
                            }
                            if (w.ObjectType == Objektname.Alternator)
                            {
                                Alternator sw = p as Alternator;
                                if ((sw.Activated && sw.OutputDirections[0] == Direction.Up) || (!sw.Activated && sw.OutputDirections[1] == Direction.Up))
                                {
                                    up = '｜';
                                }
                            }
                            if (w.ObjectType == Objektname.Returner && p.OutputDirections.Contains(Direction.Parent))
                            {
                                down = '↓';
                                downB = '↓';
                                leftB = '↓';
                                if (!p.InputDirections.Contains(Direction.Parent))
                                {
                                    up = ' ';
                                }
                            }
                            if ((w.ObjectType == Objektname.Comparer || w.ObjectType == Objektname.Creator) && p.OutputDirections[0] == Direction.Up)
                            {
                                Comparer c = p as Comparer;
                                upB = c.TargetValue.ToString().ToCharArray()[0];
                                up = '⇑';
                            }
                        }
                        if (p.OutputDirections.Contains(Direction.Down))
                        {
                            down = '↓';
                            if (w.ObjectType == Objektname.Switch)
                            {
                                Switch sw = p as Switch;
                                if((sw.Activated && sw.OutputDirections[1] == Direction.Down) || (!sw.Activated && sw.OutputDirections[0] == Direction.Down))
                                {
                                    down = '｜';
                                }
                            }
                            if (w.ObjectType == Objektname.Alternator)
                            {
                                Alternator sw = p as Alternator;
                                if ((sw.Activated && sw.OutputDirections[0] == Direction.Down) || (!sw.Activated && sw.OutputDirections[1] == Direction.Down))
                                {
                                    down = '｜';
                                }
                            }
                            if (w.ObjectType == Objektname.Returner && p.OutputDirections.Contains(Direction.Parent))
                            {
                                up = '↑';
                                upB = '↑';
                                rightB = '↑';
                                if (!p.InputDirections.Contains(Direction.Parent))
                                {
                                    down = ' ';
                                }
                            }
                            if ((w.ObjectType == Objektname.Comparer || w.ObjectType == Objektname.Creator) && p.OutputDirections[0] == Direction.Down)
                            {
                                Comparer c = p as Comparer;
                                downB = c.TargetValue.ToString().ToCharArray()[0];
                                down = '⇓';
                            }
                        }
                    }
                    grid[x + 5, grid.GetLength(1) - (y + 6) * 3].Text = "" + upB + up + rightB;
                    grid[x + 5, grid.GetLength(1) - (y + 6) * 3 + 1].Text = "" + left + s + right;
                    grid[x + 5, grid.GetLength(1) - (y + 6) * 3 + 2].Text = "" + leftB + down + downB;
                }
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            autorun = 0;
            c.Step();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            autorun = 0;
            waittimer = 1000;
            c.ResetSystem();
            AddInputs();
            Initialize();
        }

        public void Initialize()
        {
            if (updating)
            {
                //draw the grid visibly
                Color[] color = new Color[2] { Color.LightGray, Color.WhiteSmoke };
                int a = 0;

                foreach (Label l in grid)
                {
                    l.BackColor = BackColor;
                }

                for (int i = 5 - c.Events.Owner.Rootplace.SizeX; i < c.Events.Owner.Rootplace.SizeX + 6; i++)
                {
                    for (int j = 15 - 3 * c.Events.Owner.Rootplace.SizeY; j < 3 * c.Events.Owner.Rootplace.SizeY + 18; j++)
                    {
                        int k = j % 3;
                        if (k == 0)
                        {
                            a = (a + 1) % 2;
                        }
                        grid[i, j].BackColor = color[a];
                    }

                }

                //draw initial objects
                for (int i = 0; i < grid.GetLength(0); i++)
                {
                    for (int j = 0; j < grid.GetLength(1); j++)
                    {
                        grid[i, j].Text = "   ";
                    }
                }

                foreach (PlaceableObjekt p in c.GetInitialObjects())
                {
                    UpdateText(p.Position.PosX, p.Position.PosY, p);
                }

                UpdateConnections();

                UpdateInputs();
                UpdateOutputs();
            }
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            autorun = 0;
            updating = false;
            c.Circle();
            updating = true;
            Initialize();
        }

        bool completeRun = false;

        private async void Button4_Click(object sender, EventArgs e)
        {
            updating = false;

            //dont run completion because it blocks uiupdates
            //instead run circles till completion
            //c.Completion();

            
            try
            {
                completeRun = true;
                autorun = 0;
                await RunAutomatically(false);
            }
            catch
            {

            }

            completeRun = false;
            updating = true;
            Initialize();
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            autorun = 0;
            c.Undo();
        }

        private void Button6_Click(object sender, EventArgs e)
        {
            autorun = 0;
            c.Redo();
        }

        int autorun;
        int waittimer = 1000;

        private async void Button7_Click(object sender, EventArgs e)
        {
            try
            {
                await RunAutomatically(true);
            }
            catch
            {

            }
        }

        DateTime newtime;

        //its a dirty way to allow uiupdates without multitreading
        //we will do steps or circles and optionally wait in between them for ui updates
        //but every 100 milliseconds is a forced wait so the ui can catch up
        //a clean way would be threading with thread or tasks: work is done in another task and we dont subscribe to systemevents
        //but instead only to the taskevents (end/progress) and do the uiupdates there 
        //or call an event for each uiupdate instead of setting its property here directly: control.Invoke((MethodInvoker) (() => control.Text = "new text"));
        //this is because in Forms ui lives in only 1 task
        public async Task RunAutomatically(bool steps)
        {
            newtime = DateTime.Now;
            autorun++;
            while (autorun == 1 && this != null)
            {
                if (steps)
                {
                    c.Step();
                }
                else
                {
                    c.Circle();
                }
                if (waittimer > 2 && steps)
                {
                    await WaitAsynchronouslyAsync(waittimer);
                }
                else
                {
                    await WaitAsynchronouslyAsync(0);
                }
                if (autorun > 1)
                {
                    autorun = 0;
                    break;
                }
            }

        }

        public async Task WaitAsynchronouslyAsync(int time)
        {
            if(time == 0)
            {
                //still update form with 10 fps
                if (newtime.AddMilliseconds(100) < DateTime.Now)
                {
                    time = 2;
                    newtime = DateTime.Now;
                }
            }
            await Task.Delay(time);
        }

        private void Button8_Click(object sender, EventArgs e)
        {
            ToolpaletteForm f = new ToolpaletteForm(this);
            f.Show();
        }

        private void Button9_Click(object sender, EventArgs e)
        {
            //set the metadata for the rootplace
            c.SetRootplaceSize(int.Parse(numericUpDown1.Value.ToString()), int.Parse(numericUpDown1.Value.ToString()));
        }

    }
}
