﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    class GreaterThanTester : Melter
    {
        public GreaterThanTester(Position position, Root root, Direction output, bool destructable)
            : base(position, root, output, destructable)
        {

        }

        public override void ExecuteTick()
        {
            if (CurrentInput[0].Value > CurrentInput[1].Value)
            {
                CurrentInput[0].Value = 1;
            }
            else if (CurrentInput[0].Value == CurrentInput[1].Value)
            {
                CurrentInput[0].Value = 0;
            }
            else
            {
                CurrentInput[0].Value = -1;
            }
            base.ExecuteTick();
        }
    }
}
