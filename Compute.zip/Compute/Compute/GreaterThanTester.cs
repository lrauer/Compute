﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    class GreaterThanTester : Melter
    {
        public GreaterThanTester(Position position, Root root, Direction output, bool destructable)
            : base(position, root, output, destructable)
        {

        }

        public override void ExecuteTick()
        {
            if (CurrentInput[0].Value > CurrentInput[1].Value)
            {
                CurrentInput[0].Value = 1;
            }
            else if (CurrentInput[0].Value == CurrentInput[1].Value)
            {
                CurrentInput[0].Value = 0;
            }
            else
            {
                CurrentInput[0].Value = -1;
            }
            base.ExecuteTick();
        }

        public override int GetSpace()
        {
            return 30; // 94 record (ohne all)
        }
        
        public override int GetObjectcount()
        {
            return 25; // 53 record (ohne all)
        }
        
        public override int GetDistance()
        {
            return 40; // 116 record (ohne all)
        }
        
        public override int GetSteps()
        {
            return 40; // 85 record (ohne all)
        }

        public override string GetDescription()
        {
            return "Takes 2 inputs and compares them. The result will be 1 if first input is greater, 0 if identical and -1 if second input is greater. Then releases the result in the outputdirection.";
        }
    }
}
