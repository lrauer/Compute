﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Compute
{
    public class Place : PlaceableObjekt
    {

        //List of the children that live inside this place
        List<PlaceableObjekt> Children = new List<PlaceableObjekt>();

        public event EventHandler<MementoEventArgs> MementoCreation;
        public event EventHandler<MoveOrderEventArgs> MoveOrderBegin;
        public event EventHandler<MoveOrderEventArgs> MoveOrderEnd;

        public void AddChild(PlaceableObjekt p, bool replace)
        {
            if (p.Position.PosX > SizeX || p.Position.PosX * -1 > SizeX || p.Position.PosY > SizeY || p.Position.PosY * -1 > SizeY)
            {
                throw new ActionInvalidException("Cant add Child outside of the System", this, p.Position);
            }
            if (!MyRoot.IsReady())
            {
                throw new ActionInvalidException("Cant change System while running", this, p.Position);
            }
            PlaceableObjekt newPos = GetChildAt(p.Position.PosX, p.Position.PosY);
            if (Children.Contains(p))
            {
                throw new ActionInvalidException("Child is already in System", this, p.Position);
            }
            if (newPos != null && !replace)
            {
                throw new ActionInvalidException("There already is a Child at this position", this, p.Position);
            }

            //undoable action, so create a Memento
            PlaceableObjektMemento pOld = this.CreateMemento();
            if (newPos != null)
            {
                //remove without memento(undo) to bundle the transaction
                RemoveChild(newPos.Position.PosX, newPos.Position.PosY, false);
            }
            Children.Add(p);
            PlaceableObjektMemento pNew = this.CreateMemento();
            MementoCreation.Invoke(this, new MementoEventArgs(new MementoChange(this, pOld, pNew), "Added " + p.ObjectType, 0, p.Position.PosX, 0, p.Position.PosY, null, p.Position.Parent, p.ObjectType));

        }

        public void CopyChild(int posX, int posY, int newPosX, int newPosY, bool replace)
        {
            if (!MyRoot.IsReady())
            {
                throw new ActionInvalidException("Cant change System while running", this, new Position(newPosX, newPosY, this));
            }
            PlaceableObjekt pOld = GetChildAt(posX, posY);
            if (pOld.ObjectType == Objektname.Returner)
            {
                throw new ActionInvalidException("Cant copy a Returner", this, new Position(posX, posY, this));
            }
            CopyObject(pOld, newPosX, newPosY, replace);

        }

        public void CopyObject(PlaceableObjekt blueprint, int newPosX, int newPosY, bool replace)
        {
            if (!MyRoot.IsReady())
            {
                throw new ActionInvalidException("Cant change System while running", this, new Position(newPosX, newPosY, this));
            }
            if (blueprint == null)
            {
                throw new ActionInvalidException("Cant copy empty Object", this, new Position(newPosX, newPosY, this));
            }
            if (blueprint.ObjectType == Objektname.Returner)
            {
                throw new ActionInvalidException("Cant copy a Returner", this, new Position(newPosX, newPosY, this));
            }
            PlaceableObjekt p = ObjektnameHelper.GetObjekt(blueprint.ObjectType, this) as PlaceableObjekt;
            //copy values from old Object
            PlaceableObjektMemento memento = blueprint.CreateMemento();
            memento.positionX = newPosX;
            memento.positionY = newPosY;
            //Lever has to create a new ID
            if (p.ObjectType == Objektname.Lever)
            {
                (p as Lever).SetToMementoNewID(memento);
            }
            else
            {
                p.SetToMemento(memento);
            }
            AddChild(p, replace);

        }

        public List<PlaceableObjekt> GetChildren()
        {
            return Children;
        }

        public void RemoveChild(int posX, int posY)
        {
            RemoveChild(posX, posY, true);
        }

        void RemoveChild(int posX, int posY, bool undoable)
        {
            if (!MyRoot.IsReady())
            {
                throw new ActionInvalidException("Cant change System while running", this, new Position(posX, posY, this));
            }
            PlaceableObjekt p = GetChildAt(posX, posY);
            if (p == null)
            {
                throw new ActionInvalidException("Cant destroy at empty Position", this, new Position(posX, posY, this));
            }
            if (!p.Destructable)
            {
                throw new ActionInvalidException("Cant destroy indestructible Object", this, new Position(posX, posY, this));
            }
            PlaceableObjektMemento pOld = null;
            if (undoable)
            {
                //undoable action, so create a Memento
                pOld = this.CreateMemento();
            }
            Children.Remove(p);
            //update Levers that connect to the child
            if (p as IFlickable != null)
            {
                //delete Connections
                UpdateLevers(p as IFlickable, null);
            }
            if (undoable)
            {
                PlaceableObjektMemento pNew = this.CreateMemento();
                MementoCreation.Invoke(this, new MementoEventArgs(new MementoChange(this, pOld, pNew), "Removed " + p.ObjectType, p.Position.PosX, 0, p.Position.PosY, 0, p.Position.Parent, null, p.ObjectType));
            }
        }

        public void ChangeChildPosition(int oldPosX, int oldPosY, int newPosX, int newPosY, bool replace)
        {
            if (!MyRoot.IsReady())
            {
                throw new ActionInvalidException("Cant change System while running", this, new Position(newPosX, newPosY, this));
            }
            PlaceableObjekt p = GetChildAt(oldPosX, oldPosY);
            PlaceableObjekt pNewPos = GetChildAt(newPosX, newPosY);
            if (p == null)
            {
                throw new ActionInvalidException("Cant move from empty Position", this, new Position(oldPosX, oldPosY, this));
            }
            if (oldPosX == newPosX && oldPosY == newPosY)
            {
                throw new ActionInvalidException("Object is already at target Position", this, new Position(newPosX, newPosY, this));
            }
            if (p.ObjectType == Objektname.Returner)
            {
                throw new ActionInvalidException("Cant change Position of a Returner", this, new Position(oldPosX, oldPosY, this));
            }
            if (pNewPos != null && !replace)
            {
                throw new ActionInvalidException("There already is a Child at new Position", this, new Position(newPosX, newPosY, this));
            }
            //undoable action, so create a Memento
            PlaceableObjektMemento pOld = this.CreateMemento();
            if (pNewPos != null)
            {
                //remove without memento(undo) to bundle the transaction
                RemoveChild(newPosX, newPosY, false);
            }
            else
            {
                //update Levers that connect to the child
                if (p as IFlickable != null)
                {
                    //update connections
                    UpdateLevers(p as IFlickable, p as IFlickable);
                }
            }
            p.Position.SetValues(newPosX, newPosY, p.Position.Parent);
            PlaceableObjektMemento pNew = this.CreateMemento();
            MementoCreation.Invoke(this, new MementoEventArgs(new MementoChange(this, pOld, pNew), "Changed Position", oldPosX, newPosX, oldPosY, newPosY, p.Position.Parent, p.Position.Parent, p.ObjectType));

        }

        public void SwapChildPositions(int PosX1, int PosY1, int PosX2, int PosY2)
        {
            if (!MyRoot.IsReady())
            {
                throw new ActionInvalidException("Cant change System while running", this, new Position(PosX1, PosY1, this));
            }
            PlaceableObjekt p1 = GetChildAt(PosX1, PosY1);
            PlaceableObjekt p2 = GetChildAt(PosX2, PosY2);
            if (PosX1 == PosX2 && PosY1 == PosY2)
            {
                throw new ActionInvalidException("Cant swap Child with itself", this, new Position(PosX1, PosY1, this));
            }
            if (p1.ObjectType == Objektname.Returner || p2.ObjectType == Objektname.Returner)
            {
                throw new ActionInvalidException("Cant swap Position of a Returner", this, new Position(PosX1, PosY1, this));
            }
            //undoable action, so create a Memento
            PlaceableObjektMemento pOld = this.CreateMemento();
            if (p1 != null)
            {
                p1.Position.SetValues(PosX2, PosY2, this);
                //update Levers that connect to the child
                if (p1 as IFlickable != null)
                {
                    //update connections
                    UpdateLevers(p1 as IFlickable, p1 as IFlickable);
                }
            }
            if (p2 != null)
            {
                p2.Position.SetValues(PosX1, PosY1, this);
                //update Levers that connect to the child
                if (p2 as IFlickable != null)
                {
                    //update connections
                    UpdateLevers(p2 as IFlickable, p2 as IFlickable);
                }
            }
            PlaceableObjektMemento pNew = this.CreateMemento();
            MementoCreation.Invoke(this, new MementoEventArgs(new MementoChange(this, pOld, pNew), "Swapped Positions", PosX1, PosX2, PosY1, PosY2, this, this, ObjectType));

        }

        public PlaceableObjekt GetChildAt(int posX, int posY)
        {
            foreach (PlaceableObjekt p in Children)
            {
                if (p.Position.PosX == posX && p.Position.PosY == posY && p.Position.Parent == this)
                {
                    return p;
                }
            }
            return null;
        }

        public Moveable GetInputAt(int posX, int posY)
        {
            foreach (Moveable m in CurrentInput)
            {
                if (m.Position.PosX == posX && m.Position.PosY == posY && m.Position.Parent == this)
                {
                    return m;
                }
            }
            return null;
        }

        void UpdateLevers(IFlickable sender, IFlickable newValue)
        {
            foreach (PlaceableObjekt p in Children)
            {
                Lever l = p as Lever;
                if (l != null && l.Connection == sender)
                {
                    l.Connect(newValue);
                }
            }
        }

        public void ConnectLeverToFlickable(int lPosX, int lPosY, int fPosX, int fPosY)
        {
            if (!MyRoot.IsReady())
            {
                throw new ActionInvalidException("Cant change System while running", this, new Position(lPosX, lPosY, this));
            }
            IFlickable f = GetChildAt(fPosX, fPosY) as IFlickable;
            if (f == null)
            {
                f = GetChildAt(lPosX, lPosY) as IFlickable;
            }
            Lever l = GetChildAt(lPosX, lPosY) as Lever;
            if (l == null)
            {
                l = GetChildAt(fPosX, fPosY) as Lever;
            }
            if (l == null)
            {
                throw new ActionInvalidException("There is no Lever to connect from", this, new Position(lPosX, lPosY, this));
            }
            if (f == null)
            {
                throw new ActionInvalidException("There is no Flickable to connect to", this, new Position(fPosX, fPosY, this));
            }
            if (l.Connection == f)
            {
                throw new ActionInvalidException("Lever already connected to this Flickable", this, l.Position);
            }
            //undoable action, so create a Memento
            PlaceableObjektMemento pOld = l.CreateMemento();
            l.Connect(f);
            PlaceableObjektMemento pNew = l.CreateMemento();
            MementoCreation.Invoke(this, new MementoEventArgs(new MementoChange(l, pOld, pNew), "Lever connected", pOld.positionX, pNew.positionX, pOld.positionY, pNew.positionY, l.Position.Parent, l.Position.Parent, l.ObjectType));
        }

        public void Disconnect(int posX, int posY)
        {
            if (!MyRoot.IsReady())
            {
                throw new ActionInvalidException("Cant change System while running", this, new Position(posX, posY, this));
            }
            Lever l = GetChildAt(posX, posY) as Lever;
            if (l != null)
            {
                if (l.Connection == null)
                {
                    throw new ActionInvalidException("There is no Flickable to disconnect", this, new Position(posX, posY, this));
                }
                //undoable action, so create a Memento
                PlaceableObjektMemento pOld = l.CreateMemento();
                l.Connection = null;
                PlaceableObjektMemento pNew = l.CreateMemento();
                MementoCreation.Invoke(this, new MementoEventArgs(new MementoChange(l, pOld, pNew), "Disconnected Lever", pOld.positionX, pNew.positionX, pOld.positionY, pNew.positionY, l.Position.Parent, l.Position.Parent, l.ObjectType));
            }
            else
            {
                PlaceableObjekt p = GetChildAt(posX, posY);
                IFlickable f = p as IFlickable;
                if (f != null)
                {
                    //undoable action, so create a Memento
                    PlaceableObjektMemento pOld = this.CreateMemento();
                    UpdateLevers(f, null);
                    PlaceableObjektMemento pNew = this.CreateMemento();
                    MementoCreation.Invoke(this, new MementoEventArgs(new MementoChange(this, pOld, pNew), "Disconnected all Levers", p.Position.PosX, p.Position.PosX, p.Position.PosY, p.Position.PosY, p.Position.Parent, p.Position.Parent, ObjectType));
                }
                else
                {
                    throw new ActionInvalidException("There is no Lever or Flickable at this Position", this, new Position(posX, posY, this));
                }
            }
        }

        public void ChangeTargetValue(int posX, int posY, int value)
        {
            if (!MyRoot.IsReady())
            {
                throw new ActionInvalidException("Cant change System while running", this, new Position(posX, posY, this));
            }
            Comparer c = GetChildAt(posX, posY) as Comparer;
            if (c == null)
            {
                throw new ActionInvalidException("There is no Object with a Value to change at this Position", this, new Position(posX, posY, this));
            }
            if (c.TargetValue == value)
            {
                throw new ActionInvalidException("Object already has the same Value", this, new Position(posX, posY, this));
            }
            //undoable action, so create a Memento
            PlaceableObjektMemento pOld = c.CreateMemento();
            c.TargetValue = value;
            PlaceableObjektMemento pNew = c.CreateMemento();
            MementoCreation.Invoke(this, new MementoEventArgs(new MementoChange(c, pOld, pNew), "Changed value", pOld.positionX, pNew.positionX, pOld.positionY, pNew.positionY, c.Position.Parent, c.Position.Parent, c.ObjectType));
        }

        public void ChangeJumpTarget(int posX, int posY, int targetX, int targetY)
        {
            if (!MyRoot.IsReady())
            {
                throw new ActionInvalidException("Cant change System while running", this, new Position(posX, posY, this));
            }
            Jumper j = GetChildAt(posX, posY) as Jumper;
            if (j == null)
            {
                throw new ActionInvalidException("There is no Jumper at this Position", this, new Position(posX, posY, this));
            }
            if (j.TargetPosition.PosX == targetX && j.TargetPosition.PosY == targetY)
            {
                throw new ActionInvalidException("Cant Jump to own Position", this, new Position(posX, posY, this));
            }
            //undoable action, so create a Memento
            PlaceableObjektMemento pOld = j.CreateMemento();
            j.TargetPosition.SetValues(targetX, targetY, j.TargetPosition.Parent);
            PlaceableObjektMemento pNew = j.CreateMemento();
            MementoCreation.Invoke(this, new MementoEventArgs(new MementoChange(j, pOld, pNew), "Changed jump target", pOld.positionX, pNew.positionX, pOld.positionY, pNew.positionY, j.Position.Parent, j.Position.Parent, j.ObjectType));
        }

        //change all outputs in specific direction
        public void ChangeOutputDirection(int posX, int posY, Direction dOld, Direction dNew)
        {
            if (!MyRoot.IsReady())
            {
                throw new ActionInvalidException("Cant change System while running", this, new Position(posX, posY, this));
            }
            PlaceableObjekt p = GetChildAt(posX, posY);
            if (p == null)
            {
                throw new ActionInvalidException("There is no Child at this Position", this, new Position(posX, posY, this));
            }
            if (!p.OutputDirections.Contains(dOld))
            {
                throw new ActionInvalidException("Child does not contain old Outputdirection", this, new Position(posX, posY, this));
            }
            if (dOld == dNew)
            {
                throw new ActionInvalidException("Child already outputs to this Direction", this, new Position(posX, posY, this));
            }
            if (p.ObjectType == Objektname.Returner)
            {
                throw new ActionInvalidException("Cant change Outputdirection for a Returner", this, new Position(posX, posY, this));
            }
            if (p.ObjectType == Objektname.Place)
            {
                throw new ActionInvalidException("Cant change a single Outputdirection for a Place", this, new Position(posX, posY, this));
            }
            //undoable action, so create a Memento
            PlaceableObjektMemento pOld = p.CreateMemento();
            for (int i = 0; i < p.OutputDirections.Count; i++)
            {
                if (p.OutputDirections[i] == dOld)
                {
                    p.OutputDirections[i] = dNew;
                }
            }
            PlaceableObjektMemento pNew = p.CreateMemento();
            MementoCreation.Invoke(this, new MementoEventArgs(new MementoChange(p, pOld, pNew), "Changed Outputdirections", pOld.positionX, pNew.positionX, pOld.positionY, pNew.positionY, p.Position.Parent, p.Position.Parent, p.ObjectType));
        }

        //change a specific outputdirection
        public void ChangeOutputDirection(int posX, int posY, int index, Direction dNew)
        {
            if (!MyRoot.IsReady())
            {
                throw new ActionInvalidException("Cant change System while running", this, new Position(posX, posY, this));
            }
            PlaceableObjekt p = GetChildAt(posX, posY);
            if (p == null)
            {
                throw new ActionInvalidException("There is no Child at this Position", this, new Position(posX, posY, this));
            }
            if (p.OutputDirections.Count <= index)
            {
                throw new ActionInvalidException("Child does not contain old Outputdirection", this, new Position(posX, posY, this));
            }
            if (p.OutputDirections[index] == dNew)
            {
                throw new ActionInvalidException("Child already outputs to this Direction", this, new Position(posX, posY, this));
            }
            if (p.ObjectType == Objektname.Returner)
            {
                throw new ActionInvalidException("Cant change Outputdirection for a Returner", this, new Position(posX, posY, this));
            }
            if (p.ObjectType == Objektname.Place)
            {
                throw new ActionInvalidException("Cant change a single Outputdirection for a Place", this, new Position(posX, posY, this));
            }
            //undoable action, so create a Memento
            PlaceableObjektMemento pOld = p.CreateMemento();
            p.OutputDirections[index] = dNew;
            PlaceableObjektMemento pNew = p.CreateMemento();
            MementoCreation.Invoke(this, new MementoEventArgs(new MementoChange(p, pOld, pNew), "Changed Outputdirection", pOld.positionX, pNew.positionX, pOld.positionY, pNew.positionY, p.Position.Parent, p.Position.Parent, p.ObjectType));
        }

        //rotates for int quarters clockwise
        public void Rotate(int posX, int posY, int quarters)
        {
            if (!MyRoot.IsReady())
            {
                throw new ActionInvalidException("Cant change System while running", this, new Position(posX, posY, this));
            }
            PlaceableObjekt p = GetChildAt(posX, posY);
            if (p == null)
            {
                throw new ActionInvalidException("There is no Child at this Position", this, new Position(posX, posY, this));
            }
            if (quarters < 1)
            {
                throw new ActionInvalidException("Cant rotate less than 1 Quarter", this, new Position(posX, posY, this));
            }
            if (quarters > 3)
            {
                throw new ActionInvalidException("Cant rotate more than 3 Quarters", this, new Position(posX, posY, this));
            }
            if (p.ObjectType == Objektname.Returner)
            {
                throw new ActionInvalidException("Cant rotate a Returner", this, new Position(posX, posY, this));
            }

            //undoable action, so create a Memento
            PlaceableObjektMemento pOld = p.CreateMemento();

            //place has a special rotationlogic
            if (p.ObjectType == Objektname.Place)
            {
                Place pl = p as Place;
                pl.RelativeRotation = DirectionHelper.Rotate(pl.RelativeRotation, quarters);
            }
            //rotate all directions for int quarters
            else
            {
                for (int i = 0; i < p.InputDirections.Count; i++)
                {
                    p.InputDirections[i] = DirectionHelper.Rotate(p.InputDirections[i], quarters);
                }
                for (int i = 0; i < p.OutputDirections.Count; i++)
                {
                    p.OutputDirections[i] = DirectionHelper.Rotate(p.OutputDirections[i], quarters);
                }
            }
            PlaceableObjektMemento pNew = p.CreateMemento();
            MementoCreation.Invoke(this, new MementoEventArgs(new MementoChange(p, pOld, pNew), "Rotated " + p.ObjectType, pOld.positionX, pNew.positionX, pOld.positionY, pNew.positionY, p.Position.Parent, p.Position.Parent, p.ObjectType));
        }

        public void ChangeBoundaries(int sizeX, int sizeY, Direction[] inputDirections, Direction[] outputDirections, int inputcount, int outputcount)
        {
            if (!MyRoot.IsReady())
            {
                throw new ActionInvalidException("Cant change System while running", this, Position);
            }
            if (sizeX < 1 || sizeY < 1)
            {
                throw new ActionInvalidException("System cant get smaller than 1x1", this, Position);
            }
            if (inputcount < 1 || inputDirections.Length < 1)
            {
                throw new ActionInvalidException("System cant work with less than 1 input", this, Position);
            }
            if (outputcount < 1 || outputDirections.Length < 1)
            {
                throw new ActionInvalidException("System cant work with less than 1 output", this, Position);
            }
            if (sizeX == SizeX && sizeY == SizeY && inputcount == InputCount && outputcount == OutputCount && Enumerable.SequenceEqual(InputDirections.OrderBy(x => x), inputDirections.OrderBy(x => x)) && Enumerable.SequenceEqual(OutputDirections.OrderBy(x => x), outputDirections.OrderBy(x => x)))
            {
                throw new ActionInvalidException("System already has the target Boundaries", this, Position);
            }
            //undoable action, so create a Memento
            PlaceableObjektMemento pOld = this.CreateMemento();

            //remove all children out of new boundaries
            for (int i = 0; i < Children.Count(); i++)
            {
                PlaceableObjekt p = Children[i];
                if (p.Position.PosX > sizeX || p.Position.PosX < sizeX * -1 || p.Position.PosY > sizeY || p.Position.PosY < sizeY * -1)
                {
                    Children.Remove(p);
                    i--;
                }
            }

            //remove all children where the returners will now be
            if (inputDirections.Contains(Direction.Right) || outputDirections.Contains(Direction.Right))
            {
                PlaceableObjekt p = GetChildAt(sizeX, 0);
                if (p != null)
                {
                    Children.Remove(p);
                }
            }
            if (inputDirections.Contains(Direction.Left) || outputDirections.Contains(Direction.Left))
            {
                PlaceableObjekt p = GetChildAt(sizeX * -1, 0);
                if (p != null)
                {
                    Children.Remove(p);
                }
            }
            if (inputDirections.Contains(Direction.Up) || outputDirections.Contains(Direction.Up))
            {
                PlaceableObjekt p = GetChildAt(0, sizeY);
                if (p != null)
                {
                    Children.Remove(p);
                }
            }
            if (inputDirections.Contains(Direction.Down) || outputDirections.Contains(Direction.Down))
            {
                PlaceableObjekt p = GetChildAt(0, sizeY * -1);
                if (p != null)
                {
                    Children.Remove(p);
                }
            }

            CreateReturners(sizeX, sizeY, inputDirections, outputDirections, inputcount, outputcount);

            PlaceableObjektMemento pNew = this.CreateMemento();
            MementoCreation.Invoke(this, new MementoEventArgs(new MementoChange(this, pOld, pNew), "Changed Systemboundaries", 0, 0, 0, 0, null, null, Objektname.Root));

        }

        List<MoveTarget> _InputBuffer = new List<MoveTarget>();

        internal List<MoveTarget> InputBuffer
        {
            get { return _InputBuffer; }
            set { _InputBuffer = value; }
        }

        //for testing from where the inputs came this tick
        List<Direction> _CurrentInputDirections = new List<Direction>();

        public List<Direction> CurrentInputDirections
        {
            get { return _CurrentInputDirections; }
            set { _CurrentInputDirections = value; }
        }

        //for testing if the outputs are at the correkt directions
        List<Direction> _CurrentOutputDirections = new List<Direction>();

        public List<Direction> CurrentOutputDirections
        {
            get { return _CurrentOutputDirections; }
            set { _CurrentOutputDirections = value; }
        }

        int _SizeX;

        public int SizeX
        {
            get { return _SizeX; }
            set
            {
                _SizeX = value;
                foreach (PlaceableObjekt p in Children)
                {
                    if (p.Position.PosX > value || p.Position.PosX * -1 > value)
                    {
                        throw new ActionInvalidException("Place is too small for existing children", this, Position);
                    }
                }
            }
        }

        int _SizeY;

        public int SizeY
        {
            get { return _SizeY; }
            set
            {
                _SizeY = value;
                foreach (PlaceableObjekt p in Children)
                {
                    if (p.Position.PosY > value || p.Position.PosY * -1 > value)
                    {
                        throw new ActionInvalidException("Place is too small for existing children", this, Position);
                    }
                }
            }
        }

        Direction _RelativeRotation;

        public Direction RelativeRotation
        {
            get { return _RelativeRotation; }
            set { _RelativeRotation = value; }
        }

        public List<Direction> GetCleanOutputDirections()
        {
            List<Direction> tmp = new List<Direction>();
            foreach (Direction d in OutputDirections)
            {
                if (DirectionHelper.isRotationDirection(d))
                {
                    tmp.Add(DirectionHelper.Rotate(d, DirectionHelper.GetRotation(RelativeRotation)));
                }
                else
                {
                    tmp.Add(d);
                }
            }
            return tmp;
        }

        public List<Direction> GetCleanInputDirections()
        {
            List<Direction> tmp = new List<Direction>();
            foreach (Direction d in InputDirections)
            {
                if (DirectionHelper.isRotationDirection(d))
                {
                    tmp.Add(DirectionHelper.Rotate(d, DirectionHelper.GetRotation(RelativeRotation)));
                }
                else
                {
                    tmp.Add(d);
                }
            }
            return tmp;
        }

        string _Name;

        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        //Create new empty place at position
        public Place(Position position, Root root, bool destructable, int sizeX, int sizeY, string name, Direction relativerotation, Direction[] inputDirections, Direction[] outputDirections, int inputcount, int outputcount)
            : base(position, root)
        {
            Position = position;

            Destructable = destructable;

            RelativeRotation = relativerotation;

            Name = name;

            CreateReturners(sizeX, sizeY, inputDirections, outputDirections, inputcount, outputcount);

            MementoCreation += root.Eventsystem.HandleMementoCreation;
            MoveOrderBegin += root.Eventsystem.HandleMoveOrderBegin;
            MoveOrderEnd += root.Eventsystem.HandleMoveOrderEnd;

            root.RunBegin += HandleNewRun;
        }

        public void HandleNewRun(object sender, SystemStateEventArgs eventArgs)
        {
            //we need sorted List so it always produces the same result
            //we sort at the sart in case System  changed between runs
            Children.Sort();
        }

        public void CreateReturners(int sizeX, int sizeY, Direction[] inputDirections, Direction[] outputDirections, int inputcount, int outputcount)
        {
            //add directions
            OutputDirections.Clear();
            OutputDirections.AddRange(outputDirections);
            InputDirections.Clear();
            InputDirections.AddRange(inputDirections);

            CurrentInputDirections.Clear();
            CurrentInputDirections.AddRange(InputDirections);
            CurrentOutputDirections.Clear();
            CurrentOutputDirections.AddRange(OutputDirections);

            InputCount = inputcount;
            OutputCount = outputcount;

            //remove all returner
            for (int i = 0; i < Children.Count(); i++)
            {
                PlaceableObjekt p = Children[i];
                if (p.ObjectType == Objektname.Returner)
                {
                    Children.Remove(p);
                    i--;
                }
            }

            //set Size of the place. Size goes in each direction (e.g. 5 means from -5 to 5 --> 11 tiles)
            SizeX = sizeX;
            SizeY = sizeY;

            //each place has a fixed children as returners
            //only add necessary returners
            
            if (OutputDirections.Contains(Direction.Up) || InputDirections.Contains(Direction.Up))
            {
                PlaceableObjekt p = new Returner(new Position(0, SizeY, this), MyRoot, Direction.Down, false, InputDirections.Contains(Direction.Up), OutputDirections.Contains(Direction.Up));
                Children.Add(p);
            }
            if (OutputDirections.Contains(Direction.Left) || InputDirections.Contains(Direction.Left))
            {
                PlaceableObjekt p = new Returner(new Position(-1 * SizeX, 0, this), MyRoot, Direction.Right, false, InputDirections.Contains(Direction.Left), OutputDirections.Contains(Direction.Left));
                Children.Add(p);
            }
            if (OutputDirections.Contains(Direction.Down) || InputDirections.Contains(Direction.Down))
            {
                PlaceableObjekt p = new Returner(new Position(0, -1 * SizeY, this), MyRoot, Direction.Up, false, InputDirections.Contains(Direction.Down), OutputDirections.Contains(Direction.Down));
                Children.Add(p);
            }
            if (OutputDirections.Contains(Direction.Right) || InputDirections.Contains(Direction.Right))
            {
                PlaceableObjekt p = new Returner(new Position(SizeX, 0, this), MyRoot, Direction.Left, false, InputDirections.Contains(Direction.Right), OutputDirections.Contains(Direction.Right));
                Children.Add(p);
            }           
        }

        public override bool PrepareTick()
        {

            if (CurrentInput.Count < InputCount)
                return false;
            if (CurrentInput.Count == InputCount)
            {
                //reset outputcounter
                ReleasedOutput = 0;
                CurrentInputDirections.Clear();
                CurrentInputDirections.AddRange(InputDirections);
                CurrentOutputDirections.Clear();
                CurrentOutputDirections.AddRange(OutputDirections);
                return true;
            }

            throw new ActionInvalidException("This Place can only process " + InputCount + " inputs", this, Position);
        }

        //how much output is processed
        int _ReleasedOutput;

        public int ReleasedOutput
        {
            get { return _ReleasedOutput; }
            set { _ReleasedOutput = value; }
        }

        //tick childs until this place finished 1 tick
        public override void ExecuteTick()
        {
            //step the children until this place finished 1 tick (got rid of all inputs)
            do
            {
                Substep();
            } while (InputBuffer.Count > 0);
        }

        //how many substeps per inputs
        int supstepcounter;

        //just do 1 tick for each child
        public void Substep()
        {
            supstepcounter++;
            //if 10000 steps since last input we are most likely broken
            if (supstepcounter > 10000)
            {
                throw new ActionInvalidException("System is looping or too slow", this, Position);
            }
            //first distribute new inputs for the children
            foreach (MoveTarget m in InputBuffer)
            {
                MoveOrder mo = new MoveOrder(m.Mover, m.Origin);
                m.Target.ReceiveInput(mo);
                MoveOrderEnd.Invoke(this, new MoveOrderEventArgs(mo, m));
            }
            InputBuffer.Clear();

            foreach (PlaceableObjekt p in Children)
            {
                if (p.PrepareTick())
                {
                    p.ExecuteTick();
                    MyRoot.CurrentExecute.Steps += p.GetSteps();
                }
            }

            //too few outputs
            if (InputBuffer.Count == 0)
            {
                if (ReleasedOutput != OutputCount)
                {
                    throw new ActionInvalidException("System released " + ReleasedOutput + " outputs but should release " + OutputCount, this, Position);
                }
                else if (CurrentInput.Count > 0)
                {
                    throw new ActionInvalidException("System released all outputs, but is still running (looping)", this, Position);
                }
            }
        }

        public override void Reset()
        {
            InputBuffer.Clear();
            CurrentInput.Clear();
            ReleasedOutput = 0;
            CurrentInputDirections.Clear();
            CurrentInputDirections.AddRange(InputDirections);
            CurrentOutputDirections.Clear();
            CurrentOutputDirections.AddRange(OutputDirections);

            foreach (PlaceableObjekt p in Children)
            {
                p.Reset();
            }
        }

        public override void ReceiveInput(MoveOrder moveOrder)
        {
            //calculate direction for relativeRotation
            moveOrder.Order = DirectionHelper.Rotate(moveOrder.Order, 4 - DirectionHelper.GetRotation(RelativeRotation));

            Direction oldDirection = moveOrder.Order;

            if (CurrentInputDirections.Contains(moveOrder.Order))
            {
                CurrentInputDirections.Remove(moveOrder.Order);
            }
            else
            {
                //get position where input would land
                Position pos = this.Position;
                foreach (PlaceableObjekt p in Children)
                {
                    if (p.ObjectType == Objektname.Returner && p.OutputDirections.Contains(DirectionHelper.Invert(oldDirection)))
                    {
                        pos = p.Position;
                        break;
                    }
                }
                throw new ActionInvalidException("Invalid direction to receive Input for this Place", this, pos);
            }
            //new inputs means system changed
            supstepcounter = 0;
            CurrentInput.Add(moveOrder.Objekt);

            //ReceiveInput to signify the moveable was passed down from parent to child
            moveOrder.Order = Direction.Parent;
            //pass it to the right returner depending on from which direction the input came (inputdirection is always inverted outputdirection)
            PlaceableObjekt r = null;
            foreach (PlaceableObjekt p in Children)
            {
                if (p.ObjectType == Objektname.Returner && p.OutputDirections.Contains(DirectionHelper.Invert(oldDirection)))
                {
                    r = p;
                    break;
                }
            }
            //only receive if the returner can accept inputs from the parent
            if (r != null && r.InputDirections.Contains(Direction.Parent))
            {
                moveOrder.Objekt.Position.Copy(r.Position);
                r.ReceiveInput(moveOrder);
            }
            else
            {
                //get position where input would land
                Position pos = this.Position;
                if (r != null)
                {
                    pos = r.Position;
                }
                throw new ActionInvalidException("Invalid direction to receive Input for this Place", this, pos);
            }
        }

        public override void ReleaseOutput(MoveOrder moveOrder)
        {
            //check if its an output for this element or will just be moved
            //if it is a child of this place it will be released to the next level
            if (moveOrder.Objekt.Position.Parent == this)
            {
                CurrentInput.Remove(moveOrder.Objekt);
                //has released an output
                ReleasedOutput++;

                //too many outputs
                if (OutputCount < ReleasedOutput)
                {
                    throw new ActionInvalidException("System released " + ReleasedOutput + " outputs but should release " + OutputCount, this, Position);
                }

                if (CurrentOutputDirections.Contains(moveOrder.Order))
                {
                    CurrentOutputDirections.Remove(moveOrder.Order);
                }
                else
                {
                    throw new ActionInvalidException("Invalid direction to release output for this Place", this, moveOrder.Objekt.Position);
                }

                //calculate direction for relativeRotation
                moveOrder.Order = DirectionHelper.Rotate(moveOrder.Order, DirectionHelper.GetRotation(RelativeRotation));

                Position.Parent.ReleaseOutput(moveOrder);
            }
            else
            {
                //return it to level of this place before it will be input for the next child
                moveOrder.Objekt.Position.Copy(moveOrder.Objekt.Position.Parent.Position);
                //determine the parent at target position
                int x = moveOrder.Objekt.Position.PosX;
                int y = moveOrder.Objekt.Position.PosY;
                switch (moveOrder.Order)
                {
                    case Direction.Down:
                        y--;
                        break;
                    case Direction.Up:
                        y++;
                        break;
                    case Direction.Left:
                        x--;
                        break;
                    case Direction.Right:
                        x++;
                        break;
                }
                moveOrder.Order = DirectionHelper.Invert(moveOrder.Order);

                if (x > SizeX || x * -1 > SizeX || y > SizeY || y * -1 > SizeY)
                {
                    throw new ActionInvalidException("Can't input outside of the System", this, new Position(x, y, this));
                }
                PlaceableObjekt child = null;
                foreach (PlaceableObjekt p in Children)
                {
                    if (p.Position.PosX == x && p.Position.PosY == y)
                    {
                        child = p;
                        break;
                    }
                }

                if (child == null)
                {
                    throw new ActionInvalidException("Can't input to empty position", this, new Position(x, y, this));
                }
                //add to bufferlist with new parent
                MoveTarget m = new MoveTarget(child, moveOrder.Objekt, moveOrder.Order);
                InputBuffer.Add(m);
                MoveOrder mo = new MoveOrder(m.Mover, m.Origin);
                MoveOrderBegin.Invoke(this, new MoveOrderEventArgs(mo, m));
            }
        }

        public void AddCurrentInput(Moveable m)
        {
            CurrentInput.Add(m);
            //add reference to parentplace as well
            if (MyRoot != Position.Parent)
            {
                Place p = Position.Parent as Place;
                p.AddCurrentInput(m);
            }
        }

        public void RemoveCurrentInput(Moveable m)
        {
            CurrentInput.Remove(m);
            //remove reference from parentplace as well
            if (MyRoot != Position.Parent)
            {
                Place p = Position.Parent as Place;
                p.RemoveCurrentInput(m);
            }
        }

        public override int GetSpace()
        {
            int i = (SizeX * 2 + 1) * (SizeY * 2 + 1);
            foreach (PlaceableObjekt p in Children)
            {
                i += p.GetSpace();
            }
            return i;
        }

        public override int GetObjectcount()
        {
            int i = 0;
            foreach (PlaceableObjekt p in Children)
            {
                i += p.GetObjectcount();
            }
            return i;
        }

        public override int GetDistance()
        {
            return 0;
        }

        //return 0 for Place because it is calculated at runtime
        //so instead of 1 for for the execute you get the childsteps
        public override int GetSteps()
        {
            return 0;
        }

        public override string GetDescription()
        {
            string s = "Uses:";
            List<string> names = new List<string>();
            foreach (PlaceableObjekt p in Children)
            {
                Place pl = p as Place;
                if (pl != null && !names.Contains(pl.Name))
                {
                    s += " " + pl.Name;
                    names.Add(pl.Name);
                }
            }
            if (names.Count == 0)
            {
                s = "Uses no other places";
            }
            return s;
        }

        public void ToXMLComplete(XmlDocument doc, XmlElement head)
        {
            ToXMLBase(doc, head);

            //save attributes
            XmlElement e;

            //create a new element for each child
            foreach (PlaceableObjekt p in Children)
            {
                e = doc.CreateElement(p.ObjectType.ToString());
                //save the childplace completely in this file
                if (p.ObjectType == Objektname.Place)
                {
                    Place pl = p as Place;
                    pl.ToXMLComplete(doc, e);
                }
                else
                {
                    p.ToXML(doc, e);
                }
                head.AppendChild(e);
            }
        }

        public override void ToXML(XmlDocument doc, XmlElement head)
        {
            ToXMLBase(doc, head);

            //save attributes
            XmlElement e;

            //create a new element for each child
            foreach (PlaceableObjekt p in Children)
            {
                e = doc.CreateElement(p.ObjectType.ToString());
                //save only reference to childplaces with their rotation
                if (p.ObjectType == Objektname.Place)
                {
                    Place pl = p as Place;
                    XmlElement e2;
                    //Name
                    e2 = doc.CreateElement("Name");
                    e2.InnerXml = pl.Name;
                    e.AppendChild(e2);

                    //position
                    e2 = doc.CreateElement("Position");
                    e2.InnerXml = pl.Position.PosX + "," + pl.Position.PosY;
                    e.AppendChild(e2);

                    //destructable
                    e2 = doc.CreateElement("Destructable");
                    e2.InnerXml = "" + pl.Destructable;
                    e.AppendChild(e2);

                    //RelativeRotation
                    e2 = doc.CreateElement("RelativeRotation");
                    e2.InnerXml = "" + pl.RelativeRotation;
                    e.AppendChild(e2);

                }
                else
                {
                    p.ToXML(doc, e);
                }
                head.AppendChild(e);
            }
        }

        public void ToXMLBase(XmlDocument doc, XmlElement head)
        {
            base.ToXML(doc, head);

            //save attributes
            XmlElement e;

            //Name
            e = doc.CreateElement("Name");
            e.InnerXml = Name;
            head.AppendChild(e);

            //SizeX
            e = doc.CreateElement("SizeX");
            e.InnerXml = "" + SizeX;
            head.AppendChild(e);

            //SizeY
            e = doc.CreateElement("SizeY");
            e.InnerXml = "" + SizeY;
            head.AppendChild(e);

            //RelativeRotation
            e = doc.CreateElement("RelativeRotation");
            e.InnerXml = "" + RelativeRotation;
            head.AppendChild(e);
        }

        public override void FromXML(XmlElement head)
        {
            //load Place from its own XML File if its not in this file
            //in that case thee are only the 4 positionelements: position, name, destructable, rotation
            if (head.ChildNodes.Count == 4)
            {
                head = SaveLoadManager.GetChildXML(head, MyRoot.savepath);
            }

            base.FromXML(head);

            //Create children
            Children.Clear();
            List<XmlElement> list = new List<XmlElement>();
            foreach (XmlElement x in head.ChildNodes)
            {
                Objektname o;
                if (Enum.TryParse<Objektname>(x.Name, out o))
                {
                    list.Add(x);
                    PlaceableObjekt p = ObjektnameHelper.GetObjekt(o, this) as PlaceableObjekt;
                    Children.Add(p);
                }
                else if (x.Name == "SizeX")
                {
                    SizeX = int.Parse(x.InnerText);
                }
                else if (x.Name == "SizeY")
                {
                    SizeY = int.Parse(x.InnerText);
                }
                else if (x.Name == "RelativeRotation")
                {
                    RelativeRotation = (Direction)Enum.Parse(typeof(Direction), x.InnerText);
                }
                else if (x.Name == "Name")
                {
                    Name = x.InnerText;
                }
            }

            //fill children with attributes
            for (int i = 0; i < Children.Count(); i++)
            {
                if (Children[i].ObjectType != Objektname.Lever)
                {
                    Children[i].FromXML(list[i]);
                }
            }

            //Fill the Lever as last, because it can only load its connections if the 
            //corresponding flickable is already loaded
            for (int i = 0; i < Children.Count(); i++)
            {
                if (Children[i].ObjectType == Objektname.Lever)
                {
                    Children[i].FromXML(list[i]);
                }
            }

            CreateReturners(SizeX, SizeY, InputDirections.ToArray(), OutputDirections.ToArray(), InputCount, OutputCount);
        }

        public override void SetToMemento(PlaceableObjektMemento memento)
        {
            base.SetToMemento(memento);
            PlaceMemento m = (PlaceMemento)memento;
            Children.Clear();
            foreach (PlaceableObjektMemento p in m.children)
            {
                if (p.objektname != Objektname.Lever)
                {
                    PlaceableObjekt po = ObjektnameHelper.GetObjekt(p.objektname, this) as PlaceableObjekt;
                    po.SetToMemento(p);
                    Children.Add(po);
                }
            }

            //create levers as last, so that the connectionobject already exist
            foreach (PlaceableObjektMemento p in m.children)
            {
                if (p.objektname == Objektname.Lever)
                {
                    PlaceableObjekt po = ObjektnameHelper.GetObjekt(p.objektname, this) as PlaceableObjekt;
                    po.SetToMemento(p);
                    Children.Add(po);
                }
            }
            CurrentInputDirections.Clear();
            CurrentInputDirections.AddRange(InputDirections);
            CurrentOutputDirections.Clear();
            CurrentOutputDirections.AddRange(OutputDirections);
            SizeX = m.sizeX;
            SizeY = m.sizeY;
            RelativeRotation = m.relativeRotation;
            Name = m.name;
        }

        public override PlaceableObjektMemento CreateMemento()
        {
            return new PlaceMemento(Position, InputCount, OutputCount, Destructable, InputDirections, OutputDirections, ObjectType, Children, SizeX, SizeY, Name, RelativeRotation);
        }
    }

    public class PlaceMemento : PlaceableObjektMemento
    {
        public PlaceableObjektMemento[] children;
        public int sizeX;
        public int sizeY;
        public Direction relativeRotation;
        public string name;

        public PlaceMemento(Position position, int inputcount, int outputcount, bool destructable, List<Direction> inputdirections, List<Direction> outputdirections, Objektname objectname, List<PlaceableObjekt> children, int sizeX, int sizeY, string name, Direction relativeRotation)
            : base(position, inputcount, outputcount, destructable, inputdirections, outputdirections, objectname)
        {
            this.children = new PlaceableObjektMemento[children.Count()];
            this.sizeX = sizeX;
            this.sizeY = sizeY;
            this.relativeRotation = relativeRotation;
            for (int i = 0; i < children.Count(); i++)
            {
                this.children[i] = children[i].CreateMemento();
            }
            this.name = name;
        }
    }
}