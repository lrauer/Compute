﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Compute
{
    public class Place: PlaceableObjekt
    {

        //List of the children that live inside this place
        List<PlaceableObjekt> Children = new List<PlaceableObjekt>();

        public event EventHandler<MementoEventArgs> MementoCreation;
        public event EventHandler<MoveOrderEventArgs> MoveOrderBegin;
        public event EventHandler<MoveOrderEventArgs> MoveOrderEnd;

        public bool AddChild(PlaceableObjekt p)
        {
            if (p.Position.PosX > SizeX || p.Position.PosX * -1 > SizeX || p.Position.PosY > SizeY || p.Position.PosY * -1 > SizeY)
            {
                throw new ActionInvalidException("Cant add Child outside of the System", this);
            }
            if (!getRoot().isReady())
            {
                throw new ActionInvalidException("Cant change System while running", this);
            }
            if(GetChildAt(p.Position.PosX,p.Position.PosY) == null && !Children.Contains(p))
            {
                //undoable action, so create a Memento
                PlaceableObjektMemento pOld = this.createMemento();
                Children.Add(p);
                PlaceableObjektMemento pNew = this.createMemento();
                MementoCreation.Invoke(this, new MementoEventArgs(new MementoChange(this, pOld, pNew), 0, p.Position.PosX, 0, p.Position.PosY, null, p.Position.Parent, p.ObjectType));
                return true;
            }
            return false;
        }

        public bool CopyChild(int posX, int posY, int newPosX, int newPosY)
        {
            PlaceableObjekt pOld = GetChildAt(posX, posY);
            if (pOld == null || pOld.ObjectType == Objektname.Returner)
            {
                return false;
            }
            PlaceableObjekt p = ObjektnameHelper.getObjekt(pOld.ObjectType, pOld.Position.Parent) as PlaceableObjekt;
            //copy values from old Object
            p.setToMemento(pOld.createMemento());
            p.Position.SetValues(newPosX, newPosY, this);
            return (AddChild(p));

        }

        public List<PlaceableObjekt> getChildren()
        {
            return Children;
        }

        public bool RemoveChild(int posX, int posY)
        {
            if (!getRoot().isReady())
            {
                throw new ActionInvalidException("Cant change System while running", this);
            }
            PlaceableObjekt p = GetChildAt(posX, posY);
            if (p != null && p.Destructable)
            {
                //undoable action, so create a Memento
                PlaceableObjektMemento pOld = this.createMemento();
                Children.Remove(p);
                PlaceableObjektMemento pNew = this.createMemento();
                MementoCreation.Invoke(this, new MementoEventArgs(new MementoChange(this, pOld, pNew), p.Position.PosX, 0, p.Position.PosY, 0, p.Position.Parent, null, p.ObjectType));
                return true;
            }
            return false;
        }

        public bool ChangeChildPosition(int oldPosX,int oldPosY,int newPosX,int newPosY)
        {
            if (!getRoot().isReady())
            {
                throw new ActionInvalidException("Cant change System while running", this);
            }
            PlaceableObjekt p = GetChildAt(oldPosX, oldPosY);
            if (p != null && GetChildAt(newPosX, newPosY) == null && (oldPosX != newPosX || oldPosY != newPosY) && p.ObjectType != Objektname.Returner)
            {
                //undoable action, so create a Memento
                PlaceableObjektMemento pOld = p.createMemento();
                p.Position.SetValues(newPosX, newPosY, p.Position.Parent);
                PlaceableObjektMemento pNew = p.createMemento();
                MementoCreation.Invoke(this, new MementoEventArgs(new MementoChange(p, pOld, pNew), pOld.positionX, pNew.positionX, pOld.positionY, pNew.positionY, p.Position.Parent, p.Position.Parent, p.ObjectType));
                return true;
            }
            return false;
        }

        public PlaceableObjekt GetChildAt(int posX, int posY)
        {
            foreach (PlaceableObjekt p in Children)
            {
                if (p.Position.PosX == posX && p.Position.PosY == posY && p.Position.Parent == this)
                {
                    return p;
                }
            }
            return null;
        }

        public Moveable GetInputAt(int posX, int posY)
        {
            foreach (Moveable m in CurrentInput)
            {
                if (m.Position.PosX == posX && m.Position.PosY == posY && m.Position.Parent == this)
                {
                    return m;
                }
            }
            return null;
        }

        public bool ConnectLeverToFlickable(int lPosX, int lPosY, int fPosX, int fPosY)
        {
            if (!getRoot().isReady())
            {
                throw new ActionInvalidException("Cant change System while running", this);
            }
            Lever l = GetChildAt(lPosX, lPosY) as Lever;
            IFlickable f = GetChildAt(fPosX, fPosY) as IFlickable;
            if (l == null || f == null || l.Connection == f)
                return false;
            //undoable action, so create a Memento
            PlaceableObjektMemento pOld = l.createMemento();
            l.Connect(f);
            PlaceableObjektMemento pNew = l.createMemento();
            MementoCreation.Invoke(this, new MementoEventArgs(new MementoChange(l, pOld, pNew), pOld.positionX, pNew.positionX, pOld.positionY, pNew.positionY, l.Position.Parent, l.Position.Parent, l.ObjectType));
            return true;
        }

        public bool ChangeTargetValue(int posX, int posY, int value)
        {
            if (!getRoot().isReady())
            {
                throw new ActionInvalidException("Cant change System while running", this);
            }
            Comparer c = GetChildAt(posX, posY) as Comparer;
            if (c == null || c.TargetValue == value)
                return false;
            //undoable action, so create a Memento
            PlaceableObjektMemento pOld = c.createMemento();
            c.TargetValue = value;
            PlaceableObjektMemento pNew = c.createMemento();
            MementoCreation.Invoke(this, new MementoEventArgs(new MementoChange(c, pOld, pNew), pOld.positionX, pNew.positionX, pOld.positionY, pNew.positionY, c.Position.Parent, c.Position.Parent, c.ObjectType));
            return true;
        }

        public bool ChangeJumpTarget(int posX, int posY, int targetX, int targetY)
        {
            if (!getRoot().isReady())
            {
                throw new ActionInvalidException("Cant change System while running", this);
            }
            Jumper j = GetChildAt(posX, posY) as Jumper;
            if (j == null || (j.TargetPosition.PosX == targetX && j.TargetPosition.PosY == targetY))
                return false;
            //undoable action, so create a Memento
            PlaceableObjektMemento pOld = j.createMemento();
            j.TargetPosition.SetValues(targetX, targetY, j.TargetPosition.Parent);
            PlaceableObjektMemento pNew = j.createMemento();
            MementoCreation.Invoke(this, new MementoEventArgs(new MementoChange(j, pOld, pNew), pOld.positionX, pNew.positionX, pOld.positionY, pNew.positionY, j.Position.Parent, j.Position.Parent, j.ObjectType));
            return true;
        }

        public bool ChangeOutputDirection(int posX, int posY, Direction dOld, Direction dNew)
        {
            if (!getRoot().isReady())
            {
                throw new ActionInvalidException("Cant change System while running", this);
            }
            PlaceableObjekt p = GetChildAt(posX, posY);
            if (p == null || !p.OutputDirections.Contains(dOld) || dOld == dNew || p.ObjectType == Objektname.Returner || p.ObjectType == Objektname.Place)
                return false;
            //undoable action, so create a Memento
            PlaceableObjektMemento pOld = p.createMemento();
            p.OutputDirections.Remove(dOld);
            p.OutputDirections.Add(dNew);
            PlaceableObjektMemento pNew = p.createMemento();
            MementoCreation.Invoke(this, new MementoEventArgs(new MementoChange(p, pOld, pNew), pOld.positionX, pNew.positionX, pOld.positionY, pNew.positionY, p.Position.Parent, p.Position.Parent, p.ObjectType));
            return true;
        }

        //rotates for int quarters clockwise
        public bool Rotate(int posX, int posY, int quarters)
        {
            if (!getRoot().isReady())
            {
                throw new ActionInvalidException("Cant change System while running", this);
            }
            PlaceableObjekt p = GetChildAt(posX, posY);
            if (p == null || quarters < 1 || quarters > 3 || p.ObjectType == Objektname.Returner)
                return false;

            //undoable action, so create a Memento
            PlaceableObjektMemento pOld = p.createMemento();

            //place has a special rotationlogic
            if (p.ObjectType == Objektname.Place)
            {
                Place pl = p as Place;
                pl.RelativeRotation = DirectionHelper.Rotate(pl.RelativeRotation, quarters);
            }
            //rotate all directions for int quarters
            else
            {
                List<Direction> templist = new List<Direction>();
                foreach (Direction d in p.OutputDirections)
                {
                    templist.Add(DirectionHelper.Rotate(d, quarters));
                }
                p.OutputDirections.Clear();
                p.OutputDirections.AddRange(templist);
                templist.Clear();
                foreach (Direction d in p.InputDirections)
                {
                    templist.Add(DirectionHelper.Rotate(d, quarters));
                }
                p.InputDirections.Clear();
                p.InputDirections.AddRange(templist);
            } 
            PlaceableObjektMemento pNew = p.createMemento();
            MementoCreation.Invoke(this, new MementoEventArgs(new MementoChange(p, pOld, pNew), pOld.positionX, pNew.positionX, pOld.positionY, pNew.positionY, p.Position.Parent, p.Position.Parent, p.ObjectType));
            return true;
        }

        public bool ChangeBoundaries(int sizeX, int sizeY, Direction[] inputDirections, Direction[] outputDirections, int inputcount, int outputcount)
        {
            if (!getRoot().isReady())
            {
                throw new ActionInvalidException("Cant change System while running", this);
            }
            if (sizeX != SizeX || sizeY != SizeY || inputcount != InputCount || outputcount != OutputCount || !Enumerable.SequenceEqual(InputDirections.OrderBy(x => x), inputDirections.OrderBy(x => x)) || !Enumerable.SequenceEqual(OutputDirections.OrderBy(x => x), outputDirections.OrderBy(x => x)))
            {
                //undoable action, so create a Memento
                PlaceableObjektMemento pOld = this.createMemento();

                //remove all children out of new boundaries
                Children.RemoveAll(x => x.Position.PosX > sizeX);
                Children.RemoveAll(x => x.Position.PosX < sizeX * -1);
                Children.RemoveAll(x => x.Position.PosY > sizeY);
                Children.RemoveAll(x => x.Position.PosY < sizeY * -1);

                //remove all children where the returners will now be
                if(inputDirections.Contains(Direction.Right) || outputDirections.Contains(Direction.Right))
                    Children.Remove(GetChildAt(sizeX, 0));
                if (inputDirections.Contains(Direction.Left) || outputDirections.Contains(Direction.Left))
                    Children.Remove(GetChildAt(sizeX * -1, 0));
                if (inputDirections.Contains(Direction.Up) || outputDirections.Contains(Direction.Up))
                    Children.Remove(GetChildAt(0, sizeY));
                if (inputDirections.Contains(Direction.Down) || outputDirections.Contains(Direction.Down))
                    Children.Remove(GetChildAt(0, sizeY * -1));

                CreateReturners(sizeX, sizeY, inputDirections, outputDirections, inputcount, outputcount);

                PlaceableObjektMemento pNew = this.createMemento();
                MementoCreation.Invoke(this, new MementoEventArgs(new MementoChange(this, pOld, pNew), 0, 0, 0, 0, null, null, Objektname.Root));
                return true;
            }
            return false;
        }

        List<MoveTarget> _InputBuffer = new List<MoveTarget>();

        internal List<MoveTarget> InputBuffer
        {
            get { return _InputBuffer; }
            set { _InputBuffer = value; }
        }

        //for testing from where the inputs came this tick
        List<Direction> _CurrentInputDirections = new List<Direction>();

        public List<Direction> CurrentInputDirections
        {
            get { return _CurrentInputDirections; }
            set { _CurrentInputDirections = value; }
        }

        //for testing if the outputs are at the correkt directions
        List<Direction> _CurrentOutputDirections = new List<Direction>();

        public List<Direction> CurrentOutputDirections
        {
            get { return _CurrentOutputDirections; }
            set { _CurrentOutputDirections = value; }
        }

        int _SizeX;

        public int SizeX
        {
            get { return _SizeX; }
            set 
            {
                _SizeX = value;
                if (Children.Find(x => x.Position.PosX > value || x.Position.PosX * -1 > value) != null)
                {
                    throw new ActionInvalidException("Place is too small for existing children", this);
                }
            }
        }

        int _SizeY;

        public int SizeY
        {
            get { return _SizeY; }
            set 
            { 
                _SizeY = value;
                if (Children.Find(x => x.Position.PosY > value || x.Position.PosY * -1 > value) != null)
                {
                    throw new ActionInvalidException("Place is too small for existing children", this);
                }
            }
        }

        Direction _RelativeRotation;

        public Direction RelativeRotation
        {
            get { return _RelativeRotation; }
            set { _RelativeRotation = value; }
        }

        string _Name;

        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        //Create new empty place at position
        public Place(Position position, bool destructable, int sizeX, int sizeY, string name, Direction relativerotation, Direction[] inputDirections, Direction[] outputDirections, int inputcount, int outputcount)
            : base(position)
        {
            Position = position;

            Destructable = destructable;

            RelativeRotation = relativerotation;

            Name = name;
            
            CreateReturners(sizeX, sizeY, inputDirections,  outputDirections, inputcount, outputcount);

            MementoCreation += getRoot().Eventsystem.HandleMementoCreation;
            MoveOrderBegin += getRoot().Eventsystem.HandleMoveOrderBegin;
            MoveOrderEnd += getRoot().Eventsystem.HandleMoveOrderEnd;     
        }

        public void CreateReturners(int sizeX, int sizeY, Direction[] inputDirections, Direction[] outputDirections, int inputcount, int outputcount)
        {
            //add directions
            OutputDirections.Clear();
            OutputDirections.AddRange(outputDirections);
            InputDirections.Clear();
            InputDirections.AddRange(inputDirections);

            CurrentInputDirections.Clear();
            CurrentInputDirections.AddRange(InputDirections);
            CurrentOutputDirections.Clear();
            CurrentOutputDirections.AddRange(OutputDirections);

            InputCount = inputcount;
            OutputCount = outputcount;

            //remove all returner
            Children.RemoveAll(x => x.ObjectType == Objektname.Returner);

            //set Size of the place. Size goes in each direction (e.g. 5 means from -5 to 5 --> 11 tiles)
            SizeX = sizeX;
            SizeY = sizeY;

            //each place has a fixed children as returners
            //only add necessary returners
            if (OutputDirections.Contains(Direction.Left) || InputDirections.Contains(Direction.Left))
            {
                Children.Add(new Returner(new Position(-1 * SizeX, 0, this), Direction.Right, false, InputDirections.Contains(Direction.Left), OutputDirections.Contains(Direction.Left)));
            }
            if (OutputDirections.Contains(Direction.Right) || InputDirections.Contains(Direction.Right))
            {
                Children.Add(new Returner(new Position(SizeX, 0, this), Direction.Left, false, InputDirections.Contains(Direction.Right), OutputDirections.Contains(Direction.Right)));
            }
            if (OutputDirections.Contains(Direction.Up) || InputDirections.Contains(Direction.Up))
            {
                Children.Add(new Returner(new Position(0, SizeY, this), Direction.Down, false, InputDirections.Contains(Direction.Up), OutputDirections.Contains(Direction.Up)));
            }
            if (OutputDirections.Contains(Direction.Down) || InputDirections.Contains(Direction.Down))
            {
                Children.Add(new Returner(new Position(0, -1 * SizeY, this), Direction.Up, false, InputDirections.Contains(Direction.Down), OutputDirections.Contains(Direction.Down)));
            }
        }

        public override bool PrepareTick()
        {

            if (CurrentInput.Count < InputCount)
                return false;
            if (CurrentInput.Count == InputCount)
            {
                //reset outputcounter
                ReleasedOutput = 0;
                CurrentInputDirections.Clear();
                CurrentInputDirections.AddRange(InputDirections);
                CurrentOutputDirections.Clear();
                CurrentOutputDirections.AddRange(OutputDirections);
                return true;
            }

            throw new ActionInvalidException("This Place can only process " + InputCount + " inputs",this);
        }

        //how much output is processed
        int _ReleasedOutput;

        public int ReleasedOutput
        {
            get { return _ReleasedOutput; }
            set { _ReleasedOutput = value; }
        }

        //tick childs until this place finished 1 tick
        public override void ExecuteTick()
        {
            //step the children until this place finished 1 tick (got rid of all inputs)
            do
            {
                Substep();
            } while (InputBuffer.Count > 0);
        }

        //how many substaps per inputs
        int supstepcounter;

        //just do 1 tick for each child
        public void Substep()
        {
            supstepcounter++;
            //new step in this Execute
            getRoot().CurrentExecute.Steps++;
            //if 10000 steps since last input we are most likely broken
            if (supstepcounter > 10000)
            {
                throw new ActionInvalidException("System is looping or too slow", this);
            }
            //first distribute new inputs for the children
            foreach (MoveTarget m in InputBuffer)
            {
                MoveOrder mo = new MoveOrder(m.Mover, m.Origin);
                m.Target.ReceiveInput(mo);
                MoveOrderEnd.Invoke(this, new MoveOrderEventArgs(mo, m));
            }
            InputBuffer.Clear();

            foreach (PlaceableObjekt p in Children)
            {
                if (p.PrepareTick())
                    p.ExecuteTick();
            }
            
            //too few outputs
            if (InputBuffer.Count == 0)
            {
                if (ReleasedOutput != OutputCount)
                {
                    throw new ActionInvalidException("System released " + ReleasedOutput + " outputs but should release " + OutputCount, this);
                }
                else if (CurrentInput.Count > 0)
                {
                    throw new ActionInvalidException("System released all outputs, but is still running (looping)", this);
                }
            }
        }

        public override void Reset()
        {
            InputBuffer.Clear();
            CurrentInput.Clear();
            ReleasedOutput = 0;
            CurrentInputDirections.Clear();
            CurrentInputDirections.AddRange(InputDirections);
            CurrentOutputDirections.Clear();
            CurrentOutputDirections.AddRange(OutputDirections);
            foreach (PlaceableObjekt p in Children)
            {
                p.Reset();
            }
        }

        public override void ReceiveInput(MoveOrder moveOrder)
        {
            //calculate direction for relativeRotation
            moveOrder.Order = DirectionHelper.Rotate(moveOrder.Order, 4 - DirectionHelper.GetRotation(RelativeRotation));

            if (CurrentInputDirections.Contains(moveOrder.Order))
            {
                CurrentInputDirections.Remove(moveOrder.Order);
            }
            else
            {
                throw new ActionInvalidException("Invalid direction to receive Input for this Place", this);
            }
            //new inputs means system changed
            supstepcounter = 0;
            CurrentInput.Add(moveOrder.Objekt);
            Direction oldDirection = moveOrder.Order;
            //ReceiveInput to signify the moveable was passed down from parent to child
            moveOrder.Order = Direction.Parent;
            //pass it to the right returner depending on from which direction the input came (inputdirection is always inverted outputdirection)
            PlaceableObjekt r = Children.Find(x => x.ObjectType == Objektname.Returner && x.OutputDirections.Contains(DirectionHelper.Invert(oldDirection)));
            //only receive if the returner can accept inputs from the parent
            if (r != null && r.InputDirections.Contains(Direction.Parent))
            {
                moveOrder.Objekt.Position.Copy(r.Position);
                r.ReceiveInput(moveOrder);
            }
            else
            {
                throw new ActionInvalidException("Invalid direction to receive Input for this Place", this);
            }
        }

        public override void ReleaseOutput(MoveOrder moveOrder)
        {
            //check if its an output for this element or will just be moved
            //if it is a child of this place it will be released to the next level
            if (moveOrder.Objekt.Position.Parent == this)
            {
                CurrentInput.Remove(moveOrder.Objekt);
                //has released an output
                ReleasedOutput++;

                //too many outputs
                if (OutputCount < ReleasedOutput)
                {
                    throw new ActionInvalidException("System released " + ReleasedOutput + " outputs but should release " + OutputCount, this);
                }

                if (CurrentOutputDirections.Contains(moveOrder.Order))
                {
                    CurrentOutputDirections.Remove(moveOrder.Order);
                }
                else
                {
                    throw new ActionInvalidException("Invalid direction to release output for this Place", this);
                }

                //calculate direction for relativeRotation
                moveOrder.Order = DirectionHelper.Rotate(moveOrder.Order, DirectionHelper.GetRotation(RelativeRotation));

                Position.Parent.ReleaseOutput(moveOrder);
            }
            else
            {
                //return it to level of this place before it will be input for the next child
                moveOrder.Objekt.Position.Copy(moveOrder.Objekt.Position.Parent.Position);
                //determine the parent at target position
                int x = moveOrder.Objekt.Position.PosX;
                int y = moveOrder.Objekt.Position.PosY;
                switch (moveOrder.Order)
                {
                    case Direction.Down:
                        y--;
                        break;
                    case Direction.Up:
                        y++;
                        break;
                    case Direction.Left:
                        x--;
                        break;
                    case Direction.Right:
                        x++;
                        break;
                }
                moveOrder.Order = DirectionHelper.Invert(moveOrder.Order);
                PlaceableObjekt child = Children.Find(i => i.Position.PosX == x && i.Position.PosY == y);

                if (child == null)
                {
                    throw new ActionInvalidException("Can't input to empty position", this);
                }
                //add to bufferlist with new parent
                MoveTarget m = new MoveTarget(child, moveOrder.Objekt, moveOrder.Order);
                InputBuffer.Add(m);
                MoveOrder mo = new MoveOrder(m.Mover, m.Origin);
                MoveOrderBegin.Invoke(this, new MoveOrderEventArgs(mo, m));
            }
        }

        public void AddCurrentInput(Moveable m)
        {
            CurrentInput.Add(m);
            //add reference to parentplace as well
            if (getRoot() != Position.Parent)
            {
                Place p = Position.Parent as Place;
                p.AddCurrentInput(m);
            }
        }

        public void RemoveCurrentInput(Moveable m)
        {
            CurrentInput.Remove(m);
            //remove reference from parentplace as well
            if (getRoot() != Position.Parent)
            {
                Place p = Position.Parent as Place;
                p.RemoveCurrentInput(m);
            }
        }

        public int getSpace()
        {
            int i = (SizeX*2+1) * (SizeY*2+1);
            foreach (PlaceableObjekt p in Children)
            {
                if (p.ObjectType == Objektname.Place)
                {
                    Place pl = p as Place;
                    i += pl.getSpace();
                }
            }
            return i;
        }

        public int getObjectcount()
        {
            int i = 0;
            foreach (PlaceableObjekt p in Children)
            {
                i++;
                if (p.ObjectType == Objektname.Place)
                {
                    Place pl = p as Place;
                    i += pl.getObjectcount();
                }
            }
            return i;
        }

        public void ToXMLComplete(XmlDocument doc, XmlElement head)
        {
            ToXMLBase(doc, head);

            //save attributes
            XmlElement e;

            //create a new element for each child
            foreach (PlaceableObjekt p in Children)
            {
                e = doc.CreateElement(p.ObjectType.ToString());
                //save the childplace completely in this file
                if (p.ObjectType == Objektname.Place)
                {
                    Place pl = p as Place;
                    pl.ToXML(doc, e);
                }
                else
                {
                    p.ToXML(doc, e);
                }
                head.AppendChild(e);
            }
        }

        public override void ToXML(XmlDocument doc, XmlElement head)
        {
            ToXMLBase(doc, head);

            //save attributes
            XmlElement e;

            //create a new element for each child
            foreach (PlaceableObjekt p in Children)
            {
                e = doc.CreateElement(p.ObjectType.ToString());
                //save only reference to childplaces with their rotation
                if (p.ObjectType == Objektname.Place)
                {
                    Place pl = p as Place;
                    XmlElement e2;
                    //Name
                    e2 = doc.CreateElement("Name");
                    e2.InnerXml = pl.Name;
                    e.AppendChild(e2);

                    //position
                    e2 = doc.CreateElement("Position");
                    e2.InnerXml = pl.Position.PosX + "," + pl.Position.PosY;
                    e.AppendChild(e2);

                    //destructable
                    e2 = doc.CreateElement("Destructable");
                    e2.InnerXml = "" + pl.Destructable;
                    e.AppendChild(e2);

                    //RelativeRotation
                    e2 = doc.CreateElement("RelativeRotation");
                    e2.InnerXml = "" + pl.RelativeRotation;
                    e.AppendChild(e2);

                }
                else
                {
                    p.ToXML(doc, e);
                }
                head.AppendChild(e);
            }
        }

        public void ToXMLBase(XmlDocument doc, XmlElement head)
        {
            base.ToXML(doc, head);

            //save attributes
            XmlElement e;

            //Name
            e = doc.CreateElement("Name");
            e.InnerXml = Name;
            head.AppendChild(e);

            //SizeX
            e = doc.CreateElement("SizeX");
            e.InnerXml = "" + SizeX;
            head.AppendChild(e);

            //SizeY
            e = doc.CreateElement("SizeY");
            e.InnerXml = "" + SizeY;
            head.AppendChild(e);

            //RelativeRotation
            e = doc.CreateElement("RelativeRotation");
            e.InnerXml = "" + RelativeRotation;
            head.AppendChild(e);
        }

        public override void FromXML(XmlElement head)
        {
            //load Place from its own XML File if its not in this file
            //in that case thee are only the 4 positionelements: position, name, destructable, rotation
            if (head.ChildNodes.Count == 4)
            {
                head = SaveLoadManager.getChildXML(head);
            }

            base.FromXML(head);

            //Create children
            Children.Clear();
            List<XmlElement> list = new List<XmlElement>();
            foreach (XmlElement x in head.ChildNodes)
            {
                Objektname o;
                if (Enum.TryParse<Objektname>(x.Name, out o))
                {
                    list.Add(x);
                    PlaceableObjekt p = ObjektnameHelper.getObjekt(o, this) as PlaceableObjekt;
                    Children.Add(p);
                }
                else if (x.Name == "SizeX")
                {
                    SizeX = int.Parse(x.InnerText);
                }
                else if (x.Name == "SizeY")
                {
                    SizeY = int.Parse(x.InnerText);
                }
                else if (x.Name == "RelativeRotation")
                {
                    RelativeRotation = (Direction)Enum.Parse(typeof(Direction), x.InnerText);
                }
                else if (x.Name == "Name")
                {
                    Name = x.InnerText;
                }
            }

            //fill children with attributes
            for(int i = 0; i < Children.Count; i++)
            {
                if (Children[i].ObjectType != Objektname.Lever)
                {
                    Children[i].FromXML(list[i]);
                }
            }

            //Fill the Lever as last, because it can only load its connections if the 
            //corresponding flickable is already loaded
            for (int i = 0; i < Children.Count; i++)
            {
                if (Children[i].ObjectType == Objektname.Lever)
                {
                    Children[i].FromXML(list[i]);
                }
            }

            CurrentInputDirections.Clear();
            CurrentInputDirections.AddRange(InputDirections);
            CurrentOutputDirections.Clear();
            CurrentOutputDirections.AddRange(OutputDirections);
        }

        public override void setToMemento(PlaceableObjektMemento memento)
        {
            base.setToMemento(memento);
            PlaceMemento m = (PlaceMemento)memento;
            Children.Clear();
            foreach (PlaceableObjektMemento p in m.children)
            {
                if (p.objektname != Objektname.Lever)
                {
                    PlaceableObjekt po = ObjektnameHelper.getObjekt(p.objektname, this) as PlaceableObjekt;
                    po.setToMemento(p);
                    Children.Add(po);
                }
            }

            //create levers as last, so that the connectionobject already exist
            foreach (PlaceableObjektMemento p in m.children)
            {
                if (p.objektname == Objektname.Lever)
                {
                    PlaceableObjekt po = ObjektnameHelper.getObjekt(p.objektname, this) as PlaceableObjekt;
                    po.setToMemento(p);
                    Children.Add(po);
                }
            }
            CurrentInputDirections.Clear();
            CurrentInputDirections.AddRange(InputDirections);
            CurrentOutputDirections.Clear();
            CurrentOutputDirections.AddRange(OutputDirections);
            SizeX = m.sizeX;
            SizeY = m.sizeY;
            RelativeRotation = m.relativeRotation;
            Name = m.name;
        }

        public override PlaceableObjektMemento createMemento()
        {
            return new PlaceMemento(Position, InputCount, OutputCount, Destructable, InputDirections, OutputDirections, ObjectType, Children, SizeX, SizeY, Name, RelativeRotation);
        }
    }

    public class PlaceMemento: PlaceableObjektMemento
    {
        public PlaceableObjektMemento[] children;
        public int sizeX;
        public int sizeY;
        public Direction relativeRotation;
        public string name;

        public PlaceMemento(Position position, int inputcount, int outputcount, bool destructable, List<Direction> inputdirections, List<Direction> outputdirections, Objektname objectname, List<PlaceableObjekt> children, int sizeX, int sizeY, string name, Direction relativeRotation)
            : base(position, inputcount, outputcount, destructable, inputdirections, outputdirections, objectname)
        {
            this.children = new PlaceableObjektMemento[children.Count];
            this.sizeX = sizeX;
            this.sizeY = sizeY;
            this.relativeRotation = relativeRotation;
            for (int i = 0; i < children.Count; i++)
            {
                this.children[i] = children[i].createMemento();
            }
            this.name = name;
        }
    }
}