﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public class Switch : ConveyorBelt, IFlickable, IActivatable
    {

        public event EventHandler<ActivatedEventArgs> SwitchActivated;

        bool _Activated;

        public bool GetState()
        {
            return Activated;
        }

        public bool Activated
        {
            get { return _Activated; }
            set 
            {
                if (_Activated != value)
                {
                    bool oldActivated = _Activated;
                    _Activated = value;
                    SwitchActivated.Invoke(this, new ActivatedEventArgs(oldActivated, value, Position.PosX, Position.PosX, Position.PosY, Position.PosY, Position.Parent, Position.Parent, ObjectType));
                }
            }
        }

        public Switch(Position position, Root root, Direction output, Direction alternative, bool destructable)
            : base(position, root, output, destructable)
        {
            OutputDirections.Add(alternative);
            Activated = false;
            SwitchActivated += root.Eventsystem.HandleSwitchActivated;   
        }

        public override void ExecuteTick()
        {
            if (Activated)
            {
                ReleaseOutput(new MoveOrder(CurrentInput[0], OutputDirections[0]));
            }
            else
            {
                ReleaseOutput(new MoveOrder(CurrentInput[0], OutputDirections[1]));
            }
        }

        public void Flick()
        {
            Activated = !Activated;
        }

        public override void Reset()
        {
            base.Reset();
            Activated = false;
        }
        public override int GetSpace()
        {
            return 0;
        }

        public override int GetObjectcount()
        {
            return 1;
        }

        public override int GetDistance()
        {
            return 1;
        }

        public override int GetSteps()
        {
            return 1;
        }

        public override string GetDescription()
        {
            return "Takes 1 input and releases in the first outputdirection if activated. Otherwise it releases in the other direction. Changes activationstate if triggered.";
        }

    }
}
