﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Compute
{
    public abstract class PlaceableObjekt : Worldobjekt, IPlaceable
    {

        public PlaceableObjekt(Position position)
            : base(position)
        {

        }

        List<Direction> _InputDirections = new List<Direction>();
        public List<Direction> InputDirections
        {
            get
            {
                return _InputDirections;
            }
            set
            {
                _InputDirections = value;
            }
        }
        List<Direction> _OutputDirections = new List<Direction>();
        public List<Direction> OutputDirections
        {
            get
            {
                return _OutputDirections;
            }
            set
            {
                _OutputDirections = value;
            }
        }

        int _InputCount;
        public int InputCount
        {
            get
            {
                return _InputCount;
            }
            set
            {
                _InputCount = value;
            }
        }

        List<Moveable> _CurrentInput = new List<Moveable>();
        public List<Moveable> CurrentInput
        {
            get
            {
                return _CurrentInput;
            }
            set
            {
                _CurrentInput = value;
            }
        }
        int _OutputCount;
        public int OutputCount
        {
            get
            {
                return _OutputCount;
            }
            set
            {
                _OutputCount = value;
            }
        }

        bool _Destructable;
        public bool Destructable
        {
            get
            {
                return _Destructable;
            }
            set
            {
                _Destructable = value;
            }
        }

        public abstract bool PrepareTick();

        public abstract void ExecuteTick();

        public abstract void ReceiveInput(MoveOrder moveOrder);

        public abstract void ReleaseOutput(MoveOrder moveOrder);

        public abstract void Reset();

        public virtual void ToXML(XmlDocument doc, XmlElement head)
        {
            //save attributes
            XmlElement e;

            //position
            e = doc.CreateElement("Position");
            e.InnerXml = Position.PosX + "," + Position.PosY;
            head.AppendChild(e);

            //inputcount
            e = doc.CreateElement("InputCount");
            e.InnerXml = "" + InputCount;
            head.AppendChild(e);

            //outputcount
            e = doc.CreateElement("OutputCount");
            e.InnerXml = "" + OutputCount;
            head.AppendChild(e);

            //destructable
            e = doc.CreateElement("Destructable");
            e.InnerXml = "" + Destructable;
            head.AppendChild(e);

            //inputdirections
            foreach (Direction d in InputDirections)
            {
                e = doc.CreateElement("InputDirection");
                e.InnerXml = d.ToString();
                head.AppendChild(e);
            }

            //outputdirections
            foreach (Direction d in OutputDirections)
            {
                e = doc.CreateElement("OutputDirection");
                e.InnerXml = d.ToString();
                head.AppendChild(e);
            }
        }

        public virtual void FromXML(XmlElement head)
        {
            InputDirections.Clear();
            OutputDirections.Clear();
            foreach (XmlElement e in head.ChildNodes)
            {
                if (e.Name == "InputDirection")
                {
                    InputDirections.Add((Direction)Enum.Parse(typeof(Direction), e.InnerText));
                }
                if (e.Name == "OutputDirection")
                {
                    OutputDirections.Add((Direction)Enum.Parse(typeof(Direction), e.InnerText));
                }
                if (e.Name == "Position")
                {
                    Position.SetValues(int.Parse(e.InnerText.Split(',')[0]), int.Parse(e.InnerText.Split(',')[1]), Position.Parent);
                }
                if (e.Name == "InputCount")
                {
                    InputCount = int.Parse(e.InnerText);
                }
                if (e.Name == "OutputCount")
                {
                    OutputCount = int.Parse(e.InnerText);
                }
                if (e.Name == "Destructable")
                {
                    Destructable = bool.Parse(e.InnerText);
                }              
            }

        }

        public virtual void setToMemento(PlaceableObjektMemento memento)
        {
            Position.SetValues(memento.positionX, memento.positionY, Position.Parent);
            InputCount = memento.inputcount;
            OutputCount = memento.outputcount;
            Destructable = memento.destructable;
            InputDirections.Clear();
            InputDirections.AddRange(memento.inputdirections);
            OutputDirections.Clear();
            OutputDirections.AddRange(memento.outputdirections);
        }

        public abstract PlaceableObjektMemento createMemento();

    }

    public abstract class PlaceableObjektMemento
    {
        public int positionX;
        public int positionY;
        public int inputcount;
        public int outputcount;
        public bool destructable;
        public Direction[] inputdirections;
        public Direction[] outputdirections;
        public Objektname objektname;

        public PlaceableObjektMemento(Position position, int inputcount, int outputcount, bool destructable,List<Direction> inputdirections, List<Direction> outputdirections, Objektname objektname)
        {
            this.positionX = position.PosX;
            this.positionY = position.PosY;
            this.inputcount = inputcount;
            this.outputcount = outputcount;
            this.destructable = destructable;
            this.inputdirections = new Direction[inputdirections.Count];
            inputdirections.CopyTo(this.inputdirections);
            this.outputdirections = new Direction[outputdirections.Count];
            outputdirections.CopyTo(this.outputdirections);
            this.objektname = objektname;
        }
    }
}
