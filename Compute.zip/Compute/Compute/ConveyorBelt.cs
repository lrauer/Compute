﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Compute
{
    public class ConveyorBelt: PlaceableObjekt
    {

        public ConveyorBelt(Position position, Root root, Direction output, bool destructable)
            : this(position, root, destructable)
        { 
            OutputDirections.Add(output);
        }

        public ConveyorBelt(Position position, Root root, bool destructable)
            : base(position, root)
        {
            Position = position;
            InputDirections.Add(Direction.Up);
            InputDirections.Add(Direction.Down);
            InputDirections.Add(Direction.Left);
            InputDirections.Add(Direction.Right);
            Destructable = destructable;
            InputCount = 1;
            OutputCount = 1;
        }

        public override bool PrepareTick()
        {
            switch (CurrentInput.Count)
            {
                case 0:
                    return false;
                case 1:
                    return true;
                default:
                    throw new ActionInvalidException("This Object can only process 1 input", this, Position);
            }
        }

        public override void ExecuteTick()
        {
            ReleaseOutput(new MoveOrder(CurrentInput[0],OutputDirections[0]));
        }

        public override void Reset()
        {
            CurrentInput.Clear();
        }

        public override void ReceiveInput(MoveOrder moveOrder)
        {
            if(!InputDirections.Contains(moveOrder.Order))
            {
                throw new ActionInvalidException("This Object cant process Inputs from this direction", this, Position);
            }
            CurrentInput.Add(moveOrder.Objekt);
            moveOrder.Objekt.Position.SetValues(0, 0, this);
        }

        public override void ReleaseOutput(MoveOrder moveOrder)
        {
            CurrentInput.Clear();
            Position.Parent.ReleaseOutput(moveOrder);
        }

        public override int GetSpace()
        {
            return 0;
        }

        public override int GetObjectcount()
        {
            return 1;
        }

        public override int GetDistance()
        {
            return 1;
        }

        public override int GetSteps()
        {
            return 1;
        }

        public override string GetDescription()
        {
            return "Takes 1 input and releases it in the outputdirection.";
        }

        public override PlaceableObjektMemento CreateMemento()
        {
            return new ConveyorBeltMemento(Position, InputCount, OutputCount, Destructable, InputDirections, OutputDirections, ObjectType);
        }

    }

    public class ConveyorBeltMemento : PlaceableObjektMemento
    {

        public ConveyorBeltMemento(Position position, int inputcount, int outputcount, bool destructable, List<Direction> inputdirections, List<Direction> outputdirections, Objektname objektname)
            : base(position, inputcount, outputcount, destructable, inputdirections, outputdirections, objektname)
        {

        }
    }

}
