﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public interface IFlickable
    {

        //flick the state of the flickable to the next state
        void Flick();

    }
}
