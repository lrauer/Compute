﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public class MoveOrderEventArgs : EventArgs
    {
        MoveOrder _Order;

        public MoveOrder Order
        {
            get { return _Order; }
            set { _Order = value; }
        }

        MoveTarget _Target;

        public MoveTarget Target
        {
            get { return _Target; }
            set { _Target = value; }
        }

        public Position getOriginPosition()
        {
            return DirectionHelper.GetFromPosition(Target.Target.Position, DirectionHelper.Invert(Order.Order));
        }

        public Position getNewPosition()
        {
            return Target.Target.Position;
        }

        public MoveOrderEventArgs(MoveOrder mo, MoveTarget mt)
        {
            Order = mo;
            Target = mt;
        }
    }
}
