﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public class MemoryEventArgs : PositionEventArgs
    {
        int _OldMemory;

        public int OldMemory
        {
            get { return _OldMemory; }
            set { _OldMemory = value; }
        }

        int _NewMemory;

        public int NewMemory
        {
            get { return _NewMemory; }
            set { _NewMemory = value; }
        }

        public MemoryEventArgs(int oldMemory, int newMemory, int oldPositionX, int newPositionX, int oldPositionY, int newPositionY, PlaceableObjekt oldPositionParent, PlaceableObjekt newPositionParent, Objektname ownerType)
            : base(oldPositionX, newPositionX, oldPositionY, newPositionY, oldPositionParent, newPositionParent, ownerType)
        {
            OldMemory = oldMemory;
            NewMemory = newMemory;
        }
    }
}
