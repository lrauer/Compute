﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public class Memory: AssemblyLine
    {

        public event EventHandler<MemoryEventArgs> MemoryChanged;

        Direction LastInput;

        int _SavedValue;

        public int SavedValue
        {
            get { return _SavedValue; }
            set 
            {
                if (_SavedValue != value)
                {
                    int oldSavedValue = _SavedValue;
                    _SavedValue = value;
                    MemoryChanged.Invoke(this, new MemoryEventArgs(oldSavedValue, value, Position.PosX, Position.PosX, Position.PosY, Position.PosY, Position.Parent, Position.Parent, ObjectType));
                }
            }
        }

        public Memory(Position position, Root root, Direction output, bool destructable)
            : base(position, root, output, destructable)
        {
            SavedValue = 0;
            MemoryChanged += root.Eventsystem.HandleMemoryChanged;   
        }

        public override void ExecuteTick()
        {
            //first Direction is the Writedirection 
            //This is normally Up
            if (LastInput == InputDirections[0])
            {
                SavedValue = CurrentInput[0].Value;
            }
            //else we read the value
            else
            {
                CurrentInput[0].Value = SavedValue;
            }
            ReleaseOutput(new MoveOrder(CurrentInput[0], OutputDirections[0]));
        }

        public override void ReceiveInput(MoveOrder moveOrder)
        {
            base.ReceiveInput(moveOrder);
            LastInput = moveOrder.Order;
        }

        public override void Reset()
        {
            base.Reset();
            SavedValue = 0;
        }
    }
}
