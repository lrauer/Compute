﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public class Creator: Comparer, IFlickable
    {
        public Creator(Position position, Root root, Direction output, int targetValue, bool destructable)
            : base(position, root, output, targetValue, destructable)
        {

        }

        public void Flick()
        {
            //create new moveable as child for this Creator
            Moveable m = new Moveable(new Position(0, 0, this), MyRoot, TargetValue);
            CurrentInput.Add(m);
            //add reference to parentplace as well
            Place p = Position.Parent as Place;
            p.AddCurrentInput(m);
        }
    }
}
