﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public class MementoEventArgs: PositionEventArgs
    {
        MementoChange _ChangeOperation;

        internal MementoChange ChangeOperation
        {
            get { return _ChangeOperation; }
            set { _ChangeOperation = value; }
        }

        public MementoEventArgs(MementoChange changeOperation, int oldPositionX, int newPositionX, int oldPositionY, int newPositionY, PlaceableObjekt oldParent, PlaceableObjekt newParent, Objektname ownerType)
            : base(oldPositionX, newPositionX, oldPositionY, newPositionY, oldParent, newParent, ownerType)
        {
            ChangeOperation = changeOperation;
        }
    }
}
