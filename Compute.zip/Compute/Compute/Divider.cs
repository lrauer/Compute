﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    class Divider : Melter
    {
        public Divider(Position position, Root root, Direction output, Direction outputMod, bool destructable)
            : base(position, root, output, destructable)
        {
            OutputDirections.Add(outputMod);
            OutputCount = 2;
        }

        public override void ExecuteTick()
        {
            if (CurrentInput[1].Value == 0)
                throw new ActionInvalidException("Cant divide by Zero", this, Position);
            //create new moveable as child for this Divider
            Moveable m = new Moveable(new Position(0, 0, this), MyRoot, CurrentInput[0].Value % CurrentInput[1].Value);
            //add reference to parentplace as well
            Place p = Position.Parent as Place;
            p.AddCurrentInput(m);
            CurrentInput[0].Value /= CurrentInput[1].Value;
            base.ExecuteTick();
            ReleaseOutput(new MoveOrder(m, OutputDirections[1]));
        }
    }
}
