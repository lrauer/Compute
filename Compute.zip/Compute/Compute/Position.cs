﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Compute
{
    public class Position : IComparable
    {

        public event EventHandler<PositionEventArgs> PositionChanged;

        int _PosX;

        public int PosX
        {
            get { return _PosX; }
            private set
            {
                _PosX = value;
            }
        }

        int _PosY;

        public int PosY
        {
            get { return _PosY; }
            private set
            {
                _PosY = value;
            }
        }

        public void SetValues(int x, int y, PlaceableObjekt parent)
        {
            int oldX = PosX;
            int oldY = PosY;
            PlaceableObjekt oldParent = Parent;
            PosX = x;
            PosY = y;
            Parent = parent;
            if (PositionChanged != null)
                PositionChanged.Invoke(this, new PositionEventArgs(oldX, x, oldY, y, oldParent, parent, Owner.ObjectType));
        }

        Worldobjekt _Owner;

        public Worldobjekt Owner
        {
            get { return _Owner; }
            set { _Owner = value; }
        }

        PlaceableObjekt _Parent;

        public PlaceableObjekt Parent
        {
            get { return _Parent; }
            private set
            {
                _Parent = value;
            }
        }

        public Position(int posX, int posY, PlaceableObjekt parent)
        {
            _PosX = posX;
            _PosY = posY;
            _Parent = parent;
            if (parent != null)
            {
                PositionChanged += parent.GetEventsystem().HandlePositionChanged;
            }
        }

        public void Copy(Position position)
        {
            SetValues(position.PosX, position.PosY, position.Parent);
        }

        public static Position Default()
        {
            return new Position(0, 0, null);
        }

        public override string ToString()
        {
            return PosX + ", " + PosY;
        }

        public override bool Equals(object other)
        {
            Position p = other as Position;

            if (p == null)
            {
                return false;
            }
            if (PosX == p.PosX && PosY == p.PosY && Parent == p.Parent && Owner == p.Owner)
            {
                return true;
            }

            return false;
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public int CompareTo(object obj)
        {
            Position p = (Position)obj;
            //different Parents are not comparable
            if (Parent != p.Parent)
            {
                return 0;
            }

            //else compare PosX and PosY
            //to go from top left to bottom right we prefer biggest Y and after that smallest X
            if (PosY < p.PosY)
            {
                return 1;
            }
            else if (PosY > p.PosY)
            {
                return -1;
            }
            else
            {
                if (PosX > p.PosX)
                {
                    return 1;
                }
                else if (PosX < p.PosX)
                {
                    return -1;
                }
                else
                {
                    return 0;
                }                
            }            
        }
    }
}
