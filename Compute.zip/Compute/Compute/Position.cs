﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Compute
{
    public class Position
    {

        public event EventHandler<PositionEventArgs> PositionChanged;

        int _PosX;

        public int PosX
        {
            get { return _PosX; }
           private set 
            {
                _PosX = value;
            }
        }

        int _PosY;

        public int PosY
        {
            get { return _PosY; }
            private set 
            {
                _PosY = value;
            }
        }

        public void SetValues(int x, int y, PlaceableObjekt parent)
        {
            int oldX = PosX;
            int oldY = PosY;
            PlaceableObjekt oldParent = Parent;
            PosX = x;
            PosY = y;
            Parent = parent;
            if (PositionChanged != null)
                PositionChanged.Invoke(this, new PositionEventArgs(oldX, x, oldY, y, oldParent, parent, Owner.ObjectType));
        }

        Worldobjekt _Owner;

        public Worldobjekt Owner
        {
            get { return _Owner; }
            set { _Owner = value; }
        }

        PlaceableObjekt _Parent;

        public PlaceableObjekt Parent
        {
            get { return _Parent; }
            private set 
            {
                _Parent = value;
            }
        }

        public Position(int posX, int posY, PlaceableObjekt parent)
        {
            _PosX = posX;
            _PosY = posY;
            _Parent = parent;
            if (parent != null)
            {
                PositionChanged += parent.getEventsystem().HandlePositionChanged;
            }
        }

        public void Copy(Position position)
        {
            SetValues(position.PosX, position.PosY, position.Parent);
        }

        public static Position Default()
        {
            return new Position(0, 0, null);
        }
    }
}
