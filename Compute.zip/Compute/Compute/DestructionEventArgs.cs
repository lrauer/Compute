﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public class DestructionEventArgs: PositionEventArgs
    {

        Moveable _DestructedMoveable;

        public Moveable DestructedMoveable
        {
            get { return _DestructedMoveable; }
            set { _DestructedMoveable = value; }
        }

        public DestructionEventArgs(int oldPositionX, int newPositionX, int oldPositionY, int newPositionY, PlaceableObjekt oldPositionParent, PlaceableObjekt newPositionParent, Objektname ownerType, Moveable destructedMoveable)
            :base(oldPositionX, newPositionX, oldPositionY, newPositionY, oldPositionParent, newPositionParent, ownerType)
        {
            DestructedMoveable = destructedMoveable;
        }
    }
}
