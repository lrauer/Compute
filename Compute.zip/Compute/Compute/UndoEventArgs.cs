﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public class UndoEventArgs: PositionEventArgs
    {

        Stack<MementoChange> _Stack;

        internal Stack<MementoChange> Stack
        {
          get { return _Stack; }
          set { _Stack = value; }
        }

        MementoChange _Action;

        public MementoChange Action
        {
            get { return _Action; }
            set { _Action = value; }
        }

        public UndoEventArgs(MementoChange action, Stack<MementoChange> stack, int oldPositionX, int newPositionX, int oldPositionY, int newPositionY, PlaceableObjekt oldParent, PlaceableObjekt newParent, Objektname ownerType)
            : base(oldPositionX, newPositionX, oldPositionY, newPositionY, oldParent, newParent, ownerType)
        {
            Stack = stack;
            Action = action;
        }

    }
}
