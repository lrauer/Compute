﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public class Statistics
    {
        bool _AllCorrect;

        public bool AllCorrect
        {
            get { return _AllCorrect; }
            set { _AllCorrect = value; }
        }

        int _Steps;

        public int Steps
        {
            get { return _Steps; }
            set { _Steps = value; }
        }

        int _Objects;

        public int Objects
        {
            get { return _Objects; }
            set { _Objects = value; }
        }

        int _Space;

        public int Space
        {
            get { return _Space; }
            set { _Space = value; }
        }

        int _DistanceTraveled;

        public int DistanceTraveled
        {
            get { return _DistanceTraveled; }
            set { _DistanceTraveled = value; }
        }

        int Circles;

        public int StepsPerCircle()
        {
            return Convert.ToInt32(1.0 * Steps / Circles);
        }

        public int DistancePerCircle()
        {
            return Convert.ToInt32(1.0 * DistanceTraveled / Circles);
        }

        public Statistics(int objects, int space, int circles)
        {
            AllCorrect = true;
            Circles = circles;
            Steps = 0;
            Objects = objects;
            Space = space;
            DistanceTraveled = 0;
        }
    }
}
