﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public class Statistics
    {
        List<bool> _ValidationList;

        public List<bool> ValidationList
        {
            get { return _ValidationList; }
            set { _ValidationList = value; }
        }

        public bool AllCorrect()
        {
            return !ValidationList.Exists(x => x == false);
        }

        int _Steps;

        public int Steps
        {
            get { return _Steps; }
            set
            {
                circlesteps += value - _Steps;
                _Steps = value;
            }
        }

        int _MinSteps;

        public int MinSteps
        {
            get { return _MinSteps; }
            set { _MinSteps = value; }
        }

        int _MaxSteps;

        public int MaxSteps
        {
            get { return _MaxSteps; }
            set { _MaxSteps = value; }
        }

        int _Objects;

        public int Objects
        {
            get { return _Objects; }
            set { _Objects = value; }
        }

        int _Space;

        public int Space
        {
            get { return _Space; }
            set { _Space = value; }
        }

        int _DistanceTraveled;

        public int DistanceTraveled
        {
            get { return _DistanceTraveled; }
            set
            {
                circledistance += value - _DistanceTraveled;
                _DistanceTraveled = value;
            }
        }

        int _MinDistanceTraveled;

        public int MinDistanceTraveled
        {
            get { return _MinDistanceTraveled; }
            set { _MinDistanceTraveled = value; }
        }

        int _MaxDistanceTraveled;

        public int MaxDistanceTraveled
        {
            get { return _MaxDistanceTraveled; }
            set { _MaxDistanceTraveled = value; }
        }

        readonly int Circles;

        public int StepsPerCircle()
        {
            return Convert.ToInt32(1.0 * Steps / Circles);
        }

        public int DistancePerCircle()
        {
            return Convert.ToInt32(1.0 * DistanceTraveled / Circles);
        }

        private int circlesteps;
        private int circledistance;
        private bool firstCircle;

        public void CircleFinished()
        {
            if (firstCircle)
            {
                firstCircle = false;
                MinSteps = circlesteps;
                MaxSteps = circlesteps;
                MinDistanceTraveled = circledistance;
                MaxDistanceTraveled = circledistance;
            }
            else
            {
                if (circlesteps < MinSteps)
                {
                    MinSteps = circlesteps;
                }
                if (circlesteps > MaxSteps)
                {
                    MaxSteps = circlesteps;
                }
                if (circledistance < MinDistanceTraveled)
                {
                    MinDistanceTraveled = circledistance;
                }
                if (circledistance > MaxDistanceTraveled)
                {
                    MaxDistanceTraveled = circledistance;
                }
            }
            circlesteps = 0;
            circledistance = 0;
        }

        public Statistics(int objects, int space, int circles)
        {
            ValidationList = new List<bool>();
            Circles = circles;
            Steps = 0;
            Objects = objects;
            Space = space;
            DistanceTraveled = 0;
            circlesteps = 0;
            circledistance = 0;
            firstCircle = true;
        }
    }
}
