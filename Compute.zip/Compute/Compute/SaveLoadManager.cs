﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Compute
{
    public class SaveLoadManager
    {

        public static bool loading = false;

        /// <summary>
        /// saves the rootplace
        /// </summary>
        /// <param name="name">name under wihich it should be saved</param>
        /// <param name="parent">root of the system to save</param>
        /// <param name="standalone">if the place is to be saved without references so it may be exported.
        /// It also wont be affected if childobjekts are ever changed</param>
        public static void SaveRootplace(string name, Root parent, bool standalone)
        {
            if (name != "" && name != " ")
            {
                if (parent.CurrentState != SystemState.Ready)
                {
                    throw new ActionInvalidException("Cannot save System while running", parent, parent.Position);
                }
                System.IO.Directory.CreateDirectory(System.Environment.CurrentDirectory + @"\saves\");
                XmlDocument doc = new XmlDocument();
                XmlNode docNode = doc.CreateXmlDeclaration("1.0", null, null);
                doc.AppendChild(docNode);
                XmlComment comment = doc.CreateComment(name);
                doc.AppendChild(comment);
                XmlElement e = doc.CreateElement(parent.Rootplace.ObjectType.ToString());
                if (standalone)
                {
                    parent.Rootplace.ToXMLComplete(doc, e);
                }
                else
                {
                    parent.Rootplace.ToXML(doc, e);
                }
                doc.AppendChild(e);

                doc.Save(System.Environment.CurrentDirectory + @"\saves\" + name + ".xml");
            }
        }

        public static Place LoadPlace(string name, Position pos)
        {
            loading = true;
            try
            {
                if (name == "" || name == " ")
                    throw new FileNotFoundException();
                XmlDocument doc = new XmlDocument();
                doc.Load(System.Environment.CurrentDirectory + @"\saves\" + name + ".xml");
                //create new place and set attributes to XML Data
                Place p = new Place(new Position(0, 0, pos.Parent), pos.Parent.MyRoot, false, 1, 1, name, Direction.Right, new Direction[1] { Direction.Right }, new Direction[1] { Direction.Right }, 0, 0);
                p.FromXML(doc.DocumentElement);
                p.Position.SetValues(pos.PosX, pos.PosY, pos.Parent);
                doc = null;
                return p;
            }
            //if there is no saved object
            catch (FileNotFoundException)
            {
                return new Place(pos, pos.Parent.MyRoot, true, 5, 5, name, Direction.Right, new Direction[1] { Direction.Left }, new Direction[1] { Direction.Right }, 1, 1);
            }
            //need to collect garbage to release the read file for next saveoperation ( e.g. level gets immediatly autorepaired and saved if wrong returnerpositions in loaded file)
            finally
            {
                GC.Collect();
                GC.WaitForPendingFinalizers();

            }
        }

        public static XmlElement GetChildXML(XmlElement head)
        {
            string name = "LastEdit";
                string rotation = "Right";
                string destructable = "True";
                string position = "0,0";
                foreach (XmlElement x in head.ChildNodes)
                {
                    if (x.Name == "RelativeRotation")
                    {
                        rotation = x.InnerText;
                    }
                    else if (x.Name == "Name")
                    {
                        name = x.InnerText;
                    }
                    else if (x.Name == "Position")
                    {
                        position = x.InnerText;
                    }
                    else if (x.Name == "Destructable")
                    {
                        destructable = x.InnerText;
                    }
                }
            XmlDocument doc = new XmlDocument();
            try
            {
                if (name == "" || name == " ")
                    throw new FileNotFoundException();
                doc.Load(System.Environment.CurrentDirectory + @"\saves\" + name + ".xml");
            }
            catch (FileNotFoundException)
            {
                XmlElement e = doc.CreateElement(Objektname.Place.ToString());
                e.AppendChild(doc.CreateElement("Name"));
                e.AppendChild(doc.CreateElement("Position"));
                e.AppendChild(doc.CreateElement("Destructable"));
                e.AppendChild(doc.CreateElement("RelativeRotation"));
                doc.AppendChild(e);
            }

            foreach (XmlElement x in doc.DocumentElement.ChildNodes)
            {
                if (x.Name == "RelativeRotation")
                {
                    x.InnerText = rotation;
                }
                else if (x.Name == "Name")
                {
                    x.InnerText = name;
                }
                else if (x.Name == "Position")
                {
                    x.InnerText = position;
                }
                else if (x.Name == "Destructable")
                {
                    x.InnerText = destructable;
                }
            }

            return doc.DocumentElement;
        }

        public static string GetAvailableName(string name)
        {
            System.IO.Directory.CreateDirectory(System.Environment.CurrentDirectory + @"\saves\");
            if (!System.IO.File.Exists(System.Environment.CurrentDirectory + @"\saves\" + name + ".xml"))
            {
                return name;
            }
            else
            {
                if(!name.Contains("_Copy1"))
                {
                    name = name + "_Copy1";
                }
                if (!System.IO.File.Exists(System.Environment.CurrentDirectory + @"\saves\" + name + ".xml"))
                {
                    return name;
                }
                else
                {
                    int i = int.Parse(name.Split(new String[] { "_Copy" }, StringSplitOptions.None)[1]);
                    name = name.Split(new String[] { "_Copy" }, StringSplitOptions.None)[0] + "_Copy";
                    while(System.IO.File.Exists(System.Environment.CurrentDirectory + @"\saves\" + name + i + ".xml"))
                    {
                        i++;
                    }
                    return name + i;
                }
            }
        }

    }
}
