﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;

namespace Compute
{
    public class SaveLoadManager
    {

        public static string DefaultSavePath = System.Environment.CurrentDirectory + "/saves/";

        /// <summary>
        /// saves the rootplace
        /// </summary>
        /// <param name="name">name under wihich it should be saved</param>
        /// <param name="parent">root of the system to save</param>
        /// <param name="standalone">if the place is to be saved without references so it may be exported.
        /// It also wont be affected if childobjekts are ever changed</param>
        public static void SaveRootplace(string name, Root parent, bool standalone)
        {
            if (name != "" && name != " ")
            {
                string subpath = "";
                //if parent saves in own subpath add the name as folder
                if (parent.saveInSubfolder)
                {
                    subpath = GetCleanName(name) + "/";
                }
                if (parent.CurrentState != SystemState.Ready)
                {
                    throw new ActionInvalidException("Cannot save System while running", parent, parent.Position);
                }
                XmlDocument doc = new XmlDocument();
                XmlNode docNode = doc.CreateXmlDeclaration("1.0", null, null);
                doc.AppendChild(docNode);
                XmlComment comment = doc.CreateComment(name);
                doc.AppendChild(comment);
                XmlElement e = doc.CreateElement(parent.Rootplace.ObjectType.ToString());
                if (standalone)
                {
                    parent.Rootplace.ToXMLComplete(doc, e);
                }
                else
                {
                    parent.Rootplace.ToXML(doc, e);
                }
                doc.AppendChild(e);

                System.IO.Directory.CreateDirectory(parent.savepath + subpath);
                SaveXML(parent.savepath + subpath + name + ".xml", doc);
            }
        }

        public static void SaveXML(string fullname, XmlDocument xml)
        {
            xml.Save(fullname);
        }

        public static void SaveXML(string fullname, string  xml)
        {
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xml);
            SaveXML(fullname, doc);
        }

        public static Place LoadPlace(string name, Position pos)
        {
            try
            {
                if (name == "" || name == " ")
                    throw new FileNotFoundException();
                XmlDocument doc = new XmlDocument();
                //try to load from path or alternatively from a subpath so it doesnt matter where it was saved
                string[] s = { pos.Parent.MyRoot.savepath + name + ".xml" };
                if (!File.Exists(s[0]))
                {
                    s = Directory.GetFiles(pos.Parent.MyRoot.savepath, name + ".xml", SearchOption.AllDirectories);
                }
                if (s.Length > 0)
                {
                    doc.Load(s[0]);
                }
                else
                {
                    throw new FileNotFoundException();
                }
                return LoadPlace(pos, doc);
            }
            //if there is no saved object
            catch (Exception)
            {
                return new Place(pos, pos.Parent.MyRoot, true, 1, 1, name, Direction.Right, new Direction[1] { Direction.Left }, new Direction[1] { Direction.Right }, 1, 1);
            }
            //need to collect garbage to release the read file for next saveoperation ( e.g. level gets immediatly autorepaired and saved if wrong returnerpositions in loaded file)
            finally
            {
                GC.Collect();
                GC.WaitForPendingFinalizers();

            }
        }

        public static Place LoadPlace(Position pos, string XML)
        {
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(XML);
                return LoadPlace(pos, doc);
            }
            //if there is no saved object or name is empty
            catch (Exception)
            {
                return new Place(pos, pos.Parent.MyRoot, true, 1, 1, "New", Direction.Right, new Direction[1] { Direction.Left }, new Direction[1] { Direction.Right }, 1, 1);
            }
        }

        static Place LoadPlace(Position pos, XmlDocument doc)
        {
            //create new place and set attributes to XML Data
            Place p = new Place(new Position(0, 0, pos.Parent), pos.Parent.MyRoot, false, 1, 1, "New", Direction.Right, new Direction[1] { Direction.Right }, new Direction[1] { Direction.Right }, 0, 0);
            p.FromXML(doc.DocumentElement);
            p.Position.SetValues(pos.PosX, pos.PosY, pos.Parent);
            doc = null;
            return p;
        }

        public static XmlDocument GetXML(string XML)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(XML);
            return doc;
        }

        public static XmlElement GetChildXML(XmlElement head, string path)
        {
            string name = "LastEdit";
            string rotation = "Right";
            string destructable = "True";
            string position = "0,0";
            foreach (XmlElement x in head.ChildNodes)
            {
                if (x.Name == "RelativeRotation")
                {
                    rotation = x.InnerText;
                }
                else if (x.Name == "Name")
                {
                    name = x.InnerText;
                }
                else if (x.Name == "Position")
                {
                    position = x.InnerText;
                }
                else if (x.Name == "Destructable")
                {
                    destructable = x.InnerText;
                }
            }
            XmlDocument doc = new XmlDocument();
            try
            {
                if (name == "" || name == " ")
                    throw new FileNotFoundException();
                //try to load from path or alternatively from a subpath so it doesnt matter where it was saved
                string[] s = { path + name + ".xml" };
                if (!File.Exists(s[0]))
                {
                    s = Directory.GetFiles(path, name + ".xml", SearchOption.AllDirectories);
                }
                if(s.Length > 0)
                {
                    doc.Load(s[0]);
                }
                else
                {
                    throw new FileNotFoundException();
                }
            }
            catch (Exception)
            {
                XmlElement e = doc.CreateElement(Objektname.Place.ToString());
                e.AppendChild(doc.CreateElement("Name"));
                e.AppendChild(doc.CreateElement("Position"));
                e.AppendChild(doc.CreateElement("Destructable"));
                e.AppendChild(doc.CreateElement("RelativeRotation"));
                doc.AppendChild(e);
            }

            foreach (XmlElement x in doc.DocumentElement.ChildNodes)
            {
                if (x.Name == "RelativeRotation")
                {
                    x.InnerText = rotation;
                }
                else if (x.Name == "Name")
                {
                    x.InnerText = name;
                }
                else if (x.Name == "Position")
                {
                    x.InnerText = position;
                }
                else if (x.Name == "Destructable")
                {
                    x.InnerText = destructable;
                }
            }

            return doc.DocumentElement;
        }

        public static string GetAvailableName(string name, bool saveInSubfolder)
        {
            return GetAvailableName(name, DefaultSavePath, saveInSubfolder);
        }

        public static string GetAvailableName(string name, string path, bool saveInSubfolder)
        {
            string subpath = "";
            //if parent saves in own subpath add the name as folder
            if (saveInSubfolder)
            {
                subpath = name + "/";
            }
            System.IO.Directory.CreateDirectory(path);
            if (!System.IO.File.Exists(path + subpath + name + "_1.xml"))
            {
                return name + "_1";
            }
            else
            {
                int i = 2;
                while (System.IO.File.Exists(path + subpath + name + "_" + i + ".xml"))
                {
                    i++;
                }
                return name + "_" + i;
            }
        }

        public static List<String> GetUsedNames()
        {
            return GetUsedNames(DefaultSavePath);
        }

        public static List<String> GetUsedNames(string path)
        {
            List<String> l = new List<string>();
            foreach(string s in System.IO.Directory.GetFiles(path,"*.xml",SearchOption.TopDirectoryOnly))
            {
                l.Add(s.Substring(0,s.Length-4).Replace(path, ""));
            }
            return l;
        }

        public static List<String> GetUsedNames(string name, bool saveInSubfolder)
        {
            return GetUsedNames(name, DefaultSavePath, saveInSubfolder);
        }

        public static List<String> GetUsedNames(string name, string path, bool saveInSubfolder)
        {
            string subpath = "";
            //if parent saves in own subpath add the name as folder
            if (saveInSubfolder)
            {
                subpath = name + "/";
            }
            List<String> l = new List<string>();
            int i = 1;
            while (System.IO.File.Exists(path + subpath + name + "_" + i + ".xml"))
            {
                l.Add(name + "_" + i);
                i++;
            }
            return l;
        }

        //clears the name of attached numbers (e.g. _2) so to get the pathname all of them reside in (in case it saves in a subfolder)
        public static string GetCleanName(string name)
        {
            Regex r = new Regex(@"_[0-9]+\z");
            return r.Replace(name,string.Empty);
        }

    }
}
