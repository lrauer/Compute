﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    class Subber : Melter
    {
        public Subber(Position position, Root root, Direction output, bool destructable)
            : base(position, root, output, destructable)
        {

        }

        public override void ExecuteTick()
        {
            CurrentInput[0].Value -= CurrentInput[1].Value;
            base.ExecuteTick();
        }

        public override int GetSpace()
        {
            return 25; // 74 record (ohne all)
        }

        public override int GetObjectcount()
        {
            return 12; // 21 record (ohne all)
        }

        public override int GetDistance()
        {
            return 18; // 41 record (ohne all)
        }

        public override int GetSteps()
        {
            return 18; // 42 record (ohne all)
        }

        public override string GetDescription()
        {
            return "Takes 2 inputs and subtracts the second from the first. Then releases the result in the outputdirection.";
        }
    }
}
