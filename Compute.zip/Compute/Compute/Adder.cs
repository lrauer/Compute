﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    class Adder: Melter
    {
        public Adder(Position position, Root root, Direction output, bool destructable)
            : base(position, root, output, destructable)
        {

        }

        public override void ExecuteTick()
        {
            CurrentInput[0].Value += CurrentInput[1].Value;
            base.ExecuteTick();
        }

        public override int GetSpace()
        {
            return 20; // 35 record (ohne all)
        }

        public override int GetObjectcount()
        {
            return 10; // 14 record (ohne all)
        }

        public override int GetDistance()
        {
            return 15; // 31 record (ohne all)
        }

        public override int GetSteps()
        {
            return 15; // 32 record (ohne all)
        }
    }
}
