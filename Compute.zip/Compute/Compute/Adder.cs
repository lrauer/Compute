﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    class Adder: Melter
    {
        public Adder(Position position, Direction output, bool destructable)
            : base(position, output, destructable)
        {

        }

        public override void ExecuteTick()
        {
            CurrentInput[0].Value += CurrentInput[1].Value;
            base.ExecuteTick();
        }
    }
}
