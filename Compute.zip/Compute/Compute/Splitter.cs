﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    class Splitter : AssemblyLine
    {
        public Splitter(Position position, Direction output, Direction output2, bool destructable)
            : base(position, output, destructable)
        {
            InputCount = 2;
            OutputDirections.Add(output2);
            OutputCount = 2;
        }

        public override bool PrepareTick()
        {
            switch (CurrentInput.Count)
            {
                case 0:
                    return false;
                case 1:
                    return false;
                case 2:
                    return true;
                default:
                    throw new ActionInvalidException("This Object can only process 2 inputs", this);
            }
        }

        public override void ExecuteTick()
        {
            MoveOrder m = new MoveOrder(CurrentInput[1], OutputDirections[1]);
            base.ExecuteTick();
            ReleaseOutput(m);
        }
    }
}
