﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    class Splitter : AssemblyLine
    {
        public Splitter(Position position, Root root, Direction output, Direction output2, bool destructable)
            : base(position, root, output, destructable)
        {
            InputCount = 2;
            OutputDirections.Add(output2);
            OutputCount = 2;
        }

        public override bool PrepareTick()
        {
            switch (CurrentInput.Count)
            {
                case 0:
                    return false;
                case 1:
                    return false;
                case 2:
                    return true;
                default:
                    throw new ActionInvalidException("This Object can only process 2 inputs", this, Position);
            }
        }

        public override void ExecuteTick()
        {
            MoveOrder m = new MoveOrder(CurrentInput[1], OutputDirections[1]);
            base.ExecuteTick();
            ReleaseOutput(m);
        }

        public override int GetSpace()
        {
            return 5; // 9 record (ohne all)
        }

        public override int GetObjectcount()
        {
            return 3; // 7 record (ohne all)
        }

        public override int GetDistance()
        {
            return 4; // 10 record (ohne all)
        }

        public override int GetSteps()
        {
            return 4; // 10 record (ohne all)
        }
    }
}
