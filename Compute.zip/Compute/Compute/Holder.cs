﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public class Holder : AssemblyLine
    {

        bool holding;

        public Holder(Position position, Root root, Direction output, bool destructable)
            : base(position, root, output, destructable)
        {
            OutputDirections.Add(Direction.Hold);
            InputDirections.Add(Direction.Hold);
            holding = true;
        }

        public override void ExecuteTick()
        {
            if (holding)
            {
                //all holders release their input if more then one has input
                bool released = false;
                foreach (PlaceableObjekt p in (Position.Parent as Place).GetChildren())
                {
                    if (p.CurrentInput.Count == 1 && p.ObjectType == Objektname.Holder && p != this)
                    {
                        Holder h = p as Holder;
                        h.Release();
                        released = true;
                    }
                }
                if (released == true)
                {
                    Release();
                }
                //if no other holders have input this holder will hold 
                if(holding)
                    ReleaseOutput(new MoveOrder(CurrentInput[0], OutputDirections[1]));
            }
            if (!holding)
            {
                ReleaseOutput(new MoveOrder(CurrentInput[0], OutputDirections[0]));
                holding = true;
            }
        }

        public void Release()
        {
            holding = false;
        }

        public override void Reset()
        {
            base.Reset();
            holding = true;
        }

        public override void ReceiveInput(MoveOrder moveOrder)
        {
            base.ReceiveInput(moveOrder);
        }
    }
}
