﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Compute
{
    class Jumper: AssemblyLine
    {

        Position _TargetPosition;

        public Position TargetPosition
        {
            get { return _TargetPosition; }
            set { _TargetPosition = value; }
        }

        public Jumper(Position position, Root root, Position targetPosition, bool destructable)
            : base(position, root, destructable)
        {
            TargetPosition = targetPosition;
        }

        //release to target Position
        public override void ExecuteTick()
        {
            //calculates the closest neighbour between the Jumpers position and the target position
            //this neighbour will be the direction from which the Input gets moved to the target position
            Direction targetDirection = DirectionHelper.GetRelative(Position,TargetPosition);
            Position neighbour = DirectionHelper.GetFromPosition(TargetPosition,targetDirection);
            CurrentInput[0].Position.SetValues(neighbour.PosX,neighbour.PosY,TargetPosition.Parent);
            ReleaseOutput(new MoveOrder(CurrentInput[0], targetDirection));
        }  

        public override void ToXML(XmlDocument doc, XmlElement head)
        {
            base.ToXML(doc, head);

            //save attributes
            XmlElement e;

            //targetPosition
            e = doc.CreateElement("TargetPosition");
            e.InnerXml = TargetPosition.PosX + "," + TargetPosition.PosY;
            head.AppendChild(e);
        }

        public override void FromXML(XmlElement head)
        {
            base.FromXML(head);

            //load Target Position
            foreach (XmlElement e in head.ChildNodes)
            {
                if (e.Name == "TargetPosition")
                {
                    TargetPosition.SetValues(int.Parse(e.InnerText.Split(',')[0]), int.Parse(e.InnerText.Split(',')[1]), TargetPosition.Parent);
                }
            }
        }

        public override void SetToMemento(PlaceableObjektMemento memento)
        {
            base.SetToMemento(memento);
            JumperMemento m = (JumperMemento)memento;
            TargetPosition.SetValues(m.targetPosX,m.targetPosY,TargetPosition.Parent);
        }

        public override PlaceableObjektMemento CreateMemento()
        {
            return new JumperMemento(Position, InputCount, OutputCount, Destructable, InputDirections, OutputDirections, ObjectType, TargetPosition.PosX, TargetPosition.PosY);
        }
    }

    public class JumperMemento : PlaceableObjektMemento
    {
        public int targetPosX;
        public int targetPosY;

        public JumperMemento(Position position, int inputcount, int outputcount, bool destructable, List<Direction> inputdirections, List<Direction> outputdirections, Objektname objektname, int targetPosX, int targetPosY)
            : base(position, inputcount, outputcount, destructable, inputdirections, outputdirections, objektname)
        {
            this.targetPosX = targetPosX;
            this.targetPosY = targetPosY;
        }
    }
}
