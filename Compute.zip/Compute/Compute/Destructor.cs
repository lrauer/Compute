﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public class Destructor : AssemblyLine
    {
        public Destructor(Position position, bool destructable)
            : base(position, destructable)
        {

        }

        //just forget the object
        public override void ExecuteTick()
        {
            //remove reference to this objekt from the moveable
            Moveable m = CurrentInput[0];
            m.Position.SetValues(0, 0, null);  
            //remove moveable
            CurrentInput.Clear();
            //remove reference in parentplace as well
            Place p = Position.Parent as Place;
            p.RemoveCurrentInput(m);
        }
    }
}
