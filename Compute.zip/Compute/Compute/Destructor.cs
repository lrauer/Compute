﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public class Destructor : AssemblyLine
    {
        public event EventHandler<PositionEventArgs> InputDestroyed;

        public Destructor(Position position, Root root, bool destructable)
            : base(position, root, destructable)
        {
            InputDestroyed += root.Eventsystem.HandleInputDestroyed;   
        }

        //just forget the object
        public override void ExecuteTick()
        {
            //remove reference to this objekt from the moveable
            Moveable m = CurrentInput[0];
            m.Position.SetValues(0, 0, null);  
            //remove moveable
            CurrentInput.Clear();
            //remove reference in parentplace as well
            Place p = Position.Parent as Place;
            p.RemoveCurrentInput(m);
            InputDestroyed.Invoke(this, new PositionEventArgs(Position.PosX, Position.PosX, Position.PosY, Position.PosY, Position.Parent, Position.Parent, ObjectType));
        }
    }
}
