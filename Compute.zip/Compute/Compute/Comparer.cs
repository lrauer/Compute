﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Compute
{
    public class Comparer: AssemblyLine
    {

        int _TargetValue;

        public int TargetValue
        {
                get { return _TargetValue; }
                set { _TargetValue = value; }
        }

        public Comparer(Position position, Direction output, Direction alternative, int targetValue, bool destructable)
            : this(position, output, targetValue, destructable)
        {
            OutputDirections.Add(alternative);
        }

        public Comparer(Position position, Direction output, int targetValue, bool destructable)
            : base(position, output, destructable)
        {
            TargetValue = targetValue;
        }

        public override void ExecuteTick()
        {
            if (TargetValue == CurrentInput[0].Value || OutputDirections.Count == 1)
            {
                ReleaseOutput(new MoveOrder(CurrentInput[0], OutputDirections[0]));
            }
            else
            {
                ReleaseOutput(new MoveOrder(CurrentInput[0], OutputDirections[1]));
            }
        }

        public override void ToXML(XmlDocument doc, XmlElement head)
        {
            base.ToXML(doc, head);

            //save attributes
            XmlElement e;

            //targetValue
            e = doc.CreateElement("TargetValue");
            e.InnerXml = "" + TargetValue;
            head.AppendChild(e);
        }

        public override void FromXML(XmlElement head)
        {
            base.FromXML(head);

            //load Target Value
            foreach (XmlElement e in head.ChildNodes)
            {
                if (e.Name == "TargetValue")
                {
                    TargetValue = int.Parse(e.InnerText.Split(',')[0]);
                }
            }
        }

        public override void setToMemento(PlaceableObjektMemento memento)
        {
            base.setToMemento(memento);
            ComparerMemento m = (ComparerMemento)memento;
            TargetValue = m.value;
        }

        public override PlaceableObjektMemento createMemento()
        {
            return new ComparerMemento(Position, InputCount, OutputCount, Destructable, InputDirections, OutputDirections, ObjectType, TargetValue);
        }
    }

    public class ComparerMemento : PlaceableObjektMemento
    {
        public int value;

        public ComparerMemento(Position position, int inputcount, int outputcount, bool destructable, List<Direction> inputdirections, List<Direction> outputdirections, Objektname objektname, int value)
            : base(position, inputcount, outputcount, destructable, inputdirections, outputdirections, objektname)
        {
            this.value = value;
        }
    }
}
