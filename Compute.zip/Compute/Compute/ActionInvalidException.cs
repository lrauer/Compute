﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{

    public class ActionInvalidException: Exception
    {
        PlaceableObjekt _Sender;

        public PlaceableObjekt Sender
        {
          get { return _Sender; }
          set { _Sender = value; }
        }

        Position _Errorposition;

        public Position Errorposition
        {
            get { return _Errorposition; }
            set { _Errorposition = value; }
        }

        public Position getRootplacePosition()
        {
            Position pos = Errorposition;

            //return your position if you are in the rootplace
            while (pos.Parent != null)
            {
                if (pos.Parent == Sender.MyRoot.Rootplace)
                {
                    return pos;
                }
                pos = pos.Parent.Position;
            }

            //if the error is global then no errorposition
            return null;
        }

        public ActionInvalidException(String message, PlaceableObjekt sender, Position errorposition): base(message)
        {
            Sender = sender;
            Errorposition = errorposition;
        }

    }
}
