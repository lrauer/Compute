﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public class Alternator : AssemblyLine
    {

        public event EventHandler<ActivatedEventArgs> AlternatorChanged;

        bool _Activated;

        public bool Activated
        {
            get { return _Activated; }
            set
            {
                if (_Activated != value)
                {
                    bool oldActivated = _Activated;
                    _Activated = value;
                    AlternatorChanged.Invoke(this, new ActivatedEventArgs(oldActivated, value, Position.PosX, Position.PosX, Position.PosY, Position.PosY, Position.Parent, Position.Parent, ObjectType));
                }
            }
        }

        public Alternator(Position position, Direction output, Direction alternative, bool destructable)
            : base(position, output, destructable)
        {
            OutputDirections.Add(alternative);
            Activated = false;
            AlternatorChanged += getRoot().Eventsystem.HandleAlternatorChanged;
        }

        public override void ExecuteTick()
        {
            Activated = !Activated;
            if (Activated)
            {
                ReleaseOutput(new MoveOrder(CurrentInput[0], OutputDirections[0]));
            }
            else
            {
                ReleaseOutput(new MoveOrder(CurrentInput[0], OutputDirections[1]));
            }
        }

        public override void Reset()
        {
            base.Reset();
            Activated = false;
        }

    }
}
