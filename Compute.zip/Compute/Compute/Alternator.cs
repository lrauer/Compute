﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public class Alternator : ConveyorBelt, IActivatable
    {

        public event EventHandler<ActivatedEventArgs> AlternatorChanged;

        bool _Activated;

        public bool GetState()
        {
            return Activated;
        }

        public bool Activated
        {
            get { return _Activated; }
            set
            {
                if (_Activated != value)
                {
                    bool oldActivated = _Activated;
                    _Activated = value;
                    AlternatorChanged.Invoke(this, new ActivatedEventArgs(oldActivated, value, Position.PosX, Position.PosX, Position.PosY, Position.PosY, Position.Parent, Position.Parent, ObjectType));
                }
            }
        }

        public Alternator(Position position, Root root, Direction output, Direction alternative, bool destructable)
            : base(position, root, output, destructable)
        {
            OutputDirections.Add(alternative);
            Activated = false;
            AlternatorChanged += root.Eventsystem.HandleAlternatorChanged;
        }

        public override int GetSpace()
        {
            return 10; // 25 record (ohne all)
        }

        public override int GetObjectcount()
        {
            return 3; // 7 record (ohne all)
        }

        public override int GetDistance()
        {
            return 2; // 5 record (ohne all)
        }

        public override int GetSteps()
        {
            return 2; // 5 record (ohne all)
        }

        public override string GetDescription()
        {
            return "Takes 1 input, changes its outputdirection and then releases the input. Alternates between 2 outputdirections.";
        }

        public override void ExecuteTick()
        {
            Activated = !Activated;
            if (Activated)
            {
                ReleaseOutput(new MoveOrder(CurrentInput[0], OutputDirections[0]));
            }
            else
            {
                ReleaseOutput(new MoveOrder(CurrentInput[0], OutputDirections[1]));
            }
        }

        public override void Reset()
        {
            base.Reset();
            Activated = false;
        }

    }
}
