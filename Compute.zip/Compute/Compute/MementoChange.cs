﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public class MementoChange
    {

        PlaceableObjekt parent;

        public PlaceableObjekt GetNewPosition()
        {
            Place p = parent as Place;
            if (p == null)
            {
                return parent.MyRoot.Rootplace;
            }
            else
            {
                return p.GetChildAt(NewState.positionX, NewState.positionY);
            }

        }

        public PlaceableObjekt GetOldPosition()
        {
            Place p = parent as Place;
            if (p == null)
            {
                return parent.MyRoot.Rootplace;
            }
            else
            {
                return p.GetChildAt(OldState.positionX, OldState.positionY);
            }

        }

        PlaceableObjektMemento _OldState;

        public PlaceableObjektMemento OldState
        {
            get { return _OldState; }
            set { _OldState = value; }
        }
        PlaceableObjektMemento _NewState;

        public PlaceableObjektMemento NewState
        {
            get { return _NewState; }
            set { _NewState = value; }
        }

        private MementoEventArgs _CreationEvent;

        public MementoEventArgs CreationEvent
        {
            get { return _CreationEvent; }
            set { _CreationEvent = value; }
        }

        public MementoChange(PlaceableObjekt objekt, PlaceableObjektMemento oldState, PlaceableObjektMemento newState)
        {
            //save parent of objekt seperately, because aftermultiple undos/redos it might be another object that gets the memento
            parent = objekt.Position.Parent;

            OldState = oldState;
            NewState = newState;
        }
    }
}
