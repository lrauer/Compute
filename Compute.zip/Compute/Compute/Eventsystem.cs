﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public class Eventsystem
    {

        Root _Owner;

        public Root Owner
        {
          get { return _Owner; }
          set { _Owner = value; }
        }

        ComputeController _Controller;

        public ComputeController Controller
        {
            get { return _Controller; }
            set { _Controller = value; }
        }

        public event EventHandler<QueueEventArgs> SystemInput;
        public event EventHandler<QueueValidationEventArgs> SystemOutput;
        public event EventHandler<QueueEventArgs> InputReceived;
        public event EventHandler<QueueEventArgs> OutputReceived;
        public event EventHandler<SystemStateEventArgs> ExecuteFinished;
        public event EventHandler<SystemCompletionEventArgs> ExecuteCompleted;
        public event EventHandler<SystemStateEventArgs> ExecuteCircleFinished;
        public event EventHandler<SystemStateFailedEventArgs> ExecuteFailed;
        public event EventHandler<SystemStateEventArgs> SystemResetted;
        public event EventHandler<SystemStateEventArgs> RunBegin;
        public event EventHandler<PositionEventArgs> ObjektPositionChanged;
        public event EventHandler<PositionEventArgs> ObjektCreation;
        public event EventHandler<ValueEventArgs> MoveableValueChanged;
        public event EventHandler<UndoEventArgs> UndoCompleted;
        public event EventHandler<UndoEventArgs> RedoCompleted;
        public event EventHandler<MementoEventArgs> UndoableAction;
        public event EventHandler<PositionEventArgs> SystemLayoutChanged;
        public event EventHandler<PositionEventArgs> MoveablePositionChanged;
        public event EventHandler<PositionEventArgs> MoveableDestroyed;
        public event EventHandler<ActivatedEventArgs> SwitchStateChanged;
        public event EventHandler<ActivatedEventArgs> AlternatorStateChanged;
        public event EventHandler<ActivatedEventArgs> SystemStateChanged;
        public event EventHandler<MemoryEventArgs> MemoryValueChanged;
        public event EventHandler<MemoryEventArgs> SystemMemoryChanged;
        public event EventHandler<MoveOrderEventArgs> MoveableBeginMove;
        public event EventHandler<MoveOrderEventArgs> MoveableEndMove;

        public Eventsystem(ComputeController controller, string name)
        {
            Controller = controller;
            Owner = new Root(this,name, null);
        }

        public void HandlePositionChanged(object sender, PositionEventArgs eventArgs)
        {
            if (Owner != null && Owner.CurrentExecute != null && eventArgs.NewPositionParent != null && eventArgs.NewPositionParent.ObjectType == Objektname.Place)
            {
                //the object only moved if a child returns it back to its parent
                if (eventArgs.NewPositionParent == eventArgs.OldPositionParent.Position.Parent)
                {
                    Owner.CurrentExecute.DistanceTraveled += eventArgs.OldPositionParent.GetDistance();
                }
            }
            if(ObjektPositionChanged != null)
                ObjektPositionChanged.Invoke(sender,eventArgs);
            //only invoke if in Rootplace and a moveable
            if ((eventArgs.InRootPlace(true) || eventArgs.InRootPlace(false)) && eventArgs.OwnerType == Objektname.Moveable)
                if (MoveablePositionChanged != null)
                    MoveablePositionChanged.Invoke(sender, eventArgs);
        }

        public void HandleCreation(object sender, PositionEventArgs eventArgs)
        {
            if (ObjektCreation != null)
                ObjektCreation.Invoke(sender, eventArgs);
            //only invoke if in Rootplace and a moveable
            if (eventArgs.InRootPlace(true) || eventArgs.InRootPlace(false) && eventArgs.OwnerType == Objektname.Moveable)
                if (MoveablePositionChanged != null)
                    MoveablePositionChanged.Invoke(sender, eventArgs);
        }

        public void HandleValueChanged(object sender, ValueEventArgs eventArgs)
        {
            //valueupdates are always invoked
            if (MoveableValueChanged != null)
                    MoveableValueChanged.Invoke(sender, eventArgs);
        }

        public void HandleInputDestroyed(object sender, PositionEventArgs eventArgs)
        {
            if (MoveableDestroyed != null)
                MoveableDestroyed.Invoke(sender, eventArgs);
            //only invoke if in Rootplace
            if (eventArgs.InRootPlace(true))
                if (MoveablePositionChanged != null)
                    MoveablePositionChanged.Invoke(sender, eventArgs);
        }

        public void HandleSwitchActivated(object sender, ActivatedEventArgs eventArgs)
        {
            if (SwitchStateChanged != null)
                SwitchStateChanged.Invoke(sender, eventArgs);
            //only invoke if in Rootplace
            if (eventArgs.InRootPlace(true) || eventArgs.InRootPlace(false))
                if (SystemStateChanged != null)
                    SystemStateChanged.Invoke(sender, eventArgs);
        }

        public void HandleAlternatorChanged(object sender, ActivatedEventArgs eventArgs)
        {
            if (AlternatorStateChanged != null)
                AlternatorStateChanged.Invoke(sender, eventArgs);
            //only invoke if in Rootplace
            if (eventArgs.InRootPlace(true) || eventArgs.InRootPlace(false))
                if (SystemStateChanged != null)
                    SystemStateChanged.Invoke(sender, eventArgs);
        }

        public void HandleMemoryChanged(object sender, MemoryEventArgs eventArgs)
        {
            if (MemoryValueChanged != null)
                MemoryValueChanged.Invoke(sender, eventArgs);
            //only invoke if in Rootplace
            if (eventArgs.InRootPlace(true) || eventArgs.InRootPlace(false))
                if (SystemMemoryChanged != null)
                    SystemMemoryChanged.Invoke(sender, eventArgs);
        }

        public void HandleSystemInput(object sender, QueueEventArgs eventArgs)
        {
            if (SystemInput != null)
                SystemInput.Invoke(sender, eventArgs);
        }

        public void HandleSystemOutput(object sender, QueueValidationEventArgs eventArgs)
        {
            if (SystemOutput != null)
                SystemOutput.Invoke(sender, eventArgs);
        }

        public void HandleInputReceived(object sender, QueueEventArgs eventArgs)
        {
            if (InputReceived != null)
                InputReceived.Invoke(sender, eventArgs);
        }

        public void HandleOutputReceived(object sender, QueueEventArgs eventArgs)
        {
            if (OutputReceived != null)
                OutputReceived.Invoke(sender, eventArgs);
        }

        public void HandleExecuteFinished(object sender, SystemStateEventArgs eventArgs)
        {
            if (ExecuteFinished != null)
                ExecuteFinished.Invoke(sender, eventArgs);
        }

        public void HandleExecuteCompleted(object sender, SystemCompletionEventArgs eventArgs)
        {
            if (ExecuteCompleted != null)
                ExecuteCompleted.Invoke(sender, eventArgs);
        }

        public void HandleExecuteCircleFinished(object sender, SystemStateEventArgs eventArgs)
        {
            Owner.CurrentExecute.CircleFinished();
            if (ExecuteCircleFinished != null)
                ExecuteCircleFinished.Invoke(sender, eventArgs);
        }

        public void HandleExecuteFailed(object sender, SystemStateFailedEventArgs eventArgs)
        {
            if (ExecuteFailed != null)
                ExecuteFailed.Invoke(sender, eventArgs);
        }

        public void HandleSystemResetted(object sender, SystemStateEventArgs eventArgs)
        {
            if (SystemResetted != null)
                SystemResetted.Invoke(sender, eventArgs);
        }

        public void HandleRunBegin(object sender, SystemStateEventArgs eventArgs)
        {
            if (RunBegin != null)
                RunBegin.Invoke(sender, eventArgs);
        }

        public void HandleUndoAction(object sender, UndoEventArgs eventArgs)
        {
            SaveLoadManager.SaveRootplace(Owner.Rootplace.Name, Owner);
            if (UndoCompleted != null)
                UndoCompleted.Invoke(sender, eventArgs);
            if (SystemLayoutChanged != null)
                SystemLayoutChanged.Invoke(sender, eventArgs);
        }

        public void HandleRedoAction(object sender, UndoEventArgs eventArgs)
        {
            SaveLoadManager.SaveRootplace(Owner.Rootplace.Name, Owner);
            if (RedoCompleted != null)
                RedoCompleted.Invoke(sender, eventArgs);
            if (SystemLayoutChanged != null)
                SystemLayoutChanged.Invoke(sender, eventArgs);
        }

        public void HandleMementoCreation(object sender, MementoEventArgs eventArgs)
        {
            eventArgs.ChangeOperation.CreationEvent = eventArgs;
            Owner.UndoStack.Push(eventArgs.ChangeOperation);
            Owner.RedoStack.Clear();
            SaveLoadManager.SaveRootplace(Owner.Rootplace.Name, Owner);
            if (UndoableAction != null)
                UndoableAction.Invoke(sender, eventArgs);
            if (SystemLayoutChanged != null)
                SystemLayoutChanged.Invoke(sender, eventArgs);
        }

        public void HandleMoveOrderBegin(object sender, MoveOrderEventArgs eventArgs)
        {
            //only invoke if in Rootplace
            if(eventArgs.Target.Target.Position.Parent.Position.Parent.ObjectType == Objektname.Root)
                if (MoveableBeginMove != null)
                    MoveableBeginMove.Invoke(sender, eventArgs);
        }

        public void HandleMoveOrderEnd(object sender, MoveOrderEventArgs eventArgs)
        {
            //only invoke if in Rootplace
            if (eventArgs.Target.Target.Position.Parent.Position.Parent.ObjectType == Objektname.Root)
                if (MoveableEndMove != null)
                    MoveableEndMove.Invoke(sender, eventArgs);
        }


    }
}
