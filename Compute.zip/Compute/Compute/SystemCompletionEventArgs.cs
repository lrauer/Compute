﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public class SystemCompletionEventArgs: SystemStateEventArgs
    {

        Statistics _RunStatistics;

        public Statistics RunStatistics
        {
            get { return _RunStatistics; }
            set { _RunStatistics = value; }
        }

        public SystemCompletionEventArgs(SystemState state, ExecType eventExecType, Statistics stats): base(state, eventExecType)
        {
            RunStatistics = stats;
        }
    }
}
