﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    class Multiplier : Melter
    {
        public Multiplier(Position position, Root root, Direction output, bool destructable)
            : base(position, root, output, destructable)
        {

        }

        public override void ExecuteTick()
        {
            CurrentInput[0].Value *= CurrentInput[1].Value;
            base.ExecuteTick();
        }

        public override int GetSpace()
        {
            return 50; // 114 record (ohne all)
        }

        public override int GetObjectcount()
        {
            return 25; // 50 record (ohne all)
        }

        public override int GetDistance()
        {
            return 100; // 385 record (ohne all)
        }

        public override int GetSteps()
        {
            return 100; // 305 record (ohne all)
        }

        public override string GetDescription()
        {
            return "Takes 2 inputs and multiplies them. Then releases the result in the outputdirection.";
        }
    }
}
