﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Compute
{
    public class Lever : AssemblyLine
    {

        IFlickable connection;

        public IFlickable Connection
        {
            get { return connection; }
            set { connection = value; }
        }

        public Lever(Position position, Direction output, bool destructable)
            : base(position, output, destructable)
        {

        }

        public override void ReceiveInput(MoveOrder moveOrder)
        {
            base.ReceiveInput(moveOrder);
            if (Connection != null)
                Connection.Flick();
        }

        public void Connect(IFlickable target)
        {
            Connection = target;
        }

        public override void ToXML(XmlDocument doc, XmlElement head)
        {
            base.ToXML(doc, head);

            //save attributes
            XmlElement e;

            if (connection != null)
            {
                //Connection
                e = doc.CreateElement("Connection");
                e.InnerXml = "" + ((PlaceableObjekt)Connection).Position.PosX + "," + ((PlaceableObjekt)Connection).Position.PosY;
                head.AppendChild(e);
            }
        }

        public override void FromXML(XmlElement head)
        {
            base.FromXML(head);

            //load connection to flickable at position
            foreach (XmlElement e in head.ChildNodes)
            {
                if (e.Name == "Connection")
                {
                    PlaceableObjekt p = ((Place)Position.Parent).GetChildAt(int.Parse(e.InnerText.Split(',')[0]), int.Parse(e.InnerText.Split(',')[1]));
                    if(p != null)
                    {
                        IFlickable f = p as IFlickable;
                        if(f != null)
                        {
                            Connection = f;
                        }
                    }
                }
            }
            
        }

        public override void setToMemento(PlaceableObjektMemento memento)
        {
            base.setToMemento(memento);
            Connection = null;
            LeverMemento m = (LeverMemento)memento;
            PlaceableObjekt p = ((Place)Position.Parent).GetChildAt(m.connectionX, m.connectionY);
            if (p != null)
            {
                IFlickable f = p as IFlickable;
                if (f != null)
                {
                    Connection = f;
                }
            }
        }

        public override PlaceableObjektMemento createMemento()
        {
            return new LeverMemento(Position, InputCount, OutputCount, Destructable, InputDirections, OutputDirections, ObjectType, Connection);
        }
    }

    public class LeverMemento: PlaceableObjektMemento
    {
        public int connectionX;
        public int connectionY;

        public LeverMemento(Position position, int inputcount, int outputcount, bool destructable, List<Direction> inputdirections, List<Direction> outputdirections, Objektname objektname, IFlickable connection): base(position, inputcount, outputcount, destructable, inputdirections, outputdirections, objektname)
        {
            if (connection != null)
            {
                PlaceableObjekt p = connection as PlaceableObjekt;
                connectionX = p.Position.PosX;
                connectionY = p.Position.PosY;
            }
            else
            {
                connectionX = -1000;
                connectionY = -1000;
            }
        }
    }
}
