﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Compute
{
    public class Lever : ConveyorBelt
    {

        public event EventHandler<ConnectionEventArgs> ConnectionChanged;

        IFlickable connection;

        //to distinguish connections each lever has a unique ID per Place
        private int uniqueId;

        public int UniqueId 
        {
            get
            {
                //if ID not exclusive get new ID
                if (((Place)Position.Parent).GetChildren().Find(x => x.ObjectType == Objektname.Lever && (x as Lever) != this && (x as Lever).uniqueId == uniqueId) == null)
                {
                    return uniqueId;
                }
                int i = 0;
                while (((Place)Position.Parent).GetChildren().Find(x => x.ObjectType == Objektname.Lever && (x as Lever) != this && (x as Lever).uniqueId == i) != null)
                {
                    i++;
                }
                uniqueId = i;
                return i;
            }
            set
            {
                uniqueId = value;
            }
        }

        public IFlickable Connection
        {
            get { return connection; }
            set 
            {
                IFlickable oldConnection = connection;
                connection = value;
                ConnectionChanged.Invoke(this, new ConnectionEventArgs(oldConnection, value, Position.PosX, Position.PosX, Position.PosY, Position.PosY, Position.Parent, Position.Parent, ObjectType));
            }
        }

        public Lever(Position position, Root root, Direction output, bool destructable)
            : base(position, root, output, destructable)
        {
            ConnectionChanged += root.Eventsystem.HandleConnectionChanged;
            //new lever gets new ID
            int i = 0;
            while (((Place)Position.Parent).GetChildren().Find(x => x.ObjectType == Objektname.Lever && (x as Lever) != this && (x as Lever).uniqueId == i) != null)
            {
                i++;
            }
            UniqueId = i;
        }

        public override void ReceiveInput(MoveOrder moveOrder)
        {
            base.ReceiveInput(moveOrder);
            if (Connection != null)
                Connection.Flick();
        }

        public void Connect(IFlickable target)
        {
            if (target != null && ((PlaceableObjekt)target).Position.Parent != Position.Parent)
            {
                throw new ActionInvalidException("Can't connect to a Flickable in a different Place", this, new Position(Position.PosX, Position.PosY, Position.Parent));
            }
            Connection = target;
        }

        public override int GetSpace()
        {
            return 0;
        }

        public override int GetObjectcount()
        {
            return 1;
        }

        public override int GetDistance()
        {
            return 1;
        }

        public override int GetSteps()
        {
            return 1;
        }

        public override string GetDescription()
        {
            return "Takes 1 input and releases it in the outputdirection. Also triggers the connected triggerable object.";
        }

        public override void ToXML(XmlDocument doc, XmlElement head)
        {
            base.ToXML(doc, head);

            //save attributes
            XmlElement e;

            if (connection != null)
            {
                //Connection
                e = doc.CreateElement("Connection");
                e.InnerXml = "" + ((PlaceableObjekt)Connection).Position.PosX + "," + ((PlaceableObjekt)Connection).Position.PosY;
                head.AppendChild(e);
            }
        }

        public override void FromXML(XmlElement head)
        {
            base.FromXML(head);

            //load connection to flickable at position
            foreach (XmlElement e in head.ChildNodes)
            {
                if (e.Name == "Connection")
                {
                    PlaceableObjekt p = ((Place)Position.Parent).GetChildAt(int.Parse(e.InnerText.Split(',')[0]), int.Parse(e.InnerText.Split(',')[1]));
                    if(p != null)
                    {
                        IFlickable f = p as IFlickable;
                        Connection = f;
                    }
                }
            }
            
        }

        public override void SetToMemento(PlaceableObjektMemento memento)
        {
            base.SetToMemento(memento);
            Connection = null;
            LeverMemento m = (LeverMemento)memento;
            PlaceableObjekt p = ((Place)Position.Parent).GetChildAt(m.connectionX, m.connectionY);
            if (p != null)
            {
                IFlickable f = p as IFlickable;
                Connection = f;
            }
            //lever gets memento ID
            UniqueId = m.uniqueId;
        }

        public void SetToMementoNewID(PlaceableObjektMemento memento)
        {
            SetToMemento(memento);
            //repair ID immediatly to create a new one instead of using the copied one
            UniqueId = UniqueId;
        }

        public override PlaceableObjektMemento CreateMemento()
        {
            return new LeverMemento(Position, InputCount, OutputCount, Destructable, InputDirections, OutputDirections, ObjectType, Connection, UniqueId);
        }
    }

    public class LeverMemento: PlaceableObjektMemento
    {
        public int connectionX;
        public int connectionY;
        public int uniqueId;

        public LeverMemento(Position position, int inputcount, int outputcount, bool destructable, List<Direction> inputdirections, List<Direction> outputdirections, Objektname objektname, IFlickable connection, int uniqueId) : base(position, inputcount, outputcount, destructable, inputdirections, outputdirections, objektname)
        {
            if (connection != null)
            {
                PlaceableObjekt p = connection as PlaceableObjekt;
                connectionX = p.Position.PosX;
                connectionY = p.Position.PosY;
            }
            else
            {
                connectionX = -10000;
                connectionY = -10000;
            }
            this.uniqueId = uniqueId;
        }
    }
}
