﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    //This is the Class to communicate with the external caller
    public class ComputeController
    {

        Eventsystem _Events;

        //these are the events a caller can subscribe to for frontend updates
        public Eventsystem Events
        {
            get { return _Events; }
            set { _Events = value; }
        }

        Root System;

        public ComputeController(string name)
        {
            Events = new Eventsystem(this,name);
            System = Events.Owner;
        }

        public void SetRootplaceBoundaries(int sizeX, int sizeY, Direction[] inputdirections, Direction[] outputdirections, int inputcount, int outputcount)
        {
            System.Rootplace.ChangeBoundaries(sizeX, sizeY, inputdirections, outputdirections, inputcount, outputcount);
        }

        public void SetRootplaceDirections(Direction[] inputdirections, Direction[] outputdirections, int inputcount, int outputcount)
        {
            System.Rootplace.ChangeBoundaries(System.Rootplace.SizeX, System.Rootplace.SizeY, inputdirections, outputdirections, inputcount, outputcount);
        }

        public bool AddAssemblyLine(int posX, int posY, Direction direction)
        {
            return System.Rootplace.AddChild(new AssemblyLine(new Position(posX, posY, System.Rootplace), direction, true));
        }

        public bool AddIncrementer(int posX, int posY, Direction direction)
        {
            return System.Rootplace.AddChild(new Incrementer(new Position(posX, posY, System.Rootplace), direction, true));
        }

        public bool AddDecrementer(int posX, int posY, Direction direction)
        {
            return System.Rootplace.AddChild(new Decrementer(new Position(posX, posY, System.Rootplace), direction, true));
        }

        public bool AddDestructor(int posX, int posY)
        {
            return System.Rootplace.AddChild(new Destructor(new Position(posX, posY, System.Rootplace), true));
        }

        public bool AddHolder(int posX, int posY, Direction direction)
        {
            return System.Rootplace.AddChild(new Holder(new Position(posX, posY, System.Rootplace), direction, true));
        }

        public bool AddLever(int posX, int posY, Direction direction)
        {
            return System.Rootplace.AddChild(new Lever(new Position(posX, posY, System.Rootplace), direction, true));
        }

        public bool AddSwitch(int posX, int posY, Direction trueDirection, Direction falseDirection)
        {
            return System.Rootplace.AddChild(new Switch(new Position(posX, posY, System.Rootplace), trueDirection, falseDirection, true));
        }

        public bool AddMover(int posX, int posY)
        {
            return System.Rootplace.AddChild(new Mover(new Position(posX, posY, System.Rootplace), true));
        }

        public bool AddJumper(int posX, int posY, int targetX, int targetY)
        {
            return System.Rootplace.AddChild(new Jumper(new Position(posX, posY, System.Rootplace), new Position(targetX, targetY, System.Rootplace), true));
        }

        public bool AddComparer(int posX, int posY, Direction trueDirection, Direction falseDirection, int compareValue)
        {
            return System.Rootplace.AddChild(new Comparer(new Position(posX, posY, System.Rootplace), trueDirection, falseDirection, compareValue, true));
        }

        public bool AddCreator(int posX, int posY, Direction createDirection, int createValue)
        {
            return System.Rootplace.AddChild(new Creator(new Position(posX, posY, System.Rootplace), createDirection, createValue, true));
        }

        public bool AddCopier(int posX, int posY, Direction direction, Direction createDirection)
        {
            return System.Rootplace.AddChild(new Copier(new Position(posX, posY, System.Rootplace), direction, createDirection, true));
        }

        public bool AddMelter(int posX, int posY, Direction direction)
        {
            return System.Rootplace.AddChild(new Melter(new Position(posX, posY, System.Rootplace), direction, true));
        }

        public bool AddAdder(int posX, int posY, Direction direction)
        {
            return System.Rootplace.AddChild(new Adder(new Position(posX, posY, System.Rootplace), direction, true));
        }

        public bool AddSubber(int posX, int posY, Direction direction)
        {
            return System.Rootplace.AddChild(new Subber(new Position(posX, posY, System.Rootplace), direction, true));
        }

        public bool AddMultiplier(int posX, int posY, Direction direction)
        {
            return System.Rootplace.AddChild(new Multiplier(new Position(posX, posY, System.Rootplace), direction, true));
        }

        public bool AddDivider(int posX, int posY, Direction direction, Direction modDirection)
        {
            return System.Rootplace.AddChild(new Divider(new Position(posX, posY, System.Rootplace), direction, modDirection, true));
        }

        public bool AddMemory(int posX, int posY, Direction direction)
        {
            return System.Rootplace.AddChild(new Memory(new Position(posX, posY, System.Rootplace), direction, true));
        }

        public bool AddIdenticalTester(int posX, int posY, Direction direction)
        {
            return System.Rootplace.AddChild(new IdenticalTester(new Position(posX, posY, System.Rootplace), direction, true));
        }

        public bool AddGreaterThanTester(int posX, int posY, Direction direction)
        {
            return System.Rootplace.AddChild(new GreaterThanTester(new Position(posX, posY, System.Rootplace), direction, true));
        }

        public bool AddSplitter(int posX, int posY, Direction direction, Direction Direction2)
        {
            return System.Rootplace.AddChild(new Splitter(new Position(posX, posY, System.Rootplace), direction, Direction2, true));
        }

        public bool AddAlternator(int posX, int posY, Direction direction, Direction Direction2)
        {
            return System.Rootplace.AddChild(new Alternator(new Position(posX, posY, System.Rootplace), direction, Direction2, true));
        }

        public bool Connect(int lPosX, int lPosY, int fPosX, int fPosY)
        {
            //try to connect the Objekts (both ways)
            if (System.Rootplace.ConnectLeverToFlickable(lPosX, lPosY, fPosX, fPosY))
            {
                return true;
            }
            else
            {
                return System.Rootplace.ConnectLeverToFlickable(fPosX, fPosY, lPosX, lPosY);
            }
        }

        public bool ChangeTarget(int posX, int posY, int targetX, int targetY)
        {
            return System.Rootplace.ChangeJumpTarget(posX, posY, targetX, targetY);
        }

        public bool SetValue(int posX, int posY, int value)
        {
            return System.Rootplace.ChangeTargetValue(posX, posY, value);
        }

        public bool ChangeOutputdirection(int posX, int posY, Direction dOld, Direction dNew)
        {
            return System.Rootplace.ChangeOutputDirection(posX, posY, dOld, dNew);
        }

        public bool TurnAround(int posX, int posY, int quarters)
        {
            return System.Rootplace.Rotate(posX, posY, quarters);
        }

        ///alternatively LoadComputer with new name will create a new empty Place
        public bool AddComputer(int posX, int posY, string name, Direction[] inputs, Direction[] outputs, int inputcount, int outputcount)
        {
            //add empty place
            return System.Rootplace.AddChild(new Place(new Position(posX, posY, System.Rootplace), true, posX, posY, name, Direction.Right, inputs, outputs, inputcount, outputcount));
        }

        public bool LoadComputer(int posX, int posY, string blueprint)
        {
            //add place from blueprint
            return System.Rootplace.AddChild(SaveLoadManager.loadplace(blueprint,new Position(posX, posY, System.Rootplace)));
        }

        public bool ChangePosition(int oldPosX,int oldPosY,int newPosX,int newPosY)
        {
            return System.Rootplace.ChangeChildPosition(oldPosX, oldPosY, newPosX, newPosY);
        }

        public bool CopyPasteObjekt(int posX, int posY, int newPosX, int newPosY)
        {
            return System.Rootplace.CopyChild(posX, posY, newPosX, newPosY);
        }

        public bool PositionAvailable(int posX, int posY)
        {
            return System.Rootplace.GetChildAt(posX, posY) == null;
        }

        public bool DeleteAtPosition(int posX, int posY)
        {
            return System.Rootplace.RemoveChild(posX, posY);
        }

        public void AddNextInput(Direction direction, int value)
        {
            System.ReceiveInput(new MoveOrder(new Moveable(new Position(0, 0, System), value), direction));
        }

        public void AddNextExpectedOutput(Direction direction, int value)
        {
            System.ReceiveValidation(new MoveOrder(new Moveable(new Position(0, 0, System), value), direction));
        }

        public bool Step()
        {
            return System.Execute(ExecType.Substep);
        }

        public bool Circle()
        {
            return System.Execute(ExecType.Tick);
        }

        public Task<bool> CompletionAsync()
        {
            return Task.Run(() =>
            {
                return System.Execute(ExecType.Complete);
            });
        }

        public bool Completion()
        {
            return System.Execute(ExecType.Complete);
        }

        public bool ResetSystem()
        {
            return System.Execute(ExecType.Reset);
        }

        public List<PlaceableObjekt> getInitialObjects()
        {
            //return all objects in the Rootplace (returner and loaded children at start)
            return System.Rootplace.getChildren();
        }

        public PlaceableObjekt getObjectAt(int posX, int posY)
        {
            return System.Rootplace.GetChildAt(posX, posY);
        }

        public Moveable getInputAt(int posX, int posY)
        {
            return System.Rootplace.GetInputAt(posX, posY);
        }

        //undo last action
        public bool Undo()
        {
            try
            {
                System.Undo();
                return true;
            }
            catch (ActionInvalidException)
            {
                return false;
            }
        }

        //redo last undone action
        public bool Redo()
        {
            try
            {
                System.Redo();
                return true;
            }
            catch (ActionInvalidException)
            {
                return false;
            }
        }

        public bool CanUndo()
        {
            return System.UndoStack.Count > 0;
        }

        public bool CanRedo()
        {
            return System.RedoStack.Count > 0;
        }
    }
}
