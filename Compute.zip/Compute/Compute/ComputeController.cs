﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Compute
{
    //This is the Class to communicate with the external caller
    public class ComputeController
    {

        Eventsystem _Events;

        //these are the events a caller can subscribe to for frontend updates
        public Eventsystem Events
        {
            get { return _Events; }
            set { _Events = value; }
        }

        Root system;

        bool throwsErrors;


        /// <summary>
        /// creates a compute System from a custom savepath, loads from name if exists
        /// </summary>
        /// <param name="name">name of the system</param>
        /// <param name="autosave">autosave changes in the savepath under given name</param>
        /// <param name="savepath">path from where to load</param>
        /// <param name="subfolder">saves in a subfolder named after the place</param>
        public ComputeController(string name, bool autosave, string savepath, bool subfolder, bool throwsErrors)
        {
            this.throwsErrors = throwsErrors;
            Events = new Eventsystem(this, name, autosave, savepath, subfolder);
            system = Events.Owner;
        }

        /// <summary>
        /// creates a compute System from the default savepath, loads from name if exists
        /// </summary>
        /// <param name="name">name of the system</param>
        /// <param name="autosave">autosave changes in the default savepath under given name</param>
        /// /// <param name="subfolder">saves in a subfolder named after the place</param>
        public ComputeController(string name, bool autosave, bool subfolder, bool throwsErrors) : this(name, autosave, SaveLoadManager.DefaultSavePath, subfolder, throwsErrors)
        { }

        /// <summary>
        /// creates a compute System from the given XML string, but changes wont be saved
        /// </summary>
        /// <param name="name">name of the system</param>
        /// <param name="XML">XML string containing the system</param>
        /// <param name="savepath">path from where to load (additional childplace references)</param> 
        public ComputeController(string name, string XML, string savepath, bool throwsErrors)
        {
            this.throwsErrors = throwsErrors;
            Events = new Eventsystem(this, name, XML, savepath);
            system = Events.Owner;
        }

        public void SetRootplaceBoundaries(int sizeX, int sizeY, Direction[] inputdirections, Direction[] outputdirections, int inputcount, int outputcount)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.ChangeBoundaries(sizeX, sizeY, inputdirections, outputdirections, inputcount, outputcount);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.ChangeBoundaries(sizeX, sizeY, inputdirections, outputdirections, inputcount, outputcount);
            }
        }

        public void SetRootplaceDirections(Direction[] inputdirections, Direction[] outputdirections, int inputcount, int outputcount)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.ChangeBoundaries(system.Rootplace.SizeX, system.Rootplace.SizeY, inputdirections, outputdirections, inputcount, outputcount);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.ChangeBoundaries(system.Rootplace.SizeX, system.Rootplace.SizeY, inputdirections, outputdirections, inputcount, outputcount);
            }
        }

        public void SetRootplaceSize(int sizeX, int sizeY)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.ChangeBoundaries(sizeX, sizeY, system.Rootplace.InputDirections.ToArray(), system.Rootplace.OutputDirections.ToArray(), system.Rootplace.InputCount, system.Rootplace.OutputCount);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.ChangeBoundaries(sizeX, sizeY, system.Rootplace.InputDirections.ToArray(), system.Rootplace.OutputDirections.ToArray(), system.Rootplace.InputCount, system.Rootplace.OutputCount);
            }
        }

        public void AddConveyorBelt(int posX, int posY, Direction direction)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.AddChild(new ConveyorBelt(new Position(posX, posY, system.Rootplace), system, direction, true), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.AddChild(new ConveyorBelt(new Position(posX, posY, system.Rootplace), system, direction, true), false);
            }
        }

        public void AddIncrementer(int posX, int posY, Direction direction)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.AddChild(new Incrementer(new Position(posX, posY, system.Rootplace), system, direction, true), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.AddChild(new Incrementer(new Position(posX, posY, system.Rootplace), system, direction, true), false);
            }
        }

        public void AddDecrementer(int posX, int posY, Direction direction)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.AddChild(new Decrementer(new Position(posX, posY, system.Rootplace), system, direction, true), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.AddChild(new Decrementer(new Position(posX, posY, system.Rootplace), system, direction, true), false);
            }
        }

        public void AddDestructor(int posX, int posY)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.AddChild(new Destructor(new Position(posX, posY, system.Rootplace), system, true), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.AddChild(new Destructor(new Position(posX, posY, system.Rootplace), system, true), false);
            }
        }

        public void AddHolder(int posX, int posY, Direction direction)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.AddChild(new Holder(new Position(posX, posY, system.Rootplace), system, direction, true), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.AddChild(new Holder(new Position(posX, posY, system.Rootplace), system, direction, true), false);
            }
        }

        public void AddLever(int posX, int posY, Direction direction)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.AddChild(new Lever(new Position(posX, posY, system.Rootplace), system, direction, true), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.AddChild(new Lever(new Position(posX, posY, system.Rootplace), system, direction, true), false);
            }
        }

        public void AddSwitch(int posX, int posY, Direction trueDirection, Direction falseDirection)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.AddChild(new Switch(new Position(posX, posY, system.Rootplace), system, trueDirection, falseDirection, true), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.AddChild(new Switch(new Position(posX, posY, system.Rootplace), system, trueDirection, falseDirection, true), false);
            }
        }

        public void AddMover(int posX, int posY)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.AddChild(new Mover(new Position(posX, posY, system.Rootplace), system, true), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.AddChild(new Mover(new Position(posX, posY, system.Rootplace), system, true), false);
            }
        }

        public void AddJumper(int posX, int posY, int targetX, int targetY)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.AddChild(new Jumper(new Position(posX, posY, system.Rootplace), system, new Position(targetX, targetY, system.Rootplace), true), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.AddChild(new Jumper(new Position(posX, posY, system.Rootplace), system, new Position(targetX, targetY, system.Rootplace), true), false);
            }
        }

        public void AddComparer(int posX, int posY, Direction trueDirection, Direction falseDirection, int compareValue)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.AddChild(new Comparer(new Position(posX, posY, system.Rootplace), system, trueDirection, falseDirection, compareValue, true), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.AddChild(new Comparer(new Position(posX, posY, system.Rootplace), system, trueDirection, falseDirection, compareValue, true), false);
            }
        }

        public void AddCreator(int posX, int posY, Direction createDirection, int createValue)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.AddChild(new Creator(new Position(posX, posY, system.Rootplace), system, createDirection, createValue, true), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.AddChild(new Creator(new Position(posX, posY, system.Rootplace), system, createDirection, createValue, true), false);
            }
        }

        public void AddCopier(int posX, int posY, Direction direction, Direction createDirection)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.AddChild(new Copier(new Position(posX, posY, system.Rootplace), system, direction, createDirection, true), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.AddChild(new Copier(new Position(posX, posY, system.Rootplace), system, direction, createDirection, true), false);
            }
        }

        public void AddMelter(int posX, int posY, Direction direction)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.AddChild(new Melter(new Position(posX, posY, system.Rootplace), system, direction, true), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.AddChild(new Melter(new Position(posX, posY, system.Rootplace), system, direction, true), false);
            }
        }

        public void AddAdder(int posX, int posY, Direction direction)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.AddChild(new Adder(new Position(posX, posY, system.Rootplace), system, direction, true), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.AddChild(new Adder(new Position(posX, posY, system.Rootplace), system, direction, true), false);
            }
        }

        public void AddSubber(int posX, int posY, Direction direction)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.AddChild(new Subber(new Position(posX, posY, system.Rootplace), system, direction, true), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.AddChild(new Subber(new Position(posX, posY, system.Rootplace), system, direction, true), false);
            }
        }

        public void AddMultiplier(int posX, int posY, Direction direction)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.AddChild(new Multiplier(new Position(posX, posY, system.Rootplace), system, direction, true), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.AddChild(new Multiplier(new Position(posX, posY, system.Rootplace), system, direction, true), false);
            }
        }

        public void AddDivider(int posX, int posY, Direction direction, Direction modDirection)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.AddChild(new Divider(new Position(posX, posY, system.Rootplace), system, direction, modDirection, true), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.AddChild(new Divider(new Position(posX, posY, system.Rootplace), system, direction, modDirection, true), false);
            }
        }

        public void AddMemory(int posX, int posY, Direction direction)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.AddChild(new Memory(new Position(posX, posY, system.Rootplace), system, direction, true), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.AddChild(new Memory(new Position(posX, posY, system.Rootplace), system, direction, true), false);
            }
        }

        public void AddIdenticalTester(int posX, int posY, Direction direction)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.AddChild(new IdenticalTester(new Position(posX, posY, system.Rootplace), system, direction, true), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.AddChild(new IdenticalTester(new Position(posX, posY, system.Rootplace), system, direction, true), false);
            }
        }

        public void AddGreaterThanTester(int posX, int posY, Direction direction)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.AddChild(new GreaterThanTester(new Position(posX, posY, system.Rootplace), system, direction, true), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.AddChild(new GreaterThanTester(new Position(posX, posY, system.Rootplace), system, direction, true), false);
            }
        }

        public void AddSplitter(int posX, int posY, Direction direction, Direction Direction2)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.AddChild(new Splitter(new Position(posX, posY, system.Rootplace), system, direction, Direction2, true), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.AddChild(new Splitter(new Position(posX, posY, system.Rootplace), system, direction, Direction2, true), false);
            }
        }

        public void AddAlternator(int posX, int posY, Direction direction, Direction Direction2)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.AddChild(new Alternator(new Position(posX, posY, system.Rootplace), system, direction, Direction2, true), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.AddChild(new Alternator(new Position(posX, posY, system.Rootplace), system, direction, Direction2, true), false);
            }
        }

        public void Connect(int lPosX, int lPosY, int fPosX, int fPosY)
        {
            if (!throwsErrors)
            {
                try
                {
                    //try to connect the Objekts (both ways)
                    system.Rootplace.ConnectLeverToFlickable(lPosX, lPosY, fPosX, fPosY);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                //try to connect the Objekts (both ways)
                system.Rootplace.ConnectLeverToFlickable(lPosX, lPosY, fPosX, fPosY);
            }
        }

        public void Disconnect(int posX, int posY)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.Disconnect(posX, posY);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.Disconnect(posX, posY);
            }
        }

        public void ChangeTarget(int posX, int posY, int targetX, int targetY)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.ChangeJumpTarget(posX, posY, targetX, targetY);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.ChangeJumpTarget(posX, posY, targetX, targetY);
            }
        }

        public void SetValue(int posX, int posY, int value)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.ChangeTargetValue(posX, posY, value);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.ChangeTargetValue(posX, posY, value);
            }
        }

        /// <summary>
        /// change direction for all outputs pointing in a specific direction
        /// </summary>
        /// <param name="posX">X position in place</param>
        /// <param name="posY">Y position in place</param>
        /// <param name="dOld">old direction of output</param>
        /// <param name="dNew">new direction for output</param>
        /// <returns></returns>
        public void ChangeOutputdirection(int posX, int posY, Direction dOld, Direction dNew)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.ChangeOutputDirection(posX, posY, dOld, dNew);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.ChangeOutputDirection(posX, posY, dOld, dNew);
            }
        }

        /// <summary>
        /// change direction for a specific output of a placeable
        /// </summary>
        /// <param name="posX">X position in place</param>
        /// <param name="posY">Y position in place</param>
        /// <param name="index">outputindex to change</param>
        /// <param name="dNew">new direction for output</param>
        /// <returns></returns>
        public void ChangeOutputdirection(int posX, int posY, int index, Direction dNew)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.ChangeOutputDirection(posX, posY, index, dNew);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.ChangeOutputDirection(posX, posY, index, dNew);
            }
        }

        public void TurnAround(int posX, int posY, int quarters)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.Rotate(posX, posY, quarters);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.Rotate(posX, posY, quarters);
            }
        }

        ///alternatively LoadComputer with new name will create a new empty Place
        public void AddComputer(int posX, int posY, string name, Direction[] inputs, Direction[] outputs, int inputcount, int outputcount)
        {
            if (!throwsErrors)
            {
                try
                {
                    //add empty place
                    system.Rootplace.AddChild(new Place(new Position(posX, posY, system.Rootplace), system, true, posX, posY, name, Direction.Right, inputs, outputs, inputcount, outputcount), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                //add empty place
                system.Rootplace.AddChild(new Place(new Position(posX, posY, system.Rootplace), system, true, posX, posY, name, Direction.Right, inputs, outputs, inputcount, outputcount), false);
            }
        }

        public void LoadComputerByName(int posX, int posY, string name)
        {
            if (!throwsErrors)
            {
                try
                {
                    //add place from blueprint
                    system.Rootplace.AddChild(SaveLoadManager.LoadPlace(name, new Position(posX, posY, system.Rootplace)), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                //add place from blueprint
                system.Rootplace.AddChild(SaveLoadManager.LoadPlace(name, new Position(posX, posY, system.Rootplace)), false);
            }
        }

        public void LoadComputerFromFile(int posX, int posY, string blueprint)
        {
            if (!throwsErrors)
            {
                try
                {
                    //add place from blueprint
                    system.Rootplace.AddChild(SaveLoadManager.LoadPlace(new Position(posX, posY, system.Rootplace), blueprint), false);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                //add place from blueprint
                system.Rootplace.AddChild(SaveLoadManager.LoadPlace(new Position(posX, posY, system.Rootplace), blueprint), false);
            }
        }

        public void ChangePosition(int oldPosX, int oldPosY, int newPosX, int newPosY, bool replace)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.ChangeChildPosition(oldPosX, oldPosY, newPosX, newPosY, replace);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.ChangeChildPosition(oldPosX, oldPosY, newPosX, newPosY, replace);
            }
        }

        public void SwapPosition(int PosX1, int PosY1, int PosX2, int PosY2)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.SwapChildPositions(PosX1, PosY1, PosX2, PosY2);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.SwapChildPositions(PosX1, PosY1, PosX2, PosY2);
            }
        }

        public void CopyPasteObjekt(PlaceableObjekt p, int newPosX, int newPosY, bool replace)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.CopyObject(p, newPosX, newPosY, replace);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.CopyObject(p, newPosX, newPosY, replace);
            }
        }

        public void CopyPasteObjekt(int posX, int posY, int newPosX, int newPosY, bool replace)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.CopyChild(posX, posY, newPosX, newPosY, replace);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.CopyChild(posX, posY, newPosX, newPosY, replace);
            }
        }

        public bool PositionAvailable(int posX, int posY)
        {
            if (!throwsErrors)
            {
                try
                {
                    return system.Rootplace.GetChildAt(posX, posY) == null;
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                    return false;
                }
            }
            else
            {
                return system.Rootplace.GetChildAt(posX, posY) == null;
            }
        }

        public void DeleteAtPosition(int posX, int posY)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Rootplace.RemoveChild(posX, posY);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Rootplace.RemoveChild(posX, posY);
            }
        }

        public void AddNextInput(Direction direction, int value)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.ReceiveInput(new MoveOrder(new Moveable(new Position(0, 0, system), system, value), direction));
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.ReceiveInput(new MoveOrder(new Moveable(new Position(0, 0, system), system, value), direction));
            }
        }

        public void AddNextExpectedOutput(Direction direction, int value)
        {
            if (!throwsErrors)
            {
                try
                {
                    system.ReceiveValidation(new MoveOrder(new Moveable(new Position(0, 0, system), system, value), direction));
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.ReceiveValidation(new MoveOrder(new Moveable(new Position(0, 0, system), system, value), direction));
            }
        }

        public void Step()
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Execute(ExecType.Substep);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Execute(ExecType.Substep);
            }
        }

        public void Circle()
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Execute(ExecType.Tick);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Execute(ExecType.Tick);
            }
        }

        public async Task CompletionAsync()
        {
            if (!throwsErrors)
            {
                try
                {
                    await Task.Run(() =>
                    {
                        system.Execute(ExecType.Complete);
                    }); 
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                await Task.Run(() =>
                {
                    system.Execute(ExecType.Complete);
                });
            }
        }

        public void Completion()
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Execute(ExecType.Complete);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Execute(ExecType.Complete);
            }
        }

        public void ResetSystem()
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Execute(ExecType.Reset);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Execute(ExecType.Reset);
            }
        }

        public List<PlaceableObjekt> GetInitialObjects()
        {
            if (!throwsErrors)
            {
                try
                {
                    //return all objects in the Rootplace (returner and loaded children at start)
                    return system.Rootplace.GetChildren();
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                    return null;
                }
            }
            else
            {
                //return all objects in the Rootplace (returner and loaded children at start)
                return system.Rootplace.GetChildren();
            }
        }

        public PlaceableObjekt GetObjectAt(int posX, int posY)
        {
            if (!throwsErrors)
            {
                try
                {
                    return system.Rootplace.GetChildAt(posX, posY);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                    return null;
                }
            }
            else
            {
                return system.Rootplace.GetChildAt(posX, posY);
            }
        }

        public Moveable GetInputAt(int posX, int posY)
        {
            if (!throwsErrors)
            {
                try
                {
                    return system.Rootplace.GetInputAt(posX, posY);
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                    return null;
                }
            }
            else
            {
                return system.Rootplace.GetInputAt(posX, posY);
            }
        }

        //undo last action
        public void Undo()
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Undo();
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Undo();
            }
        }

        //redo last undone action
        public void Redo()
        {
            if (!throwsErrors)
            {
                try
                {
                    system.Redo();
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                }
            }
            else
            {
                system.Redo();
            }
        }

        public bool CanUndo()
        {
            if (!throwsErrors)
            {
                try
                {
                    return system.UndoStack.Count > 0;
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                    return false;
                }
            }
            else
            {
                return system.UndoStack.Count > 0;
            }
        }

        public bool CanRedo()
        {
            if (!throwsErrors)
            {
                try
                {
                    return system.RedoStack.Count > 0;
                }
                catch (ActionInvalidException)
                {
                    //do not pass on exceptions if not preferred
                    return false;
                }
            }
            else
            {
                return system.RedoStack.Count > 0;
            }
        }
    }
}
