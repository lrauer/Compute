﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public class ActivatedEventArgs: PositionEventArgs
    {
        bool _OldActivated;

        public bool OldActivated
        {
            get { return _OldActivated; }
            set { _OldActivated = value; }
        }

        bool _NewActivated;

        public bool NewActivated
        {
            get { return _NewActivated; }
            set { _NewActivated = value; }
        }

        public ActivatedEventArgs(bool oldActivated, bool newActivated, int oldPositionX, int newPositionX, int oldPositionY, int newPositionY, PlaceableObjekt oldPositionParent, PlaceableObjekt newPositionParent, Objektname ownerType)
            :base(oldPositionX, newPositionX, oldPositionY, newPositionY, oldPositionParent, newPositionParent, ownerType) 
        {
            OldActivated = oldActivated;
            NewActivated = newActivated;
        }
    }
}
