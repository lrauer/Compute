﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public enum Objektname
    {
        Place, Moveable, ConveyorBelt, Comparer, Incrementer, Decrementer, Returner, Root, Destructor, Holder, Lever, Switch, Mover, Jumper, Creator, Copier, Melter, Adder, Subber, Multiplier, Divider, Memory, IdenticalTester, GreaterThanTester, Splitter, Alternator
    }

    public static class ObjektnameHelper
    {

        public static Worldobjekt GetObjekt(Objektname name, PlaceableObjekt parent)
        {
            switch (name)
            {
                case Objektname.Place:
                    return new Place(new Position(0, 0, parent), parent.MyRoot, true, 1, 1, "LastEdit", Direction.Right, new Direction[1] { Direction.Right }, new Direction[1] { Direction.Right }, 0, 0);
                case Objektname.ConveyorBelt:
                    return new ConveyorBelt(new Position(0, 0, parent), parent.MyRoot, Direction.Right, true);
                case Objektname.Comparer:
                    return new Comparer(new Position(0, 0, parent), parent.MyRoot, Direction.Right, Direction.Right, 0, true);
                case Objektname.Incrementer:
                    return new Incrementer(new Position(0, 0, parent), parent.MyRoot, Direction.Right, true);
                case Objektname.Decrementer:
                    return new Decrementer(new Position(0, 0, parent), parent.MyRoot, Direction.Right, true);
                case Objektname.Returner:
                    return new Returner(new Position(0, 0, parent), parent.MyRoot, Direction.Right, true, true, true);
                case Objektname.Destructor:
                    return new Destructor(new Position(0, 0, parent), parent.MyRoot, true);
                case Objektname.Holder:
                    return new Holder(new Position(0, 0, parent), parent.MyRoot, Direction.Right, true);
                case Objektname.Lever:
                    return new Lever(new Position(0, 0, parent), parent.MyRoot, Direction.Right, true);
                case Objektname.Switch:
                    return new Switch(new Position(0, 0, parent), parent.MyRoot, Direction.Right, Direction.Right, true);
                case Objektname.Mover:
                    return new Mover(new Position(0, 0, parent), parent.MyRoot, true);
                case Objektname.Jumper:
                    return new Jumper(new Position(0, 0, parent), parent.MyRoot, new Position(0, 0, null), true);
                case Objektname.Creator:
                    return new Creator(new Position(0, 0, parent), parent.MyRoot, Direction.Right, 0, true);
                case Objektname.Copier:
                    return new Copier(new Position(0, 0, parent), parent.MyRoot, Direction.Right, Direction.Right, true);
                case Objektname.Melter:
                    return new Melter(new Position(0, 0, parent), parent.MyRoot, Direction.Right, true);
                case Objektname.Adder:
                    return new Adder(new Position(0, 0, parent), parent.MyRoot, Direction.Right, true);
                case Objektname.Subber:
                    return new Subber(new Position(0, 0, parent), parent.MyRoot, Direction.Right, true);
                case Objektname.Divider:
                    return new Divider(new Position(0, 0, parent), parent.MyRoot, Direction.Right, Direction.Right, true);
                case Objektname.Multiplier:
                    return new Multiplier(new Position(0, 0, parent), parent.MyRoot, Direction.Right, true);
                case Objektname.Memory:
                    return new Memory(new Position(0, 0, parent), parent.MyRoot, Direction.Right, true);
                case Objektname.IdenticalTester:
                    return new IdenticalTester(new Position(0, 0, parent), parent.MyRoot, Direction.Right, true);
                case Objektname.GreaterThanTester:
                    return new GreaterThanTester(new Position(0, 0, parent), parent.MyRoot, Direction.Right, true);
                case Objektname.Splitter:
                    return new Splitter(new Position(0, 0, parent), parent.MyRoot, Direction.Right, Direction.Right, true);
                case Objektname.Alternator:
                    return new Alternator(new Position(0, 0, parent), parent.MyRoot, Direction.Right, Direction.Right, true);
                case Objektname.Moveable:
                    return new Moveable(new Position(0, 0, parent), parent.MyRoot, 0);
                case Objektname.Root:
                    throw new NotImplementedException("This Objecttype cannot be parsed from name");
                default:
                    throw new NotImplementedException("This Objecttype cannot be parsed from name");
            }
        }

        public static Objektname GetName(Worldobjekt objekt)
        {
            if (objekt.GetType() == typeof(Moveable))
                return Objektname.Moveable;
            if (objekt.GetType() == typeof(Place))
                return Objektname.Place;
            if (objekt.GetType() == typeof(ConveyorBelt))
                return Objektname.ConveyorBelt;
            if (objekt.GetType() == typeof(Comparer))
                return Objektname.Comparer;
            if (objekt.GetType() == typeof(Incrementer))
                return Objektname.Incrementer;
            if (objekt.GetType() == typeof(Decrementer))
                return Objektname.Decrementer;
            if (objekt.GetType() == typeof(Returner))
                return Objektname.Returner;
            if (objekt.GetType() == typeof(Destructor))
                return Objektname.Destructor;
            if (objekt.GetType() == typeof(Holder))
                return Objektname.Holder;
            if (objekt.GetType() == typeof(Lever))
                return Objektname.Lever;
            if (objekt.GetType() == typeof(Switch))
                return Objektname.Switch;
            if (objekt.GetType() == typeof(Mover))
                return Objektname.Mover;
            if (objekt.GetType() == typeof(Jumper))
                return Objektname.Jumper;
            if (objekt.GetType() == typeof(Creator))
                return Objektname.Creator;
            if (objekt.GetType() == typeof(Copier))
                return Objektname.Copier;
            if (objekt.GetType() == typeof(Melter))
                return Objektname.Melter;
            if (objekt.GetType() == typeof(Adder))
                return Objektname.Adder;
            if (objekt.GetType() == typeof(Subber))
                return Objektname.Subber;
            if (objekt.GetType() == typeof(Multiplier))
                return Objektname.Multiplier;
            if (objekt.GetType() == typeof(Divider))
                return Objektname.Divider;
            if (objekt.GetType() == typeof(Memory))
                return Objektname.Memory;
            if (objekt.GetType() == typeof(IdenticalTester))
                return Objektname.IdenticalTester;
            if (objekt.GetType() == typeof(GreaterThanTester))
                return Objektname.GreaterThanTester;
            if (objekt.GetType() == typeof(Splitter))
                return Objektname.Splitter;
            if (objekt.GetType() == typeof(Alternator))
                return Objektname.Alternator;
            if (objekt.GetType() == typeof(Root))
                return Objektname.Root;

            throw new NotImplementedException("This Object has no Objektname");
        }

    }
}
