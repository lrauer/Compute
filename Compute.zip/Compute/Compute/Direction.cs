﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public static class DirectionHelper
    {

        public static Direction Invert(Direction direction)
        {
            switch (direction)
            {
                case Direction.Down:
                    return Direction.Up;
                case Direction.Up:
                    return Direction.Down;
                case Direction.Left:
                    return Direction.Right;
                case Direction.Right:
                    return Direction.Left;
                case Direction.Hold:
                    return Direction.Hold;
                case Direction.Parent:
                    return Direction.Child;
                case Direction.Child:
                    return Direction.Parent;
            }

            throw new ArgumentException("Impossible direction for invert");
        }

        //return which direction you have to travel the most to get from the old to the new position
        public static Direction GetRelative(Position posFrom, Position posTo)
        {
            //changed to parent
            if (posFrom.Parent.Position == posTo)
                return Direction.Parent;

            //changed to child
            if (posFrom == posTo.Parent.Position)
                return Direction.Child;

            //length you travel for each axis
            int difX = posTo.PosX - posFrom.PosX;
            int difY = posTo.PosY - posFrom.PosY;

            //if positions are identical
            if (difX == 0 && difY == 0)
                return Direction.Hold;

            //which direction do you have to travel on each axis?
            Direction xAxis = Direction.Right;
            Direction yAxis = Direction.Up;

            //travel left or right?
            if (difX < 0)
            {
                difX *= -1;
                xAxis = Direction.Left;
            }

            //travel up or down?
            if (difY < 0)
            {
                difY *= -1;
                yAxis = Direction.Down;
            }

            //which axis do you have to travel the furthest?
            if (difX > difY)
            {
                return xAxis;
            }
            else
            {
                return yAxis;
            }
        }

        //get the position where you came from if you landed on posAfter with target Direction
        public static Position GetFromPosition(Position posAfter, Direction target)
        {

            switch (target)
            {
                case Direction.Down:
                    return new Position(posAfter.PosX,posAfter.PosY + 1, posAfter.Parent);
                case Direction.Up:
                    return new Position(posAfter.PosX, posAfter.PosY - 1, posAfter.Parent);
                case Direction.Left:
                    return new Position(posAfter.PosX + 1, posAfter.PosY, posAfter.Parent);
                case Direction.Right:
                    return new Position(posAfter.PosX - 1, posAfter.PosY, posAfter.Parent);
                case Direction.Hold:
                    return new Position(posAfter.PosX, posAfter.PosY, posAfter.Parent);
                case Direction.Child:
                    return new Position(posAfter.PosX, posAfter.PosY, posAfter.Parent.Position.Parent);
                //can not know which child the object belonged to before
                //case Direction.Parent:
                //    return new Position(posAfter.PosX, posAfter.PosY, posAfter.Parent);
            }

            throw new ArgumentException("Impossible direction for calculating fromposition");

        }

        //get the position you willl land on if you travel from posBefore with target direction
        public static Position GetToPosition(Position posBefore, Direction target)
        {

            switch (target)
            {
                case Direction.Down:
                    return new Position(posBefore.PosX, posBefore.PosY - 1, posBefore.Parent);
                case Direction.Up:
                    return new Position(posBefore.PosX, posBefore.PosY + 1, posBefore.Parent);
                case Direction.Left:
                    return new Position(posBefore.PosX - 1, posBefore.PosY, posBefore.Parent);
                case Direction.Right:
                    return new Position(posBefore.PosX + 1, posBefore.PosY, posBefore.Parent);
                case Direction.Hold:
                    return new Position(posBefore.PosX, posBefore.PosY, posBefore.Parent);
                case Direction.Parent:
                    return new Position(posBefore.PosX, posBefore.PosY, posBefore.Parent.Position.Parent);
                //can not know to which child you want to change
                //case Direction.Child:
                //    return new Position(posBefore.PosX, posBefore.PosY, posBefore.Parent.Position.Parent);
            }

            throw new ArgumentException("Impossible direction for calculating targetposition");

        }

        //rotate int quarters clockwise
        public static Direction Rotate(Direction d, int quarters)
        {
            quarters = quarters % 4;
            for (int i = 0; i < quarters; i++)
            {
                d = Rotate(d);
            }
            return d;
        }

        //rotate 1 step clockwise
        public static Direction Rotate(Direction d)
        {
            switch (d)
            {
                case Direction.Left:
                    return Direction.Up;
                case Direction.Up:
                    return Direction.Right;
                case Direction.Right:
                    return Direction.Down;
                case Direction.Down:
                    return Direction.Left;
                default:
                    return d;
            }
        }

        //returns the Rotation in quarters to Standard Right
        public static int GetRotation(Direction d)
        {
            switch (d)
            {
                case Direction.Left:
                    return 2;
                case Direction.Up:
                    return 3;
                case Direction.Down:
                    return 1;
                default:
                    return 0;
            }
        }

    }

    public enum Direction
    {
        Left, Right, Up, Down, Parent, Child, Hold

    }
}
