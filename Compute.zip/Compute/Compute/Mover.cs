﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    class Mover: AssemblyLine
    {
        public Mover(Position position, Root root, bool destructable)
            : base(position, root, destructable)
        {
            OutputDirections.Add(Direction.Right);
            OutputDirections.Add(Direction.Left);
            OutputDirections.Add(Direction.Up);
            OutputDirections.Add(Direction.Down);
        }

        Direction _LastInputDirection;

        public Direction LastInputDirection
        {
            get { return _LastInputDirection; }
            set { _LastInputDirection = value; }
        }

        public override void ReceiveInput(MoveOrder moveOrder)
        {
            base.ReceiveInput(moveOrder);
            LastInputDirection = DirectionHelper.Invert(moveOrder.Order);
        }

        //release forward
        public override void ExecuteTick()
        {
            ReleaseOutput(new MoveOrder(CurrentInput[0], LastInputDirection));
        }

        public override int GetSpace()
        {
            return 10; // 150 record
        }

        public override int GetObjectcount()
        {
            return 5; // 72 record
        }

        public override int GetDistance()
        {
            return 3; // 21 record
        }

        public override int GetSteps()
        {
            return 3; // 21 record
        }
    }
}
