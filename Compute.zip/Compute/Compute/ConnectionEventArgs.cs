﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public class ConnectionEventArgs : PositionEventArgs
    {
        IFlickable _OldConnection;

        public IFlickable OldConnection
        {
            get { return _OldConnection; }
            set { _OldConnection = value; }
        }

        IFlickable _NewConnection;

        public IFlickable NewConnection
        {
            get { return _NewConnection; }
            set { _NewConnection = value; }
        }

        public ConnectionEventArgs(IFlickable oldConnection, IFlickable newConnection, int oldPositionX, int newPositionX, int oldPositionY, int newPositionY, PlaceableObjekt oldPositionParent, PlaceableObjekt newPositionParent, Objektname ownerType)
            : base(oldPositionX, newPositionX, oldPositionY, newPositionY, oldPositionParent, newPositionParent, ownerType)
        {
            OldConnection = oldConnection;
            NewConnection = newConnection;
        }
    }
}
