﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public class Incrementer: ConveyorBelt
    {
        public Incrementer(Position position, Root root, Direction output, bool destructable)
            : base(position, root, output, destructable)
        {

        }

        public override void ExecuteTick()
        {
            CurrentInput[0].Value++;
            base.ExecuteTick();
        }

        public override int GetSpace()
        {
            return 0;
        }

        public override int GetObjectcount()
        {
            return 1;
        }

        public override int GetDistance()
        {
            return 1;
        }

        public override int GetSteps()
        {
            return 1;
        }

        public override string GetDescription()
        {
            return "Takes 1 input and increments it by 1. Then releases the result in the outputdirection.";
        }
    }
}
