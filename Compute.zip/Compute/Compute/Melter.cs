﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    class Melter: AssemblyLine
    {
        public Melter(Position position, Root root, Direction output, bool destructable)
            : base(position, root, output, destructable)
        {
            InputCount = 2;
        }

        public override bool PrepareTick()
        {
            switch (CurrentInput.Count)
            {
                case 0:
                    return false;
                case 1:
                    return false;
                case 2:
                    return true;
                default:
                    throw new ActionInvalidException("This Object can only process 2 inputs", this, Position);
            }
        }

        public override void ExecuteTick()
        {
            //delete second object
            //remove reference to this objekt from the second moveable
            Moveable m = CurrentInput[1];
            m.Position.SetValues(0, 0, null);
            //remove reference in parentplace as well
            Place p = Position.Parent as Place;
            p.RemoveCurrentInput(m);
            base.ExecuteTick();
        }

        public override int GetSpace()
        {
            return 3; // 9 record (ohne all)
        }

        public override int GetObjectcount()
        {
            return 2; // 4 record (ohne all)
        }

        public override int GetDistance()
        {
            return 2; // 5 record (ohne all)
        }

        public override int GetSteps()
        {
            return 2; // 6 record (ohne all)
        }
    }
}
