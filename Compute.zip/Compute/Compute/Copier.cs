﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    class Copier : AssemblyLine
    {
        public Copier(Position position, Direction output, Direction output2, bool destructable)
            : base(position, output, destructable)
        {
            OutputCount = 2;
            OutputDirections.Add(output2);
        }

        public override void ExecuteTick()
        {
            //create new moveable as child for this Copier
            Moveable m = new Moveable(new Position(0, 0, this), CurrentInput[0].Value);
            //add reference to parentplace as well
            Place p = Position.Parent as Place;
            p.AddCurrentInput(m);
            base.ExecuteTick();
            ReleaseOutput(new MoveOrder(m, OutputDirections[1]));
        }

    }
}
