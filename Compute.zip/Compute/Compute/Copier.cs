﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    class Copier : ConveyorBelt
    {
        public Copier(Position position, Root root, Direction output, Direction output2, bool destructable)
            : base(position, root, output, destructable)
        {
            OutputCount = 2;
            OutputDirections.Add(output2);
        }

        public override void ExecuteTick()
        {
            //create new moveable as child for this Copier
            Moveable m = new Moveable(new Position(0, 0, this), MyRoot, CurrentInput[0].Value);
            //add reference to parentplace as well
            Place p = Position.Parent as Place;
            p.AddCurrentInput(m);
            base.ExecuteTick();
            ReleaseOutput(new MoveOrder(m, OutputDirections[1]));
        }

        public override int GetSpace()
        {
            return 20; // 49 record (ohne all)
        }

        public override int GetObjectcount()
        {
            return 10; // 22 record (ohne all)
        }

        public override int GetDistance()
        {
            return 15; // 45 record (ohne all)
        }

        public override int GetSteps()
        {
            return 15; // 46 record (ohne all)
        }

        public override string GetDescription()
        {
            return "Takes 1 input and copies it. Then releases it in both outputdirections.";
        }

    }
}
