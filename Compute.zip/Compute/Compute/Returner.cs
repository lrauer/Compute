﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    public class Returner : ConveyorBelt
    {
        public Returner(Position position, Root root, Direction output, bool destructable, bool canReceive, bool canReturn)
            : base(position, root, output, destructable)
        {
            this.canReceive = canReceive;
            this.canReturn = canReturn;
            fromParent = new List<bool>();
            //returner can receive objects from the parent 
            //this means the input came from the parent of this returners parent
            if (canReceive)
            {
                InputDirections.Add(Direction.Parent);
            }
            //returner can return objekts to the parent
            //this means the output will be passed to the parent of this returners parent
            if (canReturn)
            {
                OutputDirections.Add(Direction.Parent);
            }
        }

        List<bool> fromParent;

        bool canReceive;
        bool canReturn;

        public override bool PrepareTick()
        {
            //returner can process more than 1 input but will only output the first input per tick
            //But it will return as many outputs as possible
            switch (CurrentInput.Count)
            {
                case 0:
                    return false;
                default:
                    return true;
            }
        }

        public override void ReceiveInput(MoveOrder moveOrder)
        {
            base.ReceiveInput(moveOrder);
            //Parent means it was passed down from the parentplace
            if (moveOrder.Order == Direction.Parent)
            {
                if (!canReceive)
                {
                    throw new ActionInvalidException("This Place cant receive input from this direction", this, Position);
                }
                fromParent.Add(true);
            }
            else
            {
                fromParent.Add(false);
            }
        }

        public override void Reset()
        {
            base.Reset();
            fromParent.Clear();
        }

        public override void ExecuteTick()
        {
            bool firstinput = true;
            //do all returns but only first input
            for (int i = 0; i < CurrentInput.Count; i++)
            {
                //return to parent
                if (!fromParent[i] && canReturn)
                {
                    ReleaseOutputIndexed(new MoveOrder(CurrentInput[i], OutputDirections[0]), i);
                    i--;
                }
                //return to side
                else if (firstinput)
                {
                    firstinput = false;
                    ReleaseOutputIndexed(new MoveOrder(CurrentInput[i], OutputDirections[0]), i);
                    i--;
                }
            }
        }

        void ReleaseOutputIndexed(MoveOrder moveOrder, int index)
        {
            CurrentInput.RemoveAt(index);

            //return to parent
            if (!fromParent[index] && canReturn)
            {
                if (!OutputDirections.Contains(Direction.Parent))
                {
                    throw new ActionInvalidException("This Place cant release output to this direction", this, Position);
                }
                //set position of output to own position to return it 1 level
                moveOrder.Objekt.Position.Copy(Position);
                //invert direction so we can use it to see which returner has created the output
                moveOrder.Order = DirectionHelper.Invert(moveOrder.Order);
                Position.Parent.ReleaseOutput(moveOrder);
            }
            //release to side
            else
            {
                Position.Parent.ReleaseOutput(moveOrder);
            }
            fromParent.RemoveAt(index);
        }

        public override void ReleaseOutput(MoveOrder moveOrder)
        {
            ReleaseOutputIndexed(moveOrder, 0);
        }
        public override int GetSpace()
        {
            return 0;
        }

        public override int GetObjectcount()
        {
            return 1;
        }

        public override int GetDistance()
        {
            return 1;
        }

        public override int GetSteps()
        {
            return 1;
        }

        public override string GetDescription()
        {
            return "Can take inputs and release outputs for the System depending on the input- and outputdirections of the place.";
        }
    }
}
