﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compute
{
    class Returner : AssemblyLine
    {
        public Returner(Position position, Root root, Direction output, bool destructable, bool canReceive, bool canReturn)
            : base(position, root, output, destructable)
        {
            keep = new List<bool>();
            //returner can receive objects from the parent 
            //this means the input came from the parent of this returners parent
            if (canReceive)
            {
                InputDirections.Add(Direction.Parent);
            }
            //returner can return objekts to the parent
            //this means the output will be passed to the parent of this returners parent
            if (canReturn)
            {
                OutputDirections.Add(Direction.Parent);
            }
        }

        List<bool> keep;

        public override bool PrepareTick()
        {
            //returner can process more than 1 input but will only output the first input per tick
            //But it will return as many outputs as possible
            switch (CurrentInput.Count)
            {
                case 0:
                    return false;
                default:
                    return true;
            }
        }

        public override void ReceiveInput(MoveOrder moveOrder)
        {
            base.ReceiveInput(moveOrder);
            //Parent means it was passed down from the parentplace
            if (moveOrder.Order == Direction.Parent)
            {
                if (!InputDirections.Contains(Direction.Parent))
                {
                    throw new ActionInvalidException("This Place cant receive input from this direction", this);
                }
                keep.Add(true);
            }
            else
            {
                //if this object cant output it will keep the moveable
                if (!OutputDirections.Contains(Direction.Parent))
                {
                    keep.Add(true);
                }
                else
                {
                    keep.Add(false);
                }
            }
        }

        public override void Reset()
        {
            base.Reset();
            keep.Clear();
        }

        public override void ExecuteTick()
        {
            bool firstinput = true;
            //do all returns but only first input
            for(int i = 0; i < CurrentInput.Count; i++)
            {
                if (!keep[i] || firstinput)
                {
                    if (keep[i])
                    {
                        firstinput = false;
                    }
                    ReleaseOutput(new MoveOrder(CurrentInput[i], OutputDirections[i]));
                    i--;
                }
            }
        }

        public override void ReleaseOutput(MoveOrder moveOrder)
        {
            CurrentInput.RemoveAt(0);
            if (keep[0])
            {
                Position.Parent.ReleaseOutput(moveOrder);
            }
            else
            {
                if (!OutputDirections.Contains(Direction.Parent))
                {
                    throw new ActionInvalidException("This Place cant release output to this direction", this);
                }
                //set position of output to own position to return it 1 level
                moveOrder.Objekt.Position.Copy(Position);
                //invert direction so we can use it to see which returner has created the output
                moveOrder.Order = DirectionHelper.Invert(moveOrder.Order);
                Position.Parent.ReleaseOutput(moveOrder);
            }
            keep.RemoveAt(0);
        }

    }
}
