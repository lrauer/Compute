﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Compute
{
    public class Root: PlaceableObjekt
    {

        public event EventHandler<QueueEventArgs> InputQueueProgressed;
        public event EventHandler<QueueValidationEventArgs> ValidationQueueProgressed;
        public event EventHandler<QueueEventArgs> InputQueueEnqueued;
        public event EventHandler<QueueEventArgs> ValidationQueueEnqueued;
        public event EventHandler<SystemStateEventArgs> ExecuteFinished;
        public event EventHandler<SystemCompletionEventArgs> ExecuteCompleted;
        public event EventHandler<SystemStateEventArgs> ExecuteCircleFinished;
        public event EventHandler<SystemStateFailedEventArgs> ExecuteFailed;
        public event EventHandler<SystemStateEventArgs> SystemResetted;
        public event EventHandler<SystemStateEventArgs> RunBegin;
        public event EventHandler<UndoEventArgs> UndoAction;
        public event EventHandler<UndoEventArgs> RedoAction;

        public Root(Eventsystem eventsystem,string name, Root root)
            : base(new Position(0, 0, null), null)
        {
            Eventsystem = eventsystem;

            UndoStack = new Stack<MementoChange>();
            RedoStack = new Stack<MementoChange>();

            Position = new Position(0,0,null);

            //loads the rootplace or creates a new if no file is found
            Rootplace = SaveLoadManager.LoadPlace(name,new Position(0,0,this));

            Creation += Eventsystem.HandleCreation;
            InputQueueProgressed += Eventsystem.HandleSystemInput;
            ValidationQueueProgressed += Eventsystem.HandleSystemOutput;
            InputQueueEnqueued += Eventsystem.HandleInputReceived;
            ValidationQueueEnqueued += Eventsystem.HandleOutputReceived;
            ExecuteFinished += Eventsystem.HandleExecuteFinished;
            ExecuteCompleted += Eventsystem.HandleExecuteCompleted;
            ExecuteCircleFinished += Eventsystem.HandleExecuteCircleFinished;
            ExecuteFailed += Eventsystem.HandleExecuteFailed;
            SystemResetted += Eventsystem.HandleSystemResetted;
            RunBegin += Eventsystem.HandleRunBegin;
            UndoAction += Eventsystem.HandleUndoAction;
            RedoAction += Eventsystem.HandleRedoAction;
            
            Created(); 
        }

        Stack<MementoChange> _UndoStack;

        internal Stack<MementoChange> UndoStack
        {
            get { return _UndoStack; }
            set { _UndoStack = value; }
        }

        public void Undo()
        {
            if (UndoStack.Count == 0)
            {
                throw new ActionInvalidException("There is no action to undo", this);
            }
            if (CurrentState != SystemState.Ready)
            {
                throw new ActionInvalidException("Cant undo action if system is running", this);
            }
            MementoChange m = UndoStack.Pop();
            m.Objekt.SetToMemento(m.OldState);
            RedoStack.Push(m);
            UndoAction.Invoke(this, new UndoEventArgs(m, UndoStack, m.CreationEvent.NewPositionX, m.CreationEvent.OldPositionX, m.CreationEvent.NewPositionY, m.CreationEvent.OldPositionY, m.CreationEvent.NewPositionParent, m.CreationEvent.OldPositionParent, m.CreationEvent.OwnerType));
        }

        Stack<MementoChange> _RedoStack;

        internal Stack<MementoChange> RedoStack
        {
            get { return _RedoStack; }
            set { _RedoStack = value; }
        }

        public void Redo()
        {
            if (RedoStack.Count == 0)
            {
                throw new ActionInvalidException("There is no action to redo", this);
            }
            if (CurrentState != SystemState.Ready)
            {
                throw new ActionInvalidException("Cant redo action if system is running", this);
            }
            MementoChange m = RedoStack.Pop();
            m.Objekt.SetToMemento(m.NewState);
            UndoStack.Push(m);
            RedoAction.Invoke(this, new UndoEventArgs(m, RedoStack, m.CreationEvent.OldPositionX, m.CreationEvent.NewPositionX, m.CreationEvent.OldPositionY, m.CreationEvent.NewPositionY, m.CreationEvent.OldPositionParent, m.CreationEvent.NewPositionParent, m.CreationEvent.OwnerType));
        }

        Eventsystem _Eventsystem;

        public Eventsystem Eventsystem
        {
            get { return _Eventsystem; }
            set { _Eventsystem = value; }
        }

        SystemState _CurrentState = SystemState.Ready;

        internal SystemState CurrentState
        {
            get { return _CurrentState; }
            set { _CurrentState = value; }
        }

        public bool IsReady()
        {
            return CurrentState == SystemState.Ready;
        }

        Queue<MoveOrder> _InputQueue = new Queue<MoveOrder>();

        public Queue<MoveOrder> InputQueue
        {
            get { return _InputQueue; }
            set { _InputQueue = value; }
        }
        Queue<MoveOrder> _ValidationQueue = new Queue<MoveOrder>();

        public Queue<MoveOrder> ValidationQueue
        {
            get { return _ValidationQueue; }
            set { _ValidationQueue = value; }
        }

         Place _Rootplace;

         public Place Rootplace
         {
             get { return _Rootplace; }
             set { 
                 _Rootplace = value;
             }
         }

         Statistics _CurrentExecute;

         public Statistics CurrentExecute
         {
             get { return _CurrentExecute; }
             set { _CurrentExecute = value; }
         }

        public override bool PrepareTick()
        {   
            throw new NotImplementedException("The Root doesnt need to prepare");
        }

        public bool Execute(ExecType execType)
        {
            bool b = true;
            if (execType == ExecType.Reset)
            {
                Reset();
            }
            else
            {
                try
                {
                    if (CurrentState == SystemState.Broken || CurrentState == SystemState.Completed)
                    {
                        throw new ActionInvalidException("The System must be resetted first", this);
                    }
                    if (Rootplace.CurrentInput.Count == 0 || CurrentState != SystemState.Running)
                    {
                        if (CurrentState != SystemState.Running)
                        {
                            CurrentExecute = new Statistics(GetObjectcount(), GetSpace(), InputQueue.Count / Rootplace.InputCount);
                            CurrentState = SystemState.Running;
                            RunBegin.Invoke(this, new SystemStateEventArgs(CurrentState, execType));
                        }
                        while (Rootplace.CurrentInput.Count < Rootplace.InputCount)
                        {
                            if (InputQueue.Count == 0)
                            {
                                throw new ActionInvalidException("Can't process without enough inputs", this);
                            }
                            MoveOrder m = InputQueue.Dequeue();
                            Rootplace.ReceiveInput(m);
                            InputQueueProgressed.Invoke(this, new QueueEventArgs(InputQueue, m, maxInputSize));
                        }
                        Rootplace.PrepareTick();
                    }
                    if (execType == ExecType.Substep)
                    {
                        Rootplace.Substep();
                    }
                    else
                    {
                        ExecuteTick();
                    }
                    //if finshed stop
                    if (InputQueue.Count == 0 && ValidationQueue.Count == 0)
                    {
                        CurrentState = SystemState.Completed;
                    }
                    //if a circle is finished
                    if (Rootplace.CurrentInput.Count == 0)
                    {
                        ExecuteCircleFinished.Invoke(this, new SystemStateEventArgs(CurrentState, execType));
                    }
                }
                catch (ActionInvalidException e)
                {
                    b = false;
                    //signal that broken, so no step can be executed anymore
                    CurrentState = SystemState.Broken;
                    //event with the position, state and Error
                    ExecuteFailed.Invoke(this, new SystemStateFailedEventArgs(CurrentState, execType, e));
                }
                finally
                {
                    // if exectype complete continue with next input
                    if (execType == ExecType.Complete && InputQueue.Count > 0 && CurrentState == SystemState.Running)
                    {
                        Execute(execType);
                    }
                    //else we are finshed with this execution, exept if broken
                    else if(CurrentState != SystemState.Broken)
                    {
                        //event with the state that this Execution is finished
                        ExecuteFinished.Invoke(this, new SystemStateEventArgs(CurrentState, execType));
                        if (CurrentState == SystemState.Completed)
                        {
                            //event with the state that this system is completed
                            ExecuteCompleted.Invoke(this, new SystemCompletionEventArgs(CurrentState, execType, CurrentExecute));
                        }
                    }
                }
            }
            return b;
        }

        //removes all inputs from the System and reverts to default state
        public override void Reset()
        {
            CurrentState = SystemState.Ready;
            Rootplace.Reset();
            InputQueue.Clear();
            ValidationQueue.Clear();
            maxInputSize = 0;
            maxValidationSize = 0;
            //event that system is resetted
            SystemResetted.Invoke(this, new SystemStateEventArgs(CurrentState, ExecType.Reset));
        }

        public override void ExecuteTick()
        {
            Rootplace.ExecuteTick();
        }

        int maxInputSize;

        public override void ReceiveInput(MoveOrder moveOrder)
        {
            InputQueue.Enqueue(moveOrder);
            maxInputSize++;
            //add to queue event
            InputQueueEnqueued.Invoke(this, new QueueEventArgs(InputQueue,moveOrder,maxInputSize));
        }

        int maxValidationSize;

        public void ReceiveValidation(MoveOrder moveOrder)
        {
            ValidationQueue.Enqueue(moveOrder);
            maxValidationSize++;
            //add to queue event
            ValidationQueueEnqueued.Invoke(this, new QueueEventArgs(ValidationQueue, moveOrder, maxValidationSize));
        }

        public override void ReleaseOutput(MoveOrder moveOrder)
        {

            if (ValidationQueue.Count == 0)
            {
                throw new ActionInvalidException("Need validationoutput for each input", this);
            }

            //Remove the moveable from the Rootplace
            moveOrder.Objekt.Position.SetValues(0, 0, null);

            QueueValidationEventArgs q = new QueueValidationEventArgs(ValidationQueue, ValidationQueue.Dequeue(), maxValidationSize, moveOrder);

            if (!q.Correct())
            {
                CurrentExecute.AllCorrect = false;
            }

            //send Event with expected and actual Moveorder for Comparison
            ValidationQueueProgressed.Invoke(this, q);

        }

        public override int GetSpace()
        {
            return Rootplace.GetSpace();
        }

        public override int GetObjectcount()
        {
            return Rootplace.GetObjectcount();
        }

        public override int GetDistance()
        {
            return 0;
        }

        public override int GetSteps()
        {
            return 0;
        }

        public override void ToXML(XmlDocument doc, XmlElement head)
        {
            throw new NotImplementedException("The Root doesnt need to be converted to XML");
        }

        public override void SetToMemento(PlaceableObjektMemento memento)
        {
            throw new NotImplementedException("The Root cannot return to earlier state");
        }

        public override PlaceableObjektMemento CreateMemento()
        {
            throw new NotImplementedException("The Root has no Memento");
        }

    }
}
